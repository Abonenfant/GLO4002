package ca.ulaval.glo4002.inn.unit.domain.stay;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.room.Room;
import ca.ulaval.glo4002.inn.domain.room.RoomDirectory;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomOccupant;
import ca.ulaval.glo4002.inn.domain.room.RoomRepository;
import ca.ulaval.glo4002.inn.domain.stay.HomeDimension;
import ca.ulaval.glo4002.inn.domain.stay.Species;
import ca.ulaval.glo4002.inn.domain.stay.StayFactory;
import ca.ulaval.glo4002.inn.domain.stay.StayLifecycle;
import ca.ulaval.glo4002.inn.domain.stay.StayPackage;
import ca.ulaval.glo4002.inn.domain.stay.StayRefusalReason;
import ca.ulaval.glo4002.inn.domain.stay.StayStatus;
import ca.ulaval.glo4002.inn.domain.stay.StayTerms;
import ca.ulaval.glo4002.inn.domain.stay.Traveller;
import ca.ulaval.glo4002.inn.domain.stay.TravellerProfile;
import ca.ulaval.glo4002.inn.domain.stay.TravellerRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryRoomRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryTravellerRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class StayLifecycleTest {
    private static final ExistenceNumber EXISTENCE_NUMBER = new ExistenceNumber("EX-01");
    private static final String NAME = "Aliqua";
    private static final TravellerProfile PROFILE =
            new TravellerProfile(NAME, Species.QUIDAM, 100, HomeDimension.SALARIA);
    private static final StayTerms TERMS = new StayTerms(PROFILE, StayPackage.COMFORT, 3);
    private static final RoomNumber ROOM_NUMBER = new RoomNumber(1);
    private static final int CAPACITY = 2;
    private static final int RESERVATION_NIGHT = 1;
    private static final int FIRST_NIGHT = 2;
    private static final int MIDDLE_NIGHT = 3;
    private static final int LAST_NIGHT = 4;

    private final TravellerRepository travellerRepository = new InMemoryTravellerRepository();
    private final RoomRepository roomRepository = new InMemoryRoomRepository();
    private final StayFactory stayFactory = new StayFactory();
    private final StayLifecycle stayLifecycle =
            new StayLifecycle(travellerRepository, new RoomDirectory(roomRepository));
    private final Room room = new Room(ROOM_NUMBER, Species.QUIDAM.requiredConfiguration(), CAPACITY);

    @BeforeEach
    void setUp() {
        roomRepository.save(room);
    }

    @Test
    void givenBookedStayStartingTonight_whenTravellersArrive_thenStayBecomesActive() {
        givenBookedTraveller();

        stayLifecycle.arriveTravellers(FIRST_NIGHT);

        assertEquals(StayStatus.ACTIVE, latestStayStatus());
    }

    @Test
    void givenBookedStayStartingTonight_whenTravellersArrive_thenTravellerOccupiesItsRoom() {
        givenBookedTraveller();

        stayLifecycle.arriveTravellers(FIRST_NIGHT);

        assertEquals(List.of(new RoomOccupant(EXISTENCE_NUMBER, NAME)), room.getOccupants());
    }

    @Test
    void givenBookedStayStartingTonight_whenTravellersArrive_thenPlaceIsNoLongerOnlyReserved() {
        givenBookedTraveller();

        stayLifecycle.arriveTravellers(FIRST_NIGHT);

        assertTrue(room.getReservedExistenceNumbers().isEmpty());
    }

    @Test
    void givenBookedStayStartingTonight_whenTravellersArrive_thenRoomKeepsTheSameFreePlaces() {
        givenBookedTraveller();

        stayLifecycle.arriveTravellers(FIRST_NIGHT);

        assertEquals(CAPACITY - 1, room.getFreePlaces());
    }

    @Test
    void givenBookedStayStartingLater_whenTravellersArriveOnReservationNight_thenStayIsStillBooked() {
        givenBookedTraveller();

        stayLifecycle.arriveTravellers(RESERVATION_NIGHT);

        assertEquals(StayStatus.BOOKED, latestStayStatus());
    }

    @Test
    void givenRefusedStay_whenTravellersArrive_thenStayIsStillRefused() {
        travellerRepository.save(new Traveller(EXISTENCE_NUMBER,
                stayFactory.createRefusedStay(RESERVATION_NIGHT, TERMS, StayRefusalReason.NO_COMPATIBLE_ROOM)));

        stayLifecycle.arriveTravellers(FIRST_NIGHT);

        assertEquals(StayStatus.REFUSED, latestStayStatus());
    }

    @Test
    void givenActiveStayEndingTonight_whenTravellersDepart_thenStayIsEnded() {
        givenArrivedTraveller();

        stayLifecycle.departTravellers(LAST_NIGHT);

        assertEquals(StayStatus.ENDED, latestStayStatus());
    }

    @Test
    void givenActiveStayEndingTonight_whenTravellersDepart_thenTravellerLeavesItsRoom() {
        givenArrivedTraveller();

        stayLifecycle.departTravellers(LAST_NIGHT);

        assertTrue(room.getOccupants().isEmpty());
    }

    @Test
    void givenActiveStayEndingTonight_whenTravellersDepart_thenItsPlaceIsFreed() {
        givenArrivedTraveller();

        stayLifecycle.departTravellers(LAST_NIGHT);

        assertEquals(CAPACITY, room.getFreePlaces());
    }

    @Test
    void givenActiveStayNotEndingTonight_whenTravellersDepart_thenStayIsStillActive() {
        givenArrivedTraveller();

        stayLifecycle.departTravellers(MIDDLE_NIGHT);

        assertEquals(StayStatus.ACTIVE, latestStayStatus());
    }

    @Test
    void givenActiveStayNotEndingTonight_whenTravellersDepart_thenTravellerKeepsItsPlace() {
        givenArrivedTraveller();

        stayLifecycle.departTravellers(MIDDLE_NIGHT);

        assertEquals(List.of(new RoomOccupant(EXISTENCE_NUMBER, NAME)), room.getOccupants());
    }

    @Test
    void givenBookedStayNotArrivedYet_whenTravellersDepart_thenStayIsStillBooked() {
        givenBookedTraveller();

        stayLifecycle.departTravellers(LAST_NIGHT);

        assertEquals(StayStatus.BOOKED, latestStayStatus());
    }

    @Test
    void givenBookedStayFollowedByRefusedStay_whenTravellerArrives_thenOccupantUsesBookedStayName() {
        Traveller traveller = givenBookedTraveller();
        TravellerProfile refusedProfile =
                new TravellerProfile("Bob", Species.QUIDAM, 80, HomeDimension.SALARIA);
        StayTerms refusedTerms = new StayTerms(refusedProfile, StayPackage.COMFORT, 3);
        traveller.addStay(stayFactory.createRefusedStay(
                RESERVATION_NIGHT,
                refusedTerms,
                StayRefusalReason.ALREADY_STAYING));
        travellerRepository.save(traveller);

        stayLifecycle.arriveTravellers(FIRST_NIGHT);

        assertEquals(List.of(new RoomOccupant(EXISTENCE_NUMBER, NAME)), room.getOccupants());
    }

    private Traveller givenBookedTraveller() {
        Traveller traveller = new Traveller(EXISTENCE_NUMBER,
                stayFactory.createBookedStay(RESERVATION_NIGHT, TERMS, ROOM_NUMBER));
        travellerRepository.save(traveller);
        room.reservePlace(EXISTENCE_NUMBER);
        return traveller;
    }

    private void givenArrivedTraveller() {
        Traveller traveller = givenBookedTraveller();
        traveller.arrive(FIRST_NIGHT);
        room.occupyReservedPlace(new RoomOccupant(EXISTENCE_NUMBER, NAME));
    }

    private StayStatus latestStayStatus() {
        return travellerRepository.findByExistenceNumber(EXISTENCE_NUMBER)
                .orElseThrow().getLatestStay().getStatus();
    }
}
