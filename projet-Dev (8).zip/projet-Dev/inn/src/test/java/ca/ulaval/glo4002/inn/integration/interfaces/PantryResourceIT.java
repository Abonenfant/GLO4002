package ca.ulaval.glo4002.inn.integration.interfaces;

import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.OrderService;
import ca.ulaval.glo4002.inn.application.PantryService;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.Pantry;
import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.order.OrderFactory;
import ca.ulaval.glo4002.inn.domain.order.OrderRepository;
import ca.ulaval.glo4002.inn.interfaces.resources.PantryResource;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.PantryResponse;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.ReserveResponse;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.ShipmentResponse;
import ca.ulaval.glo4002.inn.unit.domain.Inn.InnFactory;
import ca.ulaval.glo4002.inn.unit.domain.Inn.InnTestFactory;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PantryResourceIT {
    private static final int NO_DELAY = 0;
    private static final int THREE_NIGHTS_DELAY = 3;

    InnFactory factoryTest = InnTestFactory.createFactory();
    Inn inn = factoryTest.getInn();
    private final OrderRepository orderRepository = factoryTest.getOrderRepository();
    private final Pantry pantry = factoryTest.getPantry();
    private final OrderService orderService = new OrderService(inn, orderRepository, new OrderFactory());
    private final PantryResource pantryResource = new PantryResource(new PantryService(pantry));

    @Test
    void givenNoNightPassed_whenGettingPantry_thenAllThreeReservesArePresentAndEmpty() {
        PantryResponse response = getPantry();

        assertEquals(List.of(
                new ReserveResponse(FoodType.PLANT, 40, 0, List.of(), 0, 0),
                new ReserveResponse(FoodType.MEAT, 30, 0, List.of(), 0, 0),
                new ReserveResponse(FoodType.MINERAL, 100, 0, List.of(), 0, 0)), response.reserves());
    }

    @Test
    void givenOrderNotYetExecuted_whenGettingPantry_thenHasNoShipment() {
        orderService.placeOrder(FoodType.PLANT, 12, NO_DELAY);

        PantryResponse response = getPantry();

        assertEquals(List.of(), plantReserve(response).shipments());
    }

    @Test
    void givenPlantStockedAtNightOne_whenGettingPantryAtNightThree_thenStillStocked() {
        orderService.placeOrder(FoodType.PLANT, 12, NO_DELAY);
        passNights(3);

        ReserveResponse plantReserve = plantReserve(getPantry());

        assertEquals(new ReserveResponse(FoodType.PLANT, 40, 12, List.of(new ShipmentResponse(12, 1, null)), 0, 0),
                plantReserve);
    }

    @Test
    void givenPlantStockedAtNightOne_whenGettingPantryAtNightFour_thenShipmentIsDiscarded() {
        orderService.placeOrder(FoodType.PLANT, 12, NO_DELAY);
        passNights(4);

        ReserveResponse plantReserve = plantReserve(getPantry());

        assertEquals(new ReserveResponse(FoodType.PLANT, 40, 0, List.of(new ShipmentResponse(12, 1, 4)), 12, 0),
                plantReserve);
    }

    @Test
    void givenFullReserveExpiringWhenDeliveryArrives_whenGettingPantry_thenReportsOverflowAndDiscardSeparately() {
        orderService.placeOrder(FoodType.PLANT, 40, NO_DELAY);
        orderService.placeOrder(FoodType.PLANT, 10, THREE_NIGHTS_DELAY);
        passNights(4);

        ReserveResponse plantReserve = plantReserve(getPantry());

        assertEquals(new ReserveResponse(FoodType.PLANT, 40, 0, List.of(new ShipmentResponse(40, 1, 4)), 40, 10),
                plantReserve);
    }

    @Test
    void givenOverflowInPlantReserve_whenGettingPantry_thenOtherReservesAreUnaffected() {
        orderService.placeOrder(FoodType.PLANT, 50, NO_DELAY);
        passNights(1);

        PantryResponse response = getPantry();

        assertEquals(new ReserveResponse(FoodType.MEAT, 30, 0, List.of(), 0, 0), response.reserves().get(1));
    }

    private PantryResponse getPantry() {
        return (PantryResponse) pantryResource.getPantry().getEntity();
    }

    private ReserveResponse plantReserve(PantryResponse response) {
        return response.reserves().getFirst();
    }

    private void passNights(int numberOfNights) {
        for (int night = 0; night < numberOfNights; night++) {
            inn.passNight();
        }
    }
}
