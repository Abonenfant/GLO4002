package ca.ulaval.glo4002.inn.unit.infrastructure.persistence;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.subscription.Subscription;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionFactory;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRefusalReason;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionTerms;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemorySubscriptionRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class InMemorySubscriptionRepositoryTest {
    private static final String NAME = "Verger";
    private static final String SAME_NAME_IN_LOWER_CASE = "verger";
    private static final int FIRST_EXECUTION_NIGHT = 1;
    private static final int SECOND_EXECUTION_NIGHT = 2;
    private static final SubscriptionTerms VERGER_TERMS = new SubscriptionTerms(NAME, FoodType.PLANT, 5, 2);
    private static final SubscriptionFactory SUBSCRIPTION_FACTORY = new SubscriptionFactory();
    private static final Subscription FIRST_EXECUTED_SUBSCRIPTION =
            SUBSCRIPTION_FACTORY.createActiveSubscription(FIRST_EXECUTION_NIGHT, VERGER_TERMS);
    private static final Subscription SECOND_EXECUTED_SUBSCRIPTION = SUBSCRIPTION_FACTORY.createActiveSubscription(
            SECOND_EXECUTION_NIGHT, new SubscriptionTerms("Boucherie", FoodType.MEAT, 8, 4));
    private static final Subscription REFUSED_SUBSCRIPTION = SUBSCRIPTION_FACTORY.createRefusedSubscription(
            SECOND_EXECUTION_NIGHT, VERGER_TERMS, SubscriptionRefusalReason.SUBSCRIPTION_NAME_ALREADY_USED);

    private final InMemorySubscriptionRepository subscriptionRepository = new InMemorySubscriptionRepository();

    @Test
    void givenNoSavedSubscription_whenFindingAll_thenReturnsEmptyList() {
        assertTrue(subscriptionRepository.findAllInExecutionOrder().isEmpty());
    }

    @Test
    void givenSavedSubscriptions_whenFindingAll_thenReturnsThemInExecutionOrder() {
        subscriptionRepository.save(FIRST_EXECUTED_SUBSCRIPTION);
        subscriptionRepository.save(SECOND_EXECUTED_SUBSCRIPTION);

        List<Subscription> expected = List.of(FIRST_EXECUTED_SUBSCRIPTION, SECOND_EXECUTED_SUBSCRIPTION);
        assertEquals(expected, subscriptionRepository.findAllInExecutionOrder());
    }

    @Test
    void givenActiveSubscriptionWithName_whenFindingActiveByName_thenReturnsIt() {
        subscriptionRepository.save(FIRST_EXECUTED_SUBSCRIPTION);

        assertEquals(Optional.of(FIRST_EXECUTED_SUBSCRIPTION), subscriptionRepository.findActiveByName(NAME));
    }

    @Test
    void givenOnlyRefusedSubscriptionWithName_whenFindingActiveByName_thenReturnsNothing() {
        subscriptionRepository.save(REFUSED_SUBSCRIPTION);

        assertTrue(subscriptionRepository.findActiveByName(NAME).isEmpty());
    }

    @Test
    void givenNameDifferingOnlyByCase_whenFindingActiveByName_thenReturnsNothing() {
        subscriptionRepository.save(FIRST_EXECUTED_SUBSCRIPTION);

        assertTrue(subscriptionRepository.findActiveByName(SAME_NAME_IN_LOWER_CASE).isEmpty());
    }
}
