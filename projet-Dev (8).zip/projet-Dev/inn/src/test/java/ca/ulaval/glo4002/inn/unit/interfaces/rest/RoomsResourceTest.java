package ca.ulaval.glo4002.inn.unit.interfaces.rest;

import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.RoomService;
import ca.ulaval.glo4002.inn.domain.room.Atmosphere;
import ca.ulaval.glo4002.inn.domain.room.Gravity;
import ca.ulaval.glo4002.inn.domain.room.Room;
import ca.ulaval.glo4002.inn.domain.room.RoomConfiguration;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomOperation;
import ca.ulaval.glo4002.inn.domain.room.RoomRejection;
import ca.ulaval.glo4002.inn.domain.room.RoomRejectionReason;
import ca.ulaval.glo4002.inn.domain.room.Temperature;
import ca.ulaval.glo4002.inn.interfaces.resources.RoomsResource;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.requests.ReconfigureRoomRequest;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.requests.SetupRoomRequest;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.RoomRejectionResponse;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.RoomResponse;
import jakarta.ws.rs.core.Response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class RoomsResourceTest {
    private static final int ROOM_NUMBER = 1;
    private static final int CAPACITY = 2;
    private static final int REJECTED_AT_NIGHT = 5;
    private static final RoomConfiguration CONFIGURATION =
            new RoomConfiguration(Atmosphere.STANDARD, Gravity.NORMAL, Temperature.TEMPERATE);

    private final RoomService roomService = mock(RoomService.class);
    private final RoomsResource roomsResource = new RoomsResource(roomService);

    @Test
    void givenValidRequest_whenPostingRoomSetup_thenReturnsAccepted() {
        SetupRoomRequest request =
                new SetupRoomRequest(3, Atmosphere.STANDARD, Gravity.NORMAL, Temperature.TEMPERATE, 2);

        try (Response response = roomsResource.setupRoom(request)) {
            assertEquals(Response.Status.ACCEPTED.getStatusCode(), response.getStatus());
        }
    }

    @Test
    void givenValidRequest_whenPostingRoomSetup_thenDelegatesToRoomService() {
        SetupRoomRequest request =
                new SetupRoomRequest(3, Atmosphere.STANDARD, Gravity.NORMAL, Temperature.TEMPERATE, 2);

        try (Response response = roomsResource.setupRoom(request)) {
            assertNotNull(response);
            verify(roomService).requestRoomSetup(3, Atmosphere.STANDARD, Gravity.NORMAL, Temperature.TEMPERATE, 2);
        }
    }

    @Test
    void givenReconfigurationRequest_whenPuttingRoom_thenReturnsAccepted() {
        ReconfigureRoomRequest request = new ReconfigureRoomRequest(Atmosphere.HUMID, Gravity.LIGHT, Temperature.COLD, 4);

        try (Response response = roomsResource.reconfigureRoom(3, request)) {
            assertEquals(Response.Status.ACCEPTED.getStatusCode(), response.getStatus()
            );
        }
    }

    @Test
    void givenReconfigurationRequest_whenPuttingRoom_thenDelegatesToRoomService() {
        ReconfigureRoomRequest request = new ReconfigureRoomRequest(Atmosphere.HUMID, Gravity.LIGHT, Temperature.COLD, 4);

        try (Response response = roomsResource.reconfigureRoom(3, request)) {
            assertNotNull(response);verify(roomService).requestRoomReconfiguration(3, Atmosphere.HUMID, Gravity.LIGHT, Temperature.COLD, 4);
        }
    }

    @Test
    void givenNoRoom_whenGettingRooms_thenReturnsOk() {
        when(roomService.findAllRooms()).thenReturn(List.of());

        try (Response response = roomsResource.findAllRooms()) {
            assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
        }
    }

    @Test
    void givenRoom_whenGettingRooms_thenReturnsItAsResponse() {
        Room room = new Room(new RoomNumber(ROOM_NUMBER), CONFIGURATION, CAPACITY);
        when(roomService.findAllRooms()).thenReturn(List.of(room));

        try (Response response = roomsResource.findAllRooms()) {
            RoomResponse expected = new RoomResponse(ROOM_NUMBER, Atmosphere.STANDARD, Gravity.NORMAL,
                    Temperature.TEMPERATE, CAPACITY, CAPACITY, List.of());
            assertEquals(List.of(expected), response.getEntity());
        }
    }

    @Test
    void givenNoRejection_whenGettingRejections_thenReturnsOk() {
        when(roomService.findAllRejections()).thenReturn(List.of());

        try (Response response = roomsResource.findAllRejections()) {
            assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
        }
    }

    @Test
    void givenRejection_whenGettingRejections_thenReturnsItAsResponse() {
        RoomRejection rejection = new RoomRejection(new RoomNumber(ROOM_NUMBER), RoomOperation.SETUP,
                REJECTED_AT_NIGHT, RoomRejectionReason.ROOM_NUMBER_ALREADY_USED);
        when(roomService.findAllRejections()).thenReturn(List.of(rejection));

        try (Response response = roomsResource.findAllRejections()) {
            RoomRejectionResponse expected = new RoomRejectionResponse(ROOM_NUMBER, RoomOperation.SETUP,
                    REJECTED_AT_NIGHT, RoomRejectionReason.ROOM_NUMBER_ALREADY_USED);
            assertEquals(List.of(expected), response.getEntity());
        }
    }
}
