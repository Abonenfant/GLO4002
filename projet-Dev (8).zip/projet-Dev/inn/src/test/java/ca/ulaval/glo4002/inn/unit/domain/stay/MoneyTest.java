package ca.ulaval.glo4002.inn.unit.domain.stay;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.stay.Money;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MoneyTest {
    private static final int NIGHTLY_RATE_IN_PIECES = 150;
    private static final int TWO_NIGHTLY_RATES_IN_PIECES = 300;
    private static final BigDecimal NIGHTLY_RATE_IN_CENTS = new BigDecimal("150.00");

    private final Money nightlyRate = Money.ofPieces(NIGHTLY_RATE_IN_PIECES);

    @Test
    void givenPieces_whenReadingAmount_thenAmountHasTwoDecimals() {
        BigDecimal actual = nightlyRate.getAmount();

        assertEquals(NIGHTLY_RATE_IN_CENTS, actual);
    }

    @Test
    void givenZero_whenAddingAnAmount_thenResultIsThatAmount() {
        Money actual = Money.ZERO.add(nightlyRate);

        assertEquals(nightlyRate, actual);
    }

    @Test
    void givenTwoAmounts_whenAdding_thenResultIsTheirSum() {
        Money expected = Money.ofPieces(TWO_NIGHTLY_RATES_IN_PIECES);

        Money actual = nightlyRate.add(nightlyRate);

        assertEquals(expected, actual);
    }

    @Test
    void givenAmount_whenAddingAnotherAmount_thenOriginalAmountIsUnchanged() {
        Money expected = Money.ofPieces(NIGHTLY_RATE_IN_PIECES);

        nightlyRate.add(nightlyRate);

        assertEquals(expected, nightlyRate);
    }
}
