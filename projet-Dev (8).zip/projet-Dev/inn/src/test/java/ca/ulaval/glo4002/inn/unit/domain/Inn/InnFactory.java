package ca.ulaval.glo4002.inn.unit.domain.Inn;

import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.Pantry;
import ca.ulaval.glo4002.inn.domain.food.FoodFactory;
import ca.ulaval.glo4002.inn.domain.order.OrderRepository;
import ca.ulaval.glo4002.inn.domain.room.RoomDirectory;
import ca.ulaval.glo4002.inn.domain.room.RoomRepository;
import ca.ulaval.glo4002.inn.domain.stay.StayLifecycle;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryTravellerRepository;

public class InnFactory {

    private final OrderRepository orderRepository;
    private final SubscriptionRepository subscriptionRepository;
    private final RoomRepository roomRepository;
    private Pantry pantry = new Pantry(new FoodFactory());

    private final RoomDirectory roomDirectory;
    private final Inn inn;

    public InnFactory(
            OrderRepository orderRepository,
            SubscriptionRepository subscriptionRepository,
            RoomRepository roomRepository,
            Pantry pantry
    ) {
        this.orderRepository = orderRepository;
        this.subscriptionRepository = subscriptionRepository;
        this.roomRepository = roomRepository;
        this.pantry = pantry;

        this.roomDirectory = new RoomDirectory(roomRepository);
        this.inn = new Inn(orderRepository, subscriptionRepository, pantry,
                new StayLifecycle(new InMemoryTravellerRepository(), roomDirectory));
    }

    public Inn getInn() {
        return inn;
    }

    public RoomRepository getRoomRepository() {
        return roomRepository;
    }

    public RoomDirectory getRoomDirectory() {
        return roomDirectory;
    }

    public Pantry getPantry() {
        return pantry;
    }

    public OrderRepository getOrderRepository() {
        return orderRepository;
    }

    public SubscriptionRepository getSubscriptionRepository() {
        return subscriptionRepository;
    }
}
