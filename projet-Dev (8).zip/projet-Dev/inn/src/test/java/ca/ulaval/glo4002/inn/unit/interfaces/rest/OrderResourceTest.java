package ca.ulaval.glo4002.inn.unit.interfaces.rest;

import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.OrderService;
import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.order.Order;
import ca.ulaval.glo4002.inn.interfaces.resources.OrderResource;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.requests.OrderRequest;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.OrderResponse;
import jakarta.ws.rs.core.Response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class OrderResourceTest {

    private static final int QUANTITY = 12;
    private static final int DELIVERY_DELAY = 2;
    private static final OrderRequest ORDER_REQUEST = new OrderRequest(FoodType.PLANT, QUANTITY, DELIVERY_DELAY);
    private static final Order ORDER_IN_TRANSIT = new Order(FoodType.MEAT, 5, 3, 5);
    private static final int QUANTITY_ABOVE_ANY_RESERVE_CAPACITY = 10000;

    private final OrderService orderService = mock(OrderService.class);
    private final OrderResource orderResource = new OrderResource(orderService);

    @Test
    void givenOrderRequest_whenPlacingOrder_thenReturnsAccepted() {
        Response response = orderResource.placeOrder(ORDER_REQUEST);

        assertEquals(Response.Status.ACCEPTED.getStatusCode(), response.getStatus());
    }

    @Test
    void givenOrderRequest_whenPlacingOrder_thenOrderIsPlacedWithRequestValues() {
        orderResource.placeOrder(ORDER_REQUEST);

        verify(orderService).placeOrder(FoodType.PLANT, QUANTITY, DELIVERY_DELAY);
    }

    @Test
    void givenQuantityAboveReserveCapacity_whenPlacingOrder_thenStillAccepted() {
        OrderRequest hugeOrder = new OrderRequest(FoodType.PLANT, QUANTITY_ABOVE_ANY_RESERVE_CAPACITY, DELIVERY_DELAY);

        Response response = orderResource.placeOrder(hugeOrder);

        assertEquals(Response.Status.ACCEPTED.getStatusCode(), response.getStatus());
    }

    @Test
    void givenOrderInTransit_whenFindingOrders_thenReturnsItAsResponse() {
        when(orderService.findOrdersInTransit()).thenReturn(List.of(ORDER_IN_TRANSIT));

        List<OrderResponse> responses = orderResource.findOrdersInTransit();

        assertEquals(List.of(new OrderResponse(FoodType.MEAT, 5, 3, 5)), responses);
    }
}
