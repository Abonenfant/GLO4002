package ca.ulaval.glo4002.inn.integration.application;

import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.RoomService;
import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.Pantry;
import ca.ulaval.glo4002.inn.domain.food.FoodFactory;
import ca.ulaval.glo4002.inn.domain.order.OrderRepository;
import ca.ulaval.glo4002.inn.domain.room.Atmosphere;
import ca.ulaval.glo4002.inn.domain.room.Gravity;
import ca.ulaval.glo4002.inn.domain.room.Room;
import ca.ulaval.glo4002.inn.domain.room.RoomConfiguration;
import ca.ulaval.glo4002.inn.domain.room.RoomDirectory;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomOccupant;
import ca.ulaval.glo4002.inn.domain.room.RoomOperation;
import ca.ulaval.glo4002.inn.domain.room.RoomRejection;
import ca.ulaval.glo4002.inn.domain.room.RoomRejectionReason;
import ca.ulaval.glo4002.inn.domain.room.RoomRejectionRepository;
import ca.ulaval.glo4002.inn.domain.room.RoomRepository;
import ca.ulaval.glo4002.inn.domain.room.Temperature;
import ca.ulaval.glo4002.inn.domain.stay.StayLifecycle;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryOrderRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryRoomRejectionRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryRoomRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemorySubscriptionRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryTravellerRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RoomReconfigurationIT {
    private static final RoomNumber ROOM_NUMBER = new RoomNumber(42);
    private static final int INITIAL_CAPACITY = 2;
    private static final int NEW_CAPACITY = 4;

    private static final RoomConfiguration INITIAL_CONFIGURATION =
            new RoomConfiguration(
                    Atmosphere.STANDARD,
                    Gravity.NORMAL,
                    Temperature.TEMPERATE
            );

    private static final RoomConfiguration NEW_CONFIGURATION =
            new RoomConfiguration(
                    Atmosphere.HUMID,
                    Gravity.LIGHT,
                    Temperature.COLD
            );

    private final RoomRepository roomRepository =
            new InMemoryRoomRepository();
    private final RoomRejectionRepository rejectionRepository =
            new InMemoryRoomRejectionRepository();
    private final OrderRepository orderRepository =
            new InMemoryOrderRepository();
    private final SubscriptionRepository subscriptionRepository =
            new InMemorySubscriptionRepository();

    private final Inn inn =
            new Inn(
                    orderRepository,
                    subscriptionRepository,
                    new Pantry(new FoodFactory()),
                    new StayLifecycle(new InMemoryTravellerRepository(), new RoomDirectory(roomRepository))
            );

    private final RoomService roomService =
            new RoomService(
                    inn,
                    roomRepository,
                    rejectionRepository
            );

    @Test
    void givenEmptyRoom_whenReconfigurationIsExecuted_thenRoomIsUpdated() {
        Room room = saveInitialRoom();

        requestReconfiguration();

        assertRoomUnchanged(room);

        inn.passNight();

        assertEquals(NEW_CONFIGURATION, room.getConfiguration());
        assertEquals(NEW_CAPACITY, room.getCapacity());
        assertTrue(rejectionRepository.findAllInExecutionOrder().isEmpty());
    }

    @Test
    void givenUnknownRoom_whenReconfigurationIsExecuted_thenNotFoundRejectionIsSaved() {
        requestReconfiguration();

        inn.passNight();

        assertTrue(roomRepository.findByNumber(ROOM_NUMBER).isEmpty());
        assertSingleRejection(RoomRejectionReason.ROOM_NOT_FOUND);
    }

    @Test
    void givenRoomWithReservedPlace_whenReconfigurationIsExecuted_thenNotEmptyRejectionIsSaved() {
        Room room = saveInitialRoom();
        room.reservePlace(new ExistenceNumber("EX-01"));

        requestReconfiguration();
        inn.passNight();

        assertRoomUnchanged(room);
        assertSingleRejection(RoomRejectionReason.ROOM_NOT_EMPTY);
    }

    @Test
    void givenOccupiedRoom_whenReconfigurationIsExecuted_thenNotEmptyRejectionIsSaved() {
        ExistenceNumber existenceNumber =
                new ExistenceNumber("EX-01");
        Room room = saveInitialRoom();
        room.reservePlace(existenceNumber);
        room.occupyReservedPlace(
                new RoomOccupant(existenceNumber, "Aliqua")
        );

        requestReconfiguration();
        inn.passNight();

        assertRoomUnchanged(room);
        assertSingleRejection(RoomRejectionReason.ROOM_NOT_EMPTY);
    }

    @Test
    void givenSetupBeforeReconfigurationInSameNight_whenNightPasses_thenRoomIsReconfigured() {
        requestSetup();
        requestReconfiguration();

        inn.passNight();

        Room room = roomRepository.findByNumber(ROOM_NUMBER).orElseThrow();
        assertEquals(NEW_CONFIGURATION, room.getConfiguration());
        assertEquals(NEW_CAPACITY, room.getCapacity());
        assertTrue(rejectionRepository.findAllInExecutionOrder().isEmpty());
    }

    private Room saveInitialRoom() {
        Room room =
                new Room(
                        ROOM_NUMBER,
                        INITIAL_CONFIGURATION,
                        INITIAL_CAPACITY
                );
        roomRepository.save(room);
        return room;
    }

    private void requestReconfiguration() {
        roomService.requestRoomReconfiguration(
                ROOM_NUMBER.value(),
                NEW_CONFIGURATION.getAtmosphere(),
                NEW_CONFIGURATION.getGravity(),
                NEW_CONFIGURATION.getTemperature(),
                NEW_CAPACITY
        );
    }

    private void assertRoomUnchanged(Room room) {
        assertEquals(INITIAL_CONFIGURATION, room.getConfiguration());
        assertEquals(INITIAL_CAPACITY, room.getCapacity());
    }

    private void assertSingleRejection(RoomRejectionReason reason) {
        assertEquals(
                List.of(
                        new RoomRejection(
                                ROOM_NUMBER,
                                RoomOperation.RECONFIGURE,
                                inn.getCurrentNight(),
                                reason
                        )
                ),
                rejectionRepository.findAllInExecutionOrder()
        );
    }

    private void requestSetup() {
        roomService.requestRoomSetup(
                ROOM_NUMBER.value(),
                INITIAL_CONFIGURATION.getAtmosphere(),
                INITIAL_CONFIGURATION.getGravity(),
                INITIAL_CONFIGURATION.getTemperature(),
                INITIAL_CAPACITY
        );
    }
}
