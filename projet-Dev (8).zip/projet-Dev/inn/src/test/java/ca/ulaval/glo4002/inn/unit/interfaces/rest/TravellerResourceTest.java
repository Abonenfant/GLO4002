package ca.ulaval.glo4002.inn.unit.interfaces.rest;

import java.util.Optional;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.TravellerService;
import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.stay.HomeDimension;
import ca.ulaval.glo4002.inn.domain.stay.Species;
import ca.ulaval.glo4002.inn.domain.stay.StayFactory;
import ca.ulaval.glo4002.inn.domain.stay.StayPackage;
import ca.ulaval.glo4002.inn.domain.stay.StayTerms;
import ca.ulaval.glo4002.inn.domain.stay.Traveller;
import ca.ulaval.glo4002.inn.domain.stay.TravellerProfile;
import ca.ulaval.glo4002.inn.interfaces.resources.TravellerResource;
import ca.ulaval.glo4002.inn.interfaces.rest.assemblers.TravellerAssembler;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.ErrorResponse;
import jakarta.ws.rs.core.Response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class TravellerResourceTest {
    private static final String EXISTENCE_NUMBER = "EX-01";
    private static final StayTerms TERMS = new StayTerms(
            new TravellerProfile("Aliqua", Species.QUIDAM, 100, HomeDimension.SALARIA), StayPackage.COMFORT, 3);
    private static final Traveller TRAVELLER = new Traveller(
            new ExistenceNumber(EXISTENCE_NUMBER), new StayFactory().createBookedStay(1, TERMS, new RoomNumber(1)));

    private final TravellerService travellerService = mock(TravellerService.class);
    private final TravellerResource travellerResource = new TravellerResource(travellerService);

    @Test
    void givenKnownTraveller_whenFindingTraveller_thenReturnsOk() {
        givenKnownTraveller();

        try (Response response = travellerResource.findTraveller(EXISTENCE_NUMBER)) {
            assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
        }
    }

    @Test
    void givenKnownTraveller_whenFindingTraveller_thenReturnsAssembledTraveller() {
        givenKnownTraveller();

        try (Response response = travellerResource.findTraveller(EXISTENCE_NUMBER)) {
            assertEquals(TravellerAssembler.toResponse(TRAVELLER), response.getEntity());
        }
    }

    @Test
    void givenUnknownTraveller_whenFindingTraveller_thenReturnsNotFound() {
        givenUnknownTraveller();

        try (Response response = travellerResource.findTraveller(EXISTENCE_NUMBER)) {
            assertEquals(Response.Status.NOT_FOUND.getStatusCode(), response.getStatus());
        }
    }

    @Test
    void givenUnknownTraveller_whenFindingTraveller_thenReturnsTravellerNotFoundError() {
        givenUnknownTraveller();

        try (Response response = travellerResource.findTraveller(EXISTENCE_NUMBER)) {
            ErrorResponse expected = new ErrorResponse(
                    "TRAVELLER_NOT_FOUND", "traveller with existence number EX-01 not found");
            assertEquals(expected, response.getEntity());
        }
    }

    private void givenKnownTraveller() {
        when(travellerService.findTraveller(new ExistenceNumber(EXISTENCE_NUMBER))).thenReturn(Optional.of(TRAVELLER));
    }

    private void givenUnknownTraveller() {
        when(travellerService.findTraveller(new ExistenceNumber(EXISTENCE_NUMBER))).thenReturn(Optional.empty());
    }
}
