package ca.ulaval.glo4002.inn.unit.domain.stay;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.stay.Money;
import ca.ulaval.glo4002.inn.domain.stay.StayPackage;

import static org.junit.jupiter.api.Assertions.assertEquals;

class StayPackageTest {
    private static final Money ROYAL_NIGHTLY_RATE = Money.ofPieces(300);
    private static final Money COMFORT_NIGHTLY_RATE = Money.ofPieces(150);
    private static final Money MODEST_NIGHTLY_RATE = Money.ofPieces(60);

    @Test
    void givenRoyalPackage_whenReadingNightlyRate_thenIsThreeHundredPieces() {
        assertEquals(ROYAL_NIGHTLY_RATE, StayPackage.ROYAL.nightlyRate());
    }

    @Test
    void givenComfortPackage_whenReadingNightlyRate_thenIsOneHundredFiftyPieces() {
        assertEquals(COMFORT_NIGHTLY_RATE, StayPackage.COMFORT.nightlyRate());
    }

    @Test
    void givenModestPackage_whenReadingNightlyRate_thenIsSixtyPieces() {
        assertEquals(MODEST_NIGHTLY_RATE, StayPackage.MODEST.nightlyRate());
    }
}
