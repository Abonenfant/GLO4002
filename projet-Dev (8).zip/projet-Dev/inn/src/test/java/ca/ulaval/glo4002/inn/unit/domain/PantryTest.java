package ca.ulaval.glo4002.inn.unit.domain;

import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.Pantry;
import ca.ulaval.glo4002.inn.domain.food.FoodBatch;
import ca.ulaval.glo4002.inn.domain.food.FoodFactory;
import ca.ulaval.glo4002.inn.domain.food.FoodReserve;
import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.order.Order;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

class PantryTest {

    private static final int PLANT_MAX_CAPACITY = 40;
    private static final int PLANT_SHELF_LIFE = 3;
    private static final int MEAT_MAX_CAPACITY = 30;
    private static final int MEAT_SHELF_LIFE = 4;
    private static final int MINERAL_MAX_CAPACITY = 100;
    private static final int MINERAL_SHELF_LIFE = 20;

    private static final int SOME_QUANTITY = 10;
    private static final int NO_QUANTITY = 0;

    private static final int ORDERED_AT_NIGHT_ZERO = 0;

    private static final int NIGHT_ONE = 1;
    private static final int NIGHT_TWO = 2;
    private static final int NIGHT_THREE = 3;
    private static final int NIGHT_FOUR = 4;

    @Test
    void givenFullPlantReserveExpiringTonight_whenApplyingGard_thenOverflowsBeforeDiscarding() {
        Pantry pantry = new Pantry(new FoodFactory());
        FoodReserve reserve = pantry.getReserve(FoodType.PLANT);
        reserve.store(PLANT_MAX_CAPACITY, NIGHT_ONE);
        Order delivery = new Order(FoodType.PLANT, SOME_QUANTITY, NIGHT_TWO, NIGHT_FOUR);

        pantry.applyGardConsequences(List.of(delivery), NIGHT_FOUR);

        assertEquals(SOME_QUANTITY, reserve.totalOverflowed());
        assertEquals(PLANT_MAX_CAPACITY, reserve.totalDiscarded());
        assertEquals(NO_QUANTITY, reserve.stock());
    }

    @Test
    void givenOverflowInPlantReserve_whenApplyingGard_thenOtherReservesHaveNoOverflow() {
        Pantry pantry = new Pantry(new FoodFactory());
        int plantQuantity = PLANT_MAX_CAPACITY + SOME_QUANTITY;
        List<Order> deliveries = List.of(
                new Order(FoodType.PLANT, plantQuantity, ORDERED_AT_NIGHT_ZERO, NIGHT_ONE),
                new Order(FoodType.MEAT, SOME_QUANTITY, ORDERED_AT_NIGHT_ZERO, NIGHT_ONE));

        pantry.applyGardConsequences(deliveries, NIGHT_ONE);

        assertEquals(SOME_QUANTITY, pantry.getReserve(FoodType.PLANT).totalOverflowed());
        assertEquals(NO_QUANTITY, pantry.getReserve(FoodType.MEAT).totalOverflowed());
        assertEquals(NO_QUANTITY, pantry.getReserve(FoodType.MINERAL).totalOverflowed());
    }

    @Test
    void givenPastAndFutureOrders_whenApplyingGard_thenStoresOnlyTonightsDelivery() {
        Pantry pantry = new Pantry(new FoodFactory());
        List<Order> orders = List.of(
                new Order(FoodType.PLANT, 5, ORDERED_AT_NIGHT_ZERO, NIGHT_ONE),
                new Order(FoodType.PLANT, SOME_QUANTITY, ORDERED_AT_NIGHT_ZERO, NIGHT_TWO),
                new Order(FoodType.PLANT, 15, ORDERED_AT_NIGHT_ZERO, NIGHT_THREE));

        pantry.applyGardConsequences(orders, NIGHT_TWO);

        assertEquals(List.of(new FoodBatch(SOME_QUANTITY, NIGHT_TWO, null)),
                pantry.getReserve(FoodType.PLANT).stockedBatches());
    }

    @Test
    void givenNoDeliveries_whenApplyingGard_thenDiscardsExpiredStock() {
        Pantry pantry = new Pantry(new FoodFactory());
        pantry.getReserve(FoodType.PLANT).store(SOME_QUANTITY, NIGHT_ONE);

        pantry.applyGardConsequences(List.of(), NIGHT_FOUR);

        assertEquals(SOME_QUANTITY, pantry.getReserve(FoodType.PLANT).totalDiscarded());
    }

    @Test
    void givenAllFoodTypes_whenApplyingGard_thenEachUsesItsOwnShelfLife() {
        Pantry pantry = new Pantry(new FoodFactory());
        for (FoodType type : FoodType.values()) {
            pantry.getReserve(type).store(SOME_QUANTITY, NIGHT_ONE);
        }

        pantry.applyGardConsequences(List.of(), NIGHT_FOUR);

        assertEquals(SOME_QUANTITY, pantry.getReserve(FoodType.PLANT).totalDiscarded());
        assertEquals(NO_QUANTITY, pantry.getReserve(FoodType.MEAT).totalDiscarded());
        assertEquals(NO_QUANTITY, pantry.getReserve(FoodType.MINERAL).totalDiscarded());
    }

    @Test
    void givenMultipleDeliveries_whenApplyingGard_thenCapacityAppliesToTheirCombinedQuantity() {
        Pantry pantry = new Pantry(new FoodFactory());
        int firstDeliveryQuantity = 35;
        List<Order> orders = List.of(
                new Order(FoodType.PLANT, firstDeliveryQuantity, ORDERED_AT_NIGHT_ZERO, NIGHT_ONE),
                new Order(FoodType.PLANT, SOME_QUANTITY, ORDERED_AT_NIGHT_ZERO, NIGHT_ONE));

        pantry.applyGardConsequences(orders, NIGHT_ONE);

        assertEquals(List.of(new FoodBatch(firstDeliveryQuantity, NIGHT_ONE, null), new FoodBatch(5, NIGHT_ONE, null)),
                pantry.getReserve(FoodType.PLANT).stockedBatches());
    }

    @Test
    void givenNewPantry_whenGettingPlantReserve_thenReturnsPlantConfiguration() {
        Pantry pantry = new Pantry(new FoodFactory());

        FoodReserve reserve = pantry.getReserve(FoodType.PLANT);

        assertEquals(FoodType.PLANT, reserve.type());
        assertEquals(PLANT_MAX_CAPACITY, reserve.maxCapacity());
        assertEquals(PLANT_SHELF_LIFE, reserve.shelfLife());
    }

    @Test
    void givenNewPantry_whenGettingMeatReserve_thenReturnsMeatConfiguration() {
        Pantry pantry = new Pantry(new FoodFactory());

        FoodReserve reserve = pantry.getReserve(FoodType.MEAT);

        assertEquals(FoodType.MEAT, reserve.type());
        assertEquals(MEAT_MAX_CAPACITY, reserve.maxCapacity());
        assertEquals(MEAT_SHELF_LIFE, reserve.shelfLife());
    }

    @Test
    void givenNewPantry_whenGettingMineralReserve_thenReturnsMineralConfiguration() {
        Pantry pantry = new Pantry(new FoodFactory());

        FoodReserve reserve = pantry.getReserve(FoodType.MINERAL);

        assertEquals(FoodType.MINERAL, reserve.type());
        assertEquals(MINERAL_MAX_CAPACITY, reserve.maxCapacity());
        assertEquals(MINERAL_SHELF_LIFE, reserve.shelfLife());
    }

    @Test
    void givenNewPantry_whenGettingReserves_thenReturnsAllThreeReservesInFoodTypeOrder() {
        Pantry pantry = new Pantry(new FoodFactory());

        List<FoodReserve> reserves = pantry.getReserves();

        assertEquals(List.of(FoodType.PLANT, FoodType.MEAT, FoodType.MINERAL),
                reserves.stream().map(FoodReserve::type).toList());
    }

    @Test
    void givenPantry_whenModifyingReturnedReserves_thenProtectsPantry() {
        Pantry pantry = new Pantry(new FoodFactory());

        assertThrows(UnsupportedOperationException.class, () -> pantry.getReserves().clear());
    }

    @Test
    void givenPantry_whenGettingSameFoodTypeTwice_thenReturnsSameReserve() {
        Pantry pantry = new Pantry(new FoodFactory());

        FoodReserve firstReserve = pantry.getReserve(FoodType.PLANT);
        FoodReserve secondReserve = pantry.getReserve(FoodType.PLANT);

        assertSame(firstReserve, secondReserve);
    }

    @Test
    void givenPantry_whenGettingDifferentFoodTypes_thenReturnsDistinctReserves() {
        Pantry pantry = new Pantry(new FoodFactory());

        FoodReserve plantReserve = pantry.getReserve(FoodType.PLANT);
        FoodReserve meatReserve = pantry.getReserve(FoodType.MEAT);
        FoodReserve mineralReserve = pantry.getReserve(FoodType.MINERAL);

        assertNotSame(plantReserve, meatReserve);
        assertNotSame(plantReserve, mineralReserve);
        assertNotSame(meatReserve, mineralReserve);
    }
}
