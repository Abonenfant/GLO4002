package ca.ulaval.glo4002.inn.unit.domain.stay;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.room.Atmosphere;
import ca.ulaval.glo4002.inn.domain.room.Gravity;
import ca.ulaval.glo4002.inn.domain.room.RoomConfiguration;
import ca.ulaval.glo4002.inn.domain.room.Temperature;
import ca.ulaval.glo4002.inn.domain.stay.Species;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SpeciesTest {
    @Test
    void givenQuidam_whenReadingRequiredConfiguration_thenReturnsStandardNormalTemperate() {
        RoomConfiguration expected =
                new RoomConfiguration(Atmosphere.STANDARD, Gravity.NORMAL, Temperature.TEMPERATE);

        assertEquals(expected, Species.QUIDAM.requiredConfiguration());
    }

    @Test
    void givenPyrophore_whenReadingRequiredConfiguration_thenReturnsStandardNormalHot() {
        RoomConfiguration expected =
                new RoomConfiguration(Atmosphere.STANDARD, Gravity.NORMAL, Temperature.HOT);

        assertEquals(expected, Species.PYROPHORE.requiredConfiguration());
    }

    @Test
    void givenPlantagenet_whenReadingRequiredConfiguration_thenReturnsHumidNormalHot() {
        RoomConfiguration expected =
                new RoomConfiguration(Atmosphere.HUMID, Gravity.NORMAL, Temperature.HOT);

        assertEquals(expected, Species.PLANTAGENET.requiredConfiguration());
    }

    @Test
    void givenMerfolk_whenReadingRequiredConfiguration_thenReturnsHumidLightCold() {
        RoomConfiguration expected =
                new RoomConfiguration(Atmosphere.HUMID, Gravity.LIGHT, Temperature.COLD);

        assertEquals(expected, Species.MERFOLK.requiredConfiguration());
    }

    @Test
    void givenMenhir_whenReadingRequiredConfiguration_thenReturnsStandardHeavyCold() {
        RoomConfiguration expected =
                new RoomConfiguration(Atmosphere.STANDARD, Gravity.HEAVY, Temperature.COLD);

        assertEquals(expected, Species.MENHIR.requiredConfiguration());
    }
}
