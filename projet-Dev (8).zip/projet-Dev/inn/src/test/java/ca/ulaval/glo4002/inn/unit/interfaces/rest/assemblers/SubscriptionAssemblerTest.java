package ca.ulaval.glo4002.inn.unit.interfaces.rest.assemblers;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.subscription.Subscription;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionFactory;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRefusalReason;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionTerms;
import ca.ulaval.glo4002.inn.interfaces.rest.assemblers.SubscriptionAssembler;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.requests.SubscriptionRequest;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.SubscriptionResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SubscriptionAssemblerTest {
    private static final String NAME = "Verger";
    private static final int QUANTITY = 5;
    private static final int PERIOD = 2;

    private static final int CURRENT_NIGHT = 1;
    private static final int SUBSCRIBED_AT_NIGHT = 1;
    private static final SubscriptionTerms TERMS = new SubscriptionTerms(NAME, FoodType.PLANT, QUANTITY, PERIOD);

    @Test
    void givenSubscriptionRequest_whenAssemblingTerms_thenTermsHaveRequestValues() {
        SubscriptionRequest request = new SubscriptionRequest(NAME, FoodType.PLANT, QUANTITY, PERIOD);

        SubscriptionTerms terms = SubscriptionAssembler.toSubscriptionTerms(request);

        assertEquals(new SubscriptionTerms(NAME, FoodType.PLANT, QUANTITY, PERIOD), terms);
    }

    @Test
    void givenActiveSubscription_whenAssemblingResponse_thenResponseHasSubscriptionValues() {
        Subscription subscription = new SubscriptionFactory().createActiveSubscription(SUBSCRIBED_AT_NIGHT, TERMS);

        SubscriptionResponse response = SubscriptionAssembler.toResponse(subscription, CURRENT_NIGHT);

        assertEquals(new SubscriptionResponse(NAME, "PLANT", QUANTITY, PERIOD, "ACTIVE", null, 3), response);
    }

    @Test
    void givenRefusedSubscription_whenAssemblingResponse_thenHasRefusalReasonAndNoNextDelivery() {
        Subscription subscription = new SubscriptionFactory().createRefusedSubscription(
                SUBSCRIBED_AT_NIGHT, TERMS, SubscriptionRefusalReason.SUBSCRIPTION_NAME_ALREADY_USED);

        SubscriptionResponse response = SubscriptionAssembler.toResponse(subscription, CURRENT_NIGHT);

        assertEquals(new SubscriptionResponse(NAME, "PLANT", QUANTITY, PERIOD, "REFUSED",
                "SUBSCRIPTION_NAME_ALREADY_USED", null), response);
    }

    @Test
    void givenCancelledSubscription_whenAssemblingResponse_thenReturnsExpectedResponse() {
        Subscription subscription = new SubscriptionFactory().createActiveSubscription(SUBSCRIBED_AT_NIGHT, TERMS);
        subscription.cancel();

        SubscriptionResponse response = SubscriptionAssembler.toResponse(subscription, CURRENT_NIGHT);

        assertEquals(new SubscriptionResponse(NAME, "PLANT", QUANTITY, PERIOD, "CANCELLED",
                null, null), response);
    }
}
