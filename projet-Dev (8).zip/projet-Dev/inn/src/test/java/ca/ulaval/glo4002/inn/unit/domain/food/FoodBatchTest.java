package ca.ulaval.glo4002.inn.unit.domain.food;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.food.FoodBatch;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class FoodBatchTest {
    private static final int QUANTITY = 10;
    private static final int STOCKED_NIGHT = 1;
    private static final int DISCARDED_NIGHT = 4;

    @Test
    void givenSameValues_whenComparingBatches_thenTheyAreEqual() {
        FoodBatch batch = new FoodBatch(QUANTITY, STOCKED_NIGHT, DISCARDED_NIGHT);
        FoodBatch sameBatch = new FoodBatch(QUANTITY, STOCKED_NIGHT, DISCARDED_NIGHT);

        assertEquals(batch, sameBatch);
    }

    @Test
    void givenDifferentQuantities_whenComparingBatches_thenTheyAreNotEqual() {
        FoodBatch batch = new FoodBatch(QUANTITY, STOCKED_NIGHT, null);
        FoodBatch differentBatch = new FoodBatch(QUANTITY + 1, STOCKED_NIGHT, null);

        assertNotEquals(batch, differentBatch);
    }

    @Test
    void givenDifferentStockingNights_whenComparingBatches_thenTheyAreNotEqual() {
        FoodBatch batch = new FoodBatch(QUANTITY, STOCKED_NIGHT, null);
        FoodBatch differentBatch = new FoodBatch(QUANTITY, STOCKED_NIGHT + 1, null);

        assertNotEquals(batch, differentBatch);
    }

    @Test
    void givenDifferentDiscardNights_whenComparingBatches_thenTheyAreNotEqual() {
        FoodBatch batch = new FoodBatch(QUANTITY, STOCKED_NIGHT, DISCARDED_NIGHT);
        FoodBatch differentBatch = new FoodBatch(QUANTITY, STOCKED_NIGHT, DISCARDED_NIGHT + 1);

        assertNotEquals(batch, differentBatch);
    }

    @Test
    void givenStoredAndDiscardedBatches_whenComparing_thenTheyAreNotEqual() {
        FoodBatch batch = new FoodBatch(QUANTITY, STOCKED_NIGHT, null);

        FoodBatch discardedBatch = new FoodBatch(QUANTITY, STOCKED_NIGHT, DISCARDED_NIGHT);

        assertNotEquals(batch, discardedBatch);
    }

    @Test
    void givenBatchInHashSet_whenLookingUpEqualBatch_thenFindsIt() {
        Set<FoodBatch> batches = new HashSet<>();
        batches.add(new FoodBatch(QUANTITY, STOCKED_NIGHT, null));

        boolean containsBatch = batches.contains(new FoodBatch(QUANTITY, STOCKED_NIGHT, null));

        assertTrue(containsBatch);
    }
}
