package ca.ulaval.glo4002.inn.integration.application;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.SubscriptionService;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.food.FoodBatch;
import ca.ulaval.glo4002.inn.domain.food.FoodReserve;
import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.subscription.Subscription;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionFactory;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRepository;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionStatus;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionTerms;
import ca.ulaval.glo4002.inn.unit.domain.Inn.InnFactory;
import ca.ulaval.glo4002.inn.unit.domain.Inn.InnTestFactory;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SameNightCancellationIT {
    private static final String NAME = "Carrière";
    private static final int QUANTITY = 8;
    private static final int PERIOD = 4;
    private static final int SUBSCRIPTION_NIGHT = 1;
    private static final int FIRST_DELIVERY_NIGHT = SUBSCRIPTION_NIGHT + PERIOD;
    private static final int SCHEDULED_DELIVERY_NIGHT = FIRST_DELIVERY_NIGHT + PERIOD;
    private static final int NIGHT_BEFORE_SCHEDULED_DELIVERY = SCHEDULED_DELIVERY_NIGHT - 1;
    private static final SubscriptionTerms TERMS = new SubscriptionTerms(NAME, FoodType.MINERAL, QUANTITY, PERIOD);
    private static final FoodBatch FIRST_DELIVERY = new FoodBatch(QUANTITY, FIRST_DELIVERY_NIGHT, null);
    private static final FoodBatch SCHEDULED_DELIVERY = new FoodBatch(QUANTITY, SCHEDULED_DELIVERY_NIGHT, null);

    InnFactory factoryTest = InnTestFactory.createFactory();
    Inn inn = factoryTest.getInn();
    private final SubscriptionRepository subscriptionRepository = factoryTest.getSubscriptionRepository();
    private final SubscriptionService subscriptionService =
            new SubscriptionService(inn, subscriptionRepository, new SubscriptionFactory());
    private final FoodReserve mineralReserve = inn.getPantry().getReserve(FoodType.MINERAL);

    @Test
    void givenUnsubscriptionPendingBeforeDeliveryNight_whenDeliveryNightPasses_thenSubscriptionIsCancelled() {
        givenUnsubscriptionPendingBeforeScheduledDeliveryNight();

        inn.passNight();

        assertEquals(SubscriptionStatus.CANCELLED, cancelledSubscription().getStatus());
    }

    @Test
    void givenUnsubscriptionPendingBeforeDeliveryNight_whenDeliveryNightPasses_thenNoDeliveryIsStored() {
        givenUnsubscriptionPendingBeforeScheduledDeliveryNight();

        inn.passNight();

        assertEquals(List.of(FIRST_DELIVERY), mineralReserve.stockedBatches());
    }

    @Test
    void givenUnsubscriptionPendingBeforeDeliveryNight_whenDeliveryNightPasses_thenNoNextDeliveryIsScheduled() {
        givenUnsubscriptionPendingBeforeScheduledDeliveryNight();

        inn.passNight();

        assertEquals(Optional.empty(), cancelledSubscription().nextDeliveryNightAfter(inn.getCurrentNight()));
    }

    @Test
    void givenUnsubscriptionRequestedAfterDeliveryNight_whenNextNightPasses_thenDeliveryOfThatNightIsKept() {
        givenActiveSubscriptionUntil(SCHEDULED_DELIVERY_NIGHT);
        subscriptionService.unsubscribe(NAME);

        inn.passNight();

        assertEquals(List.of(FIRST_DELIVERY, SCHEDULED_DELIVERY), mineralReserve.stockedBatches());
    }

    private void givenUnsubscriptionPendingBeforeScheduledDeliveryNight() {
        givenActiveSubscriptionUntil(NIGHT_BEFORE_SCHEDULED_DELIVERY);
        subscriptionService.unsubscribe(NAME);
    }

    private void givenActiveSubscriptionUntil(int night) {
        subscriptionService.subscribe(TERMS);
        passNightsUntil(night);
    }

    private Subscription cancelledSubscription() {
        return subscriptionRepository.findAllInExecutionOrder().getFirst();
    }

    private void passNightsUntil(int night) {
        while (inn.getCurrentNight() < night) {
            inn.passNight();
        }
    }
}
