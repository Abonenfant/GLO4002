package ca.ulaval.glo4002.inn.unit.domain.action;

import java.util.Optional;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.action.ReconfigureRoomAction;
import ca.ulaval.glo4002.inn.domain.room.Atmosphere;
import ca.ulaval.glo4002.inn.domain.room.Gravity;
import ca.ulaval.glo4002.inn.domain.room.Room;
import ca.ulaval.glo4002.inn.domain.room.RoomConfiguration;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomOccupant;
import ca.ulaval.glo4002.inn.domain.room.RoomOperation;
import ca.ulaval.glo4002.inn.domain.room.RoomRejectionReason;
import ca.ulaval.glo4002.inn.domain.room.RoomRejectionRepository;
import ca.ulaval.glo4002.inn.domain.room.RoomRepository;
import ca.ulaval.glo4002.inn.domain.room.Temperature;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.same;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

class ReconfigureRoomActionTest {
    private static final RoomNumber ROOM_NUMBER = new RoomNumber(42);
    private static final int INITIAL_CAPACITY = 2;
    private static final int NEW_CAPACITY = 4;
    private static final int EXECUTION_NIGHT = 5;
    private static final ExistenceNumber EXISTENCE_NUMBER =
            new ExistenceNumber("EX-4417-Q");

    private static final RoomConfiguration INITIAL_CONFIGURATION =
            new RoomConfiguration(
                    Atmosphere.STANDARD,
                    Gravity.NORMAL,
                    Temperature.TEMPERATE
            );

    private static final RoomConfiguration NEW_CONFIGURATION =
            new RoomConfiguration(
                    Atmosphere.HUMID,
                    Gravity.LIGHT,
                    Temperature.COLD
            );

    private final RoomRepository roomRepository = mock(RoomRepository.class);
    private final RoomRejectionRepository rejectionRepository =
            mock(RoomRejectionRepository.class);

    private final ReconfigureRoomAction action =
            new ReconfigureRoomAction(
                    roomRepository,
                    rejectionRepository,
                    ROOM_NUMBER,
                    NEW_CONFIGURATION,
                    NEW_CAPACITY
            );

    @Test
    void givenEmptyRoom_whenExecuted_thenRoomIsReconfigured() {
        Room room = new Room(
                ROOM_NUMBER,
                INITIAL_CONFIGURATION,
                INITIAL_CAPACITY
        );
        when(roomRepository.findByNumber(ROOM_NUMBER))
                .thenReturn(Optional.of(room));

        action.execute(EXECUTION_NIGHT);

        assertEquals(NEW_CONFIGURATION, room.getConfiguration());
        assertEquals(NEW_CAPACITY, room.getCapacity());
        verify(roomRepository).save(same(room));
        verifyNoInteractions(rejectionRepository);
    }

    @Test
    void givenUnknownRoom_whenExecuted_thenRoomNotFoundRejectionIsSaved() {
        when(roomRepository.findByNumber(ROOM_NUMBER))
                .thenReturn(Optional.empty());

        action.execute(EXECUTION_NIGHT);

        verifyRejection(RoomRejectionReason.ROOM_NOT_FOUND);
        verify(roomRepository, never()).save(any(Room.class));
    }

    @Test
    void givenRoomWithReservedPlace_whenExecuted_thenRoomNotEmptyRejectionIsSaved() {
        Room room = new Room(
                ROOM_NUMBER,
                INITIAL_CONFIGURATION,
                INITIAL_CAPACITY
        );
        room.reservePlace(EXISTENCE_NUMBER);
        when(roomRepository.findByNumber(ROOM_NUMBER))
                .thenReturn(Optional.of(room));

        action.execute(EXECUTION_NIGHT);

        assertRoomWasNotModified(room);
        verifyRejection(RoomRejectionReason.ROOM_NOT_EMPTY);
        verify(roomRepository, never()).save(any(Room.class));
    }

    @Test
    void givenOccupiedRoom_whenExecuted_thenRoomNotEmptyRejectionIsSaved() {
        Room room = new Room(
                ROOM_NUMBER,
                INITIAL_CONFIGURATION,
                INITIAL_CAPACITY
        );
        room.reservePlace(EXISTENCE_NUMBER);
        room.occupyReservedPlace(
                new RoomOccupant(EXISTENCE_NUMBER, "Aliqua")
        );
        when(roomRepository.findByNumber(ROOM_NUMBER))
                .thenReturn(Optional.of(room));

        action.execute(EXECUTION_NIGHT);

        assertRoomWasNotModified(room);
        verifyRejection(RoomRejectionReason.ROOM_NOT_EMPTY);
        verify(roomRepository, never()).save(any(Room.class));
    }

    private void verifyRejection(RoomRejectionReason reason) {
        verify(rejectionRepository).save(argThat(rejection ->
                rejection.getRoomNumber().equals(ROOM_NUMBER)
                        && rejection.getOperation() == RoomOperation.RECONFIGURE
                        && rejection.getRejectedAtNight() == EXECUTION_NIGHT
                        && rejection.getReason() == reason
        ));
    }

    private void assertRoomWasNotModified(Room room) {
        assertEquals(INITIAL_CONFIGURATION, room.getConfiguration());
        assertEquals(INITIAL_CAPACITY, room.getCapacity());
    }
}
