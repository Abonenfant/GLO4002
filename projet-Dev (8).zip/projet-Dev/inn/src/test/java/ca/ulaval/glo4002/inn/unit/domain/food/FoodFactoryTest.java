package ca.ulaval.glo4002.inn.unit.domain.food;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.food.FoodBatch;
import ca.ulaval.glo4002.inn.domain.food.FoodFactory;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class FoodFactoryTest {
    private static final int QUANTITY = 10;
    private static final int STOCKED_NIGHT = 1;
    private static final int DISCARDED_NIGHT = 4;

    private final FoodFactory foodFactory = new FoodFactory();

    @Test
    void givenQuantityAndNight_whenCreatingStockedBatch_thenPreservesStockingDetails() {
        FoodBatch batch = foodFactory.createStockedBatch(QUANTITY, STOCKED_NIGHT);

        assertEquals(new FoodBatch(QUANTITY, STOCKED_NIGHT, null), batch);
    }

    @Test
    void givenStockedBatch_whenCreatingDiscardedBatch_thenPreservesQuantity() {
        FoodBatch batch = new FoodBatch(QUANTITY, STOCKED_NIGHT, null);

        FoodBatch discardedBatch = foodFactory.createDiscardedBatch(batch, DISCARDED_NIGHT);

        assertEquals(QUANTITY, discardedBatch.getPortionCount());
    }

    @Test
    void givenStockedBatch_whenCreatingDiscardedBatch_thenPreservesStockingNight() {
        FoodBatch batch = new FoodBatch(QUANTITY, STOCKED_NIGHT, null);

        FoodBatch discardedBatch = foodFactory.createDiscardedBatch(batch, DISCARDED_NIGHT);

        assertEquals(STOCKED_NIGHT, discardedBatch.getStockingNight());
    }

    @Test
    void givenStockedBatch_whenCreatingDiscardedBatch_thenRecordsDiscardNight() {
        FoodBatch batch = new FoodBatch(QUANTITY, STOCKED_NIGHT, null);

        FoodBatch discardedBatch = foodFactory.createDiscardedBatch(batch, DISCARDED_NIGHT);

        assertEquals(DISCARDED_NIGHT, discardedBatch.getActualDiscardNight());
    }

    @Test
    void givenStockedBatch_whenCreatingDiscardedBatch_thenOriginalBatchRemainsUnchanged() {
        FoodBatch batch = new FoodBatch(QUANTITY, STOCKED_NIGHT, null);

        foodFactory.createDiscardedBatch(batch, DISCARDED_NIGHT);

        assertNull(batch.getActualDiscardNight());
    }
}
