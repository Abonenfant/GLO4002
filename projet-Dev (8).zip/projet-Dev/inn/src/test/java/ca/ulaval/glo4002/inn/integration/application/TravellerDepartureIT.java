package ca.ulaval.glo4002.inn.integration.application;

import java.util.Optional;

import org.glassfish.hk2.api.ServiceLocator;
import org.glassfish.hk2.utilities.ServiceLocatorUtilities;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.StayService;
import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.room.Room;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomOccupant;
import ca.ulaval.glo4002.inn.domain.room.RoomRepository;
import ca.ulaval.glo4002.inn.domain.stay.HomeDimension;
import ca.ulaval.glo4002.inn.domain.stay.Species;
import ca.ulaval.glo4002.inn.domain.stay.Stay;
import ca.ulaval.glo4002.inn.domain.stay.StayFactory;
import ca.ulaval.glo4002.inn.domain.stay.StayPackage;
import ca.ulaval.glo4002.inn.domain.stay.StayRefusalReason;
import ca.ulaval.glo4002.inn.domain.stay.StayStatus;
import ca.ulaval.glo4002.inn.domain.stay.StayTerms;
import ca.ulaval.glo4002.inn.domain.stay.Traveller;
import ca.ulaval.glo4002.inn.domain.stay.TravellerProfile;
import ca.ulaval.glo4002.inn.domain.stay.TravellerRepository;
import ca.ulaval.glo4002.inn.interfaces.configuration.ApplicationBinder;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TravellerDepartureIT {
    private static final ExistenceNumber DEPARTING_EXISTENCE_NUMBER = new ExistenceNumber("EX-01");
    private static final ExistenceNumber NEWCOMER_EXISTENCE_NUMBER = new ExistenceNumber("EX-02");
    private static final TravellerProfile DEPARTING_PROFILE =
            new TravellerProfile("Aliqua", Species.QUIDAM, 100, HomeDimension.SALARIA);
    private static final TravellerProfile NEWCOMER_PROFILE =
            new TravellerProfile("Cyd", Species.QUIDAM, 80, HomeDimension.NOCTAMBULIE);
    private static final RoomNumber ROOM_NUMBER = new RoomNumber(1);
    private static final int SINGLE_PLACE = 1;
    private static final int RESERVATION_NIGHT = 1;
    private static final int FIRST_NIGHT = 2;
    private static final int LAST_NIGHT = 4;
    private static final int NIGHTS = 3;

    private final ServiceLocator serviceLocator = ServiceLocatorUtilities.bind(new ApplicationBinder());
    private final StayService stayService = serviceLocator.getService(StayService.class);
    private final Inn inn = serviceLocator.getService(Inn.class);
    private final TravellerRepository travellerRepository = serviceLocator.getService(TravellerRepository.class);
    private final RoomRepository roomRepository = serviceLocator.getService(RoomRepository.class);
    private final Room room = new Room(ROOM_NUMBER, Species.QUIDAM.requiredConfiguration(), SINGLE_PLACE);

    @BeforeEach
    void setUp() {
        roomRepository.save(room);
        Stay stay = new StayFactory().createBookedStay(
                RESERVATION_NIGHT, new StayTerms(DEPARTING_PROFILE, StayPackage.COMFORT, NIGHTS), ROOM_NUMBER);
        Traveller departingTraveller = new Traveller(DEPARTING_EXISTENCE_NUMBER, stay);
        travellerRepository.save(departingTraveller);
        room.reservePlace(DEPARTING_EXISTENCE_NUMBER);
        departingTraveller.arrive(FIRST_NIGHT);
        room.occupyReservedPlace(new RoomOccupant(DEPARTING_EXISTENCE_NUMBER, DEPARTING_PROFILE.name()));
    }

    @AfterEach
    void tearDown() {
        serviceLocator.shutdown();
    }

    @Test
    void givenActiveStay_whenItsLastNightPasses_thenStayIsEnded() {
        passNightsUntil(LAST_NIGHT);

        assertEquals(StayStatus.ENDED, latestStayOf(DEPARTING_EXISTENCE_NUMBER).getStatus());
    }

    @Test
    void givenActiveStay_whenNightBeforeItsLastNightPasses_thenStayIsStillActive() {
        passNightsUntil(LAST_NIGHT - 1);

        assertEquals(StayStatus.ACTIVE, latestStayOf(DEPARTING_EXISTENCE_NUMBER).getStatus());
    }

    @Test
    void givenActiveStay_whenItsLastNightPasses_thenItsPlaceIsFreed() {
        passNightsUntil(LAST_NIGHT);

        assertEquals(SINGLE_PLACE, room.getFreePlaces());
    }

    @Test
    void givenBookingForTheOnlyPlaceOnTheLastNight_whenLastNightPasses_thenBookingIsRefused() {
        passNightsUntil(LAST_NIGHT - 1);
        stayService.bookStay(NEWCOMER_EXISTENCE_NUMBER, NEWCOMER_PROFILE, StayPackage.COMFORT, NIGHTS);

        inn.passNight();

        assertEquals(Optional.of(StayRefusalReason.NO_COMPATIBLE_ROOM),
                latestStayOf(NEWCOMER_EXISTENCE_NUMBER).getRefusalReason());
    }

    @Test
    void givenBookingForTheFreedPlaceTheNightAfter_whenNightPasses_thenBookingIsAccepted() {
        passNightsUntil(LAST_NIGHT);
        stayService.bookStay(NEWCOMER_EXISTENCE_NUMBER, NEWCOMER_PROFILE, StayPackage.COMFORT, NIGHTS);

        inn.passNight();

        assertEquals(StayStatus.BOOKED, latestStayOf(NEWCOMER_EXISTENCE_NUMBER).getStatus());
    }

    private Stay latestStayOf(ExistenceNumber existenceNumber) {
        return travellerRepository.findByExistenceNumber(existenceNumber).orElseThrow().getLatestStay();
    }

    private void passNightsUntil(int night) {
        while (inn.getCurrentNight() < night) {
            inn.passNight();
        }
    }
}
