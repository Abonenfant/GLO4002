package ca.ulaval.glo4002.inn.unit.interfaces.rest.assemblers;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomOperation;
import ca.ulaval.glo4002.inn.domain.room.RoomRejection;
import ca.ulaval.glo4002.inn.domain.room.RoomRejectionReason;
import ca.ulaval.glo4002.inn.interfaces.rest.assemblers.RoomRejectionAssembler;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.RoomRejectionResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;

class RoomRejectionAssemblerTest {
    private static final int ROOM_NUMBER = 3;
    private static final int REJECTED_AT_NIGHT = 5;

    @Test
    void givenSetupRejectedBecauseNumberIsUsed_whenAssemblingResponse_thenExposesSetupAndRoomNumberAlreadyUsed() {
        RoomRejection rejection = rejectionOf(RoomOperation.SETUP, RoomRejectionReason.ROOM_NUMBER_ALREADY_USED);

        RoomRejectionResponse response = RoomRejectionAssembler.toResponse(rejection);

        RoomRejectionResponse expected = new RoomRejectionResponse(ROOM_NUMBER, RoomOperation.SETUP,
                REJECTED_AT_NIGHT, RoomRejectionReason.ROOM_NUMBER_ALREADY_USED);
        assertEquals(expected, response);
    }

    @Test
    void givenReconfigurationRejectedBecauseRoomIsMissing_whenAssemblingResponse_thenExposesReconfigureAndRoomNotFound() {
        RoomRejection rejection = rejectionOf(RoomOperation.RECONFIGURE, RoomRejectionReason.ROOM_NOT_FOUND);

        RoomRejectionResponse response = RoomRejectionAssembler.toResponse(rejection);

        RoomRejectionResponse expected = new RoomRejectionResponse(ROOM_NUMBER, RoomOperation.RECONFIGURE,
                REJECTED_AT_NIGHT, RoomRejectionReason.ROOM_NOT_FOUND);
        assertEquals(expected, response);
    }

    @Test
    void givenReconfigurationRejectedBecauseRoomIsOccupied_whenAssemblingResponse_thenExposesReconfigureAndRoomNotEmpty() {
        RoomRejection rejection = rejectionOf(RoomOperation.RECONFIGURE, RoomRejectionReason.ROOM_NOT_EMPTY);

        RoomRejectionResponse response = RoomRejectionAssembler.toResponse(rejection);

        RoomRejectionResponse expected = new RoomRejectionResponse(ROOM_NUMBER, RoomOperation.RECONFIGURE,
                REJECTED_AT_NIGHT, RoomRejectionReason.ROOM_NOT_EMPTY);
        assertEquals(expected, response);
    }

    private RoomRejection rejectionOf(RoomOperation operation, RoomRejectionReason reason) {
        return new RoomRejection(new RoomNumber(ROOM_NUMBER), operation, REJECTED_AT_NIGHT, reason);
    }
}
