package ca.ulaval.glo4002.inn.unit.interfaces.rest.dto;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.order.Order;
import ca.ulaval.glo4002.inn.interfaces.rest.assemblers.OrderAssembler;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.OrderResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class OrderResponseTest {
    private static final Order ORDER = new Order(FoodType.PLANT, 12, 3, 5);

    @Test
    void givenOrder_whenConverted_thenResponseHasSameValues() {
        OrderResponse response = OrderAssembler.toResponse(ORDER);

        assertEquals(new OrderResponse(FoodType.PLANT, 12, 3, 5), response);
    }
}
