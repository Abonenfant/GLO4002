package ca.ulaval.glo4002.inn.integration.application;

import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.RoomService;
import ca.ulaval.glo4002.inn.application.StayService;
import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.Pantry;
import ca.ulaval.glo4002.inn.domain.food.FoodFactory;
import ca.ulaval.glo4002.inn.domain.order.OrderRepository;
import ca.ulaval.glo4002.inn.domain.room.Atmosphere;
import ca.ulaval.glo4002.inn.domain.room.Gravity;
import ca.ulaval.glo4002.inn.domain.room.Room;
import ca.ulaval.glo4002.inn.domain.room.RoomAssignmentPolicy;
import ca.ulaval.glo4002.inn.domain.room.RoomDirectory;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomOperation;
import ca.ulaval.glo4002.inn.domain.room.RoomRejection;
import ca.ulaval.glo4002.inn.domain.room.RoomRejectionReason;
import ca.ulaval.glo4002.inn.domain.room.RoomRejectionRepository;
import ca.ulaval.glo4002.inn.domain.room.Temperature;
import ca.ulaval.glo4002.inn.domain.stay.HomeDimension;
import ca.ulaval.glo4002.inn.domain.stay.Species;
import ca.ulaval.glo4002.inn.domain.stay.StayFactory;
import ca.ulaval.glo4002.inn.domain.stay.StayLifecycle;
import ca.ulaval.glo4002.inn.domain.stay.StayPackage;
import ca.ulaval.glo4002.inn.domain.stay.StayTerms;
import ca.ulaval.glo4002.inn.domain.stay.TravellerProfile;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryOrderRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryRoomRejectionRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryRoomRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemorySubscriptionRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryTravellerRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RoomSetupAndBookingIT {

    private static final int ROOM_NUMBER = 3;
    private static final int CAPACITY = 2;
    private static final ExistenceNumber EXISTENCE_NUMBER = new ExistenceNumber("42");

    private final OrderRepository orderRepository = new InMemoryOrderRepository();
    private final SubscriptionRepository subscriptionRepository = new InMemorySubscriptionRepository();
    private final RoomRejectionRepository roomRejectionRepository = new InMemoryRoomRejectionRepository();
    private final Pantry pantry = new Pantry(new FoodFactory());
    private final InMemoryRoomRepository roomRepository = new InMemoryRoomRepository();
    private final RoomDirectory roomDirectory = new RoomDirectory(roomRepository);

    private final InMemoryTravellerRepository travellerRepository = new InMemoryTravellerRepository();
    private final Inn inn = new Inn(orderRepository, subscriptionRepository, pantry,
            new StayLifecycle(travellerRepository, roomDirectory));

    private final StayFactory stayFactory = new StayFactory();
    private final RoomAssignmentPolicy roomAssignmentPolicy = new RoomAssignmentPolicy();

    private final RoomService roomService = new RoomService(inn, roomRepository, roomRejectionRepository);
    private final StayService stayService = new StayService(
            inn,
            travellerRepository,
            stayFactory,
            roomAssignmentPolicy,
            roomDirectory
    );

    @Test
    void givenRoomSetupAndBookingInSameNight_whenNightPasses_thenBookingUsesNewlyCreatedRoomFifo() {
        assertTrue(roomRepository.findAll().isEmpty());

        roomService.requestRoomSetup(
                ROOM_NUMBER,
                Atmosphere.STANDARD,
                Gravity.NORMAL,
                Temperature.TEMPERATE,
                CAPACITY
        );

        StayTerms terms = new StayTerms(
                new TravellerProfile("John", Species.QUIDAM, 80, HomeDimension.HYLEE),
                StayPackage.MODEST,
                1
        );
        stayService.bookStay(EXISTENCE_NUMBER, terms);

        assertThrows(NoSuchElementException.class,
                () -> roomDirectory.findExistingRoom(new RoomNumber(ROOM_NUMBER)));

        inn.passNight();

        Room createdRoom = roomDirectory.findExistingRoom(new RoomNumber(ROOM_NUMBER));
        assertTrue(createdRoom.getReservedExistenceNumbers().contains(EXISTENCE_NUMBER));
    }

    @Test
    void givenTwoRoomSetupRequestsSameNumber_whenNightPasses_thenFirstCreatesRoomAndSecondCreatesRejection() {
        roomService.requestRoomSetup(
                ROOM_NUMBER,
                Atmosphere.STANDARD,
                Gravity.NORMAL,
                Temperature.TEMPERATE,
                CAPACITY
        );

        roomService.requestRoomSetup(
                ROOM_NUMBER,
                Atmosphere.HUMID,
                Gravity.HEAVY,
                Temperature.COLD,
                99
        );

        inn.passNight();

        Room room = roomDirectory.findExistingRoom(new RoomNumber(ROOM_NUMBER));
        assertNotNull(room);
        assertEquals(CAPACITY, room.getCapacity());
        assertEquals(Atmosphere.STANDARD, room.getConfiguration().getAtmosphere());
        assertEquals(Gravity.NORMAL, room.getConfiguration().getGravity());
        assertEquals(Temperature.TEMPERATE, room.getConfiguration().getTemperature());

        assertEquals(1, roomRejectionRepository.findAllInExecutionOrder().size());
        RoomRejection rejection = roomRejectionRepository.findAllInExecutionOrder().getFirst();

        assertEquals(new RoomNumber(ROOM_NUMBER), rejection.getRoomNumber());
        assertEquals(RoomOperation.SETUP, rejection.getOperation());
        assertEquals(RoomRejectionReason.ROOM_NUMBER_ALREADY_USED, rejection.getReason());
    }
}
