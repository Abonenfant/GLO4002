package ca.ulaval.glo4002.inn.unit.interfaces.rest.assemblers;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.room.Atmosphere;
import ca.ulaval.glo4002.inn.domain.room.Gravity;
import ca.ulaval.glo4002.inn.domain.room.Room;
import ca.ulaval.glo4002.inn.domain.room.RoomConfiguration;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomOccupant;
import ca.ulaval.glo4002.inn.domain.room.Temperature;
import ca.ulaval.glo4002.inn.interfaces.rest.assemblers.RoomAssembler;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.OccupantResponse;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.RoomResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RoomAssemblerTest {
    private static final int ROOM_NUMBER = 1;
    private static final int CAPACITY = 2;
    private static final RoomConfiguration CONFIGURATION =
            new RoomConfiguration(Atmosphere.STANDARD, Gravity.NORMAL, Temperature.TEMPERATE);
    private static final ExistenceNumber SMALLER_EXISTENCE_NUMBER = new ExistenceNumber("EX-100");
    private static final ExistenceNumber GREATER_EXISTENCE_NUMBER = new ExistenceNumber("EX-99");
    private static final String NAME_LAST_IN_ALPHABET = "Zeta";
    private static final String NAME_FIRST_IN_ALPHABET = "Aliqua";

    private Room room;

    @BeforeEach
    void setUp() {
        room = new Room(new RoomNumber(ROOM_NUMBER), CONFIGURATION, CAPACITY);
    }

    @Test
    void givenEmptyRoom_whenAssemblingResponse_thenExposesRoomWithAllPlacesFree() {
        RoomResponse response = RoomAssembler.toResponse(room);

        RoomResponse expected = new RoomResponse(ROOM_NUMBER, Atmosphere.STANDARD, Gravity.NORMAL,
                Temperature.TEMPERATE, CAPACITY, CAPACITY, List.of());
        assertEquals(expected, response);
    }

    @Test
    void givenReservedPlace_whenAssemblingResponse_thenPlaceIsTakenButTravellerIsNotAnOccupant() {
        room.reservePlace(GREATER_EXISTENCE_NUMBER);

        RoomResponse response = RoomAssembler.toResponse(room);

        assertEquals(CAPACITY - 1, response.freePlaces());
        assertTrue(response.occupants().isEmpty());
    }

    @Test
    void givenRoomFilledByOccupantAndReservation_whenAssemblingResponse_thenHasNoFreePlace() {
        arrive(GREATER_EXISTENCE_NUMBER, NAME_FIRST_IN_ALPHABET);
        room.reservePlace(SMALLER_EXISTENCE_NUMBER);

        RoomResponse response = RoomAssembler.toResponse(room);

        assertEquals(0, response.freePlaces());
    }

    @Test
    void givenOccupantsArrivedInDisorder_whenAssemblingResponse_thenOccupantsAreSortedByExistenceNumber() {
        arrive(GREATER_EXISTENCE_NUMBER, NAME_FIRST_IN_ALPHABET);
        arrive(SMALLER_EXISTENCE_NUMBER, NAME_LAST_IN_ALPHABET);

        RoomResponse response = RoomAssembler.toResponse(room);

        List<OccupantResponse> expected = List.of(
                new OccupantResponse(SMALLER_EXISTENCE_NUMBER.value(), NAME_LAST_IN_ALPHABET),
                new OccupantResponse(GREATER_EXISTENCE_NUMBER.value(), NAME_FIRST_IN_ALPHABET));
        assertEquals(expected, response.occupants());
    }

    private void arrive(ExistenceNumber existenceNumber, String travellerName) {
        room.reservePlace(existenceNumber);
        room.occupyReservedPlace(new RoomOccupant(existenceNumber, travellerName));
    }
}
