package ca.ulaval.glo4002.inn.integration.interfaces;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.Pantry;
import ca.ulaval.glo4002.inn.domain.food.FoodFactory;
import ca.ulaval.glo4002.inn.domain.order.OrderRepository;
import ca.ulaval.glo4002.inn.domain.room.RoomRepository;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRepository;
import ca.ulaval.glo4002.inn.interfaces.resources.InnResource;
import ca.ulaval.glo4002.inn.interfaces.rest.mappers.InnMapper;
import ca.ulaval.glo4002.inn.unit.domain.Inn.InnFactory;
import jakarta.ws.rs.core.Response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

public class InnResourceIT {
    private static final int OK_RESPONSE_CODE = 200;

    private Inn inn;
    private InnMapper mapper;
    private InnResource innResource;

    @BeforeEach
    void setup() {
        InnFactory factory = new InnFactory(
                mock(OrderRepository.class),
                mock(SubscriptionRepository.class),
                mock(RoomRepository.class),
                new Pantry(new FoodFactory())
        );

        inn = factory.getInn();
        mapper = new InnMapper();
        innResource = new InnResource(inn, mapper);
    }

    @Test
    void givenInn_whenPostPassNightRequest_thenTransactionSuccessful() {
        Response response = innResource.passNight();
        assertEquals(OK_RESPONSE_CODE, response.getStatus());
    }

    @Test
    void givenInn_whenGetInn_thenTransactionSuccessful() {
        Response response = innResource.getInnInfo();
        assertEquals(OK_RESPONSE_CODE, response.getStatus());
    }
}
