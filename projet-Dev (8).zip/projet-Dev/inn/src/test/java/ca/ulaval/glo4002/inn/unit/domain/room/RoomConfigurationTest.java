package ca.ulaval.glo4002.inn.unit.domain.room;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.room.Atmosphere;
import ca.ulaval.glo4002.inn.domain.room.Gravity;
import ca.ulaval.glo4002.inn.domain.room.RoomConfiguration;
import ca.ulaval.glo4002.inn.domain.room.Temperature;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RoomConfigurationTest {
    private static final RoomConfiguration CONFIGURATION =
            new RoomConfiguration(Atmosphere.STANDARD, Gravity.NORMAL, Temperature.TEMPERATE);

    @Test
    void givenSameSettings_whenComparingConfigurations_thenTheyAreEqual() {
        RoomConfiguration sameConfiguration =
                new RoomConfiguration(Atmosphere.STANDARD, Gravity.NORMAL, Temperature.TEMPERATE);

        assertEquals(CONFIGURATION, sameConfiguration);
    }

    @Test
    void givenDifferentAtmosphere_whenComparingConfigurations_thenTheyAreNotEqual() {
        RoomConfiguration differentConfiguration =
                new RoomConfiguration(Atmosphere.HUMID, Gravity.NORMAL, Temperature.TEMPERATE);

        assertNotEquals(CONFIGURATION, differentConfiguration);
    }

    @Test
    void givenConfigurationInHashSet_whenLookingUpEqualConfiguration_thenFindsIt() {
        Set<RoomConfiguration> configurations = new HashSet<>();
        configurations.add(CONFIGURATION);

        RoomConfiguration equalConfiguration =
                new RoomConfiguration(Atmosphere.STANDARD, Gravity.NORMAL, Temperature.TEMPERATE);

        assertTrue(configurations.contains(equalConfiguration));
    }
}
