package ca.ulaval.glo4002.inn.unit.interfaces.rest.assemblers;

import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.food.FoodFactory;
import ca.ulaval.glo4002.inn.domain.food.FoodReserve;
import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.interfaces.rest.assemblers.PantryAssembler;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.PantryResponse;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.ReserveResponse;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.ShipmentResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PantryAssemblerTest {
    private static final int PLANT_MAX_CAPACITY = 40;
    private static final int STOCKED_AT_NIGHT = 1;
    private static final int DISCARDED_AT_NIGHT = 4;
    private static final int EXPIRED_QUANTITY = 30;
    private static final int FRESH_QUANTITY = 25;
    private static final int OVERFLOWED_QUANTITY = 5;

    @Test
    void givenEmptyReserve_whenAssemblingResponse_thenHasCapacityAndNoShipment() {
        FoodReserve reserve = new FoodReserve(FoodType.MEAT, new FoodFactory());

        PantryResponse response = PantryAssembler.toResponse(List.of(reserve));

        assertEquals(new PantryResponse(List.of(new ReserveResponse(FoodType.MEAT, 30, 0, List.of(), 0, 0))), response);
    }

    @Test
    void givenReserveWithDiscardedOverflowedAndStockedPortions_whenAssemblingResponse_thenReportsEachSeparately() {
        FoodReserve reserve = new FoodReserve(FoodType.PLANT, new FoodFactory());
        reserve.store(EXPIRED_QUANTITY, STOCKED_AT_NIGHT);
        reserve.discardExpiredAt(DISCARDED_AT_NIGHT);
        reserve.store(PLANT_MAX_CAPACITY + OVERFLOWED_QUANTITY, DISCARDED_AT_NIGHT);
        reserve.discardExpiredAt(DISCARDED_AT_NIGHT);

        PantryResponse response = PantryAssembler.toResponse(List.of(reserve));

        List<ShipmentResponse> expectedShipments = List.of(
                new ShipmentResponse(EXPIRED_QUANTITY, STOCKED_AT_NIGHT, DISCARDED_AT_NIGHT),
                new ShipmentResponse(PLANT_MAX_CAPACITY, DISCARDED_AT_NIGHT, null));
        ReserveResponse expectedReserve = new ReserveResponse(FoodType.PLANT, PLANT_MAX_CAPACITY, PLANT_MAX_CAPACITY,
                expectedShipments, EXPIRED_QUANTITY, OVERFLOWED_QUANTITY);
        assertEquals(new PantryResponse(List.of(expectedReserve)), response);
    }

    @Test
    void givenSeveralReserves_whenAssemblingResponse_thenKeepsReserveOrder() {
        List<FoodReserve> reserves = List.of(
                new FoodReserve(FoodType.MINERAL, new FoodFactory()),
                new FoodReserve(FoodType.PLANT, new FoodFactory()));

        PantryResponse response = PantryAssembler.toResponse(reserves);

        assertEquals(List.of(FoodType.MINERAL, FoodType.PLANT),
                response.reserves().stream().map(ReserveResponse::foodType).toList());
    }

    @Test
    void givenFreshBatch_whenAssemblingResponse_thenShipmentHasNoDiscardNight() {
        FoodReserve reserve = new FoodReserve(FoodType.PLANT, new FoodFactory());
        reserve.store(FRESH_QUANTITY, STOCKED_AT_NIGHT);

        PantryResponse response = PantryAssembler.toResponse(List.of(reserve));

        assertEquals(List.of(new ShipmentResponse(FRESH_QUANTITY, STOCKED_AT_NIGHT, null)),
                response.reserves().getFirst().shipments());
    }
}
