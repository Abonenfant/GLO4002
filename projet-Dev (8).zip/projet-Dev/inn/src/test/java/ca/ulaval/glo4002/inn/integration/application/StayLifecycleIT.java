package ca.ulaval.glo4002.inn.integration.application;

import java.util.List;

import org.glassfish.hk2.api.ServiceLocator;
import org.glassfish.hk2.utilities.ServiceLocatorUtilities;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.RoomService;
import ca.ulaval.glo4002.inn.application.StayService;
import ca.ulaval.glo4002.inn.application.TravellerService;
import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.room.Room;
import ca.ulaval.glo4002.inn.domain.room.RoomConfiguration;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomOccupant;
import ca.ulaval.glo4002.inn.domain.room.RoomRepository;
import ca.ulaval.glo4002.inn.domain.stay.HomeDimension;
import ca.ulaval.glo4002.inn.domain.stay.Money;
import ca.ulaval.glo4002.inn.domain.stay.Species;
import ca.ulaval.glo4002.inn.domain.stay.Stay;
import ca.ulaval.glo4002.inn.domain.stay.StayPackage;
import ca.ulaval.glo4002.inn.domain.stay.StayStatus;
import ca.ulaval.glo4002.inn.domain.stay.TravellerProfile;
import ca.ulaval.glo4002.inn.interfaces.configuration.ApplicationBinder;
import ca.ulaval.glo4002.inn.interfaces.resources.TravellerResource;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.TravellerResponse;
import jakarta.ws.rs.core.Response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class StayLifecycleIT {
    private static final ExistenceNumber EXISTENCE_NUMBER = new ExistenceNumber("EX-01");
    private static final String NAME = "Aliqua";
    private static final TravellerProfile PROFILE = new TravellerProfile(NAME, Species.QUIDAM, 100, HomeDimension.SALARIA);
    private static final RoomNumber ROOM_NUMBER = new RoomNumber(1);
    private static final int CAPACITY = 1;
    private static final int NIGHTS = 3;
    private static final Money ONE_NIGHT_AMOUNT = Money.ofPieces(150);
    private static final Money TWO_NIGHTS_AMOUNT = Money.ofPieces(300);
    private static final Money THREE_NIGHTS_AMOUNT = Money.ofPieces(450);

    private final ServiceLocator serviceLocator = ServiceLocatorUtilities.bind(new ApplicationBinder());
    private final Inn inn = serviceLocator.getService(Inn.class);
    private final RoomService roomService = serviceLocator.getService(RoomService.class);
    private final StayService stayService = serviceLocator.getService(StayService.class);
    private final TravellerService travellerService = serviceLocator.getService(TravellerService.class);
    private final RoomRepository roomRepository = serviceLocator.getService(RoomRepository.class);
    private final TravellerResource travellerResource = new TravellerResource(travellerService);

    @AfterEach
    void tearDown() {
        serviceLocator.shutdown();
    }

    @Test
    void givenThreeNightBooking_whenNightsPass_thenStayCompletesAndRemainsConsultable() {
        RoomConfiguration configuration = PROFILE.species().requiredConfiguration();
        roomService.requestRoomSetup(ROOM_NUMBER.value(), configuration.getAtmosphere(), configuration.getGravity(),
                configuration.getTemperature(), CAPACITY);
        stayService.bookStay(EXISTENCE_NUMBER, PROFILE, StayPackage.COMFORT, NIGHTS);

        inn.passNight();

        Room room = roomRepository.findByNumber(ROOM_NUMBER).orElseThrow();
        assertEquals(StayStatus.BOOKED, latestStay().getStatus());
        assertEquals(Money.ZERO, latestStay().getTotalBilledAmount());
        assertEquals(0, room.getFreePlaces());
        assertTrue(room.getOccupants().isEmpty());

        inn.passNight();

        assertEquals(StayStatus.ACTIVE, latestStay().getStatus());
        assertEquals(ONE_NIGHT_AMOUNT, latestStay().getTotalBilledAmount());
        assertEquals(List.of(new RoomOccupant(EXISTENCE_NUMBER, NAME)), room.getOccupants());
        assertTrue(room.getReservedExistenceNumbers().isEmpty());

        inn.passNight();

        assertEquals(StayStatus.ACTIVE, latestStay().getStatus());
        assertEquals(TWO_NIGHTS_AMOUNT, latestStay().getTotalBilledAmount());

        inn.passNight();

        assertEquals(StayStatus.ENDED, latestStay().getStatus());
        assertEquals(THREE_NIGHTS_AMOUNT, latestStay().getTotalBilledAmount());
        assertEquals(CAPACITY, room.getFreePlaces());
        assertTrue(room.isEmpty());

        inn.passNight();

        assertEquals(THREE_NIGHTS_AMOUNT, latestStay().getTotalBilledAmount());
        try (Response response = travellerResource.findTraveller(EXISTENCE_NUMBER.value())) {
            assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
            TravellerResponse traveller = (TravellerResponse) response.getEntity();
            assertEquals(1, traveller.stays().size());
            assertEquals(StayStatus.ENDED, traveller.stays().getFirst().status());
            assertEquals(THREE_NIGHTS_AMOUNT.getAmount(),
                    traveller.stays().getFirst().totalBilledAmount());
        }
    }

    private Stay latestStay() {
        return travellerService.findTraveller(EXISTENCE_NUMBER)
                .orElseThrow().getLatestStay();
    }
}
