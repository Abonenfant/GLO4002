package ca.ulaval.glo4002.inn.unit.application;

import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.PantryService;
import ca.ulaval.glo4002.inn.domain.Pantry;
import ca.ulaval.glo4002.inn.domain.food.FoodFactory;
import ca.ulaval.glo4002.inn.domain.food.FoodReserve;
import ca.ulaval.glo4002.inn.domain.food.FoodType;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class PantryServiceTest {
    private final Pantry pantry = mock(Pantry.class);
    private final PantryService pantryService = new PantryService(pantry);

    @Test
    void givenPantryReserves_whenFindingReserves_thenReturnsPantryReserves() {
        List<FoodReserve> reserves = List.of(new FoodReserve(FoodType.PLANT, new FoodFactory()));
        when(pantry.getReserves()).thenReturn(reserves);

        List<FoodReserve> foundReserves = pantryService.findReserves();

        assertEquals(reserves, foundReserves);
    }
}
