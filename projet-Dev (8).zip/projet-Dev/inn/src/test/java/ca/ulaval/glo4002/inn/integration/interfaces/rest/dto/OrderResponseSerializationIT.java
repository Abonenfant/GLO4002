package ca.ulaval.glo4002.inn.integration.interfaces.rest.dto;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.OrderResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;

class OrderResponseSerializationIT {
    private static final String EXPECTED_JSON =
            "{\"foodType\":\"PLANT\",\"quantity\":12,\"orderedAtNight\":3,\"deliveryNight\":5}";

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    void givenResponse_whenSerialized_thenJsonMatchesApiContract() throws Exception {
        final int quantity = 12;
        final int orderedOnNight3 = 3;
        final int deliveredOnNight5 = 5;
        OrderResponse response = new OrderResponse(FoodType.PLANT, quantity, orderedOnNight3, deliveredOnNight5);

        JsonNode json = objectMapper.valueToTree(response);

        assertEquals(objectMapper.readTree(EXPECTED_JSON), json);
    }
}
