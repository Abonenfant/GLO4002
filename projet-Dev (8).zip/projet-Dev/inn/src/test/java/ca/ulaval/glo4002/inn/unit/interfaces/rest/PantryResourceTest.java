package ca.ulaval.glo4002.inn.unit.interfaces.rest;

import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.PantryService;
import ca.ulaval.glo4002.inn.domain.food.FoodFactory;
import ca.ulaval.glo4002.inn.domain.food.FoodReserve;
import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.interfaces.resources.PantryResource;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.PantryResponse;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.ReserveResponse;
import jakarta.ws.rs.core.Response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class PantryResourceTest {
    private final PantryService pantryService = mock(PantryService.class);
    private final PantryResource pantryResource = new PantryResource(pantryService);

    @Test
    void givenPantry_whenGettingPantry_thenReturnsOk() {
        when(pantryService.findReserves()).thenReturn(List.of());

        Response response = pantryResource.getPantry();

        assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
    }

    @Test
    void givenReserve_whenGettingPantry_thenReturnsItAsResponse() {
        when(pantryService.findReserves()).thenReturn(List.of(new FoodReserve(FoodType.PLANT, new FoodFactory())));

        Response response = pantryResource.getPantry();

        PantryResponse expected = new PantryResponse(List.of(new ReserveResponse(FoodType.PLANT, 40, 0, List.of(), 0, 0)));
        assertEquals(expected, response.getEntity());
    }
}
