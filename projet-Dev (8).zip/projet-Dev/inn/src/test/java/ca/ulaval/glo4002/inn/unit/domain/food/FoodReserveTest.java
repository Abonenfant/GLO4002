package ca.ulaval.glo4002.inn.unit.domain.food;

import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.food.FoodBatch;
import ca.ulaval.glo4002.inn.domain.food.FoodFactory;
import ca.ulaval.glo4002.inn.domain.food.FoodReserve;
import ca.ulaval.glo4002.inn.domain.food.FoodType;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class FoodReserveTest {
    private final FoodReserve reserve = new FoodReserve(FoodType.PLANT, new FoodFactory());

    @Test
    void givenEachFoodType_whenDeliveryExceedsCapacity_thenStoresOnlyItsCapacity() {
        for (FoodType type : FoodType.values()) {
            FoodReserve foodReserve = new FoodReserve(type, new FoodFactory());

            foodReserve.store(type.maxCapacity() + 1, 1);

            assertEquals(type.maxCapacity(), foodReserve.stock(), type.name());
        }
    }

    @Test
    void givenEachFoodType_whenSortingBeforeExpiry_thenKeepsStock() {
        for (FoodType type : FoodType.values()) {
            FoodReserve foodReserve = new FoodReserve(type, new FoodFactory());
            foodReserve.store(10, 1);

            foodReserve.discardExpiredAt(type.shelfLife());

            assertEquals(10, foodReserve.stock(), type.name());
        }
    }

    @Test
    void givenEachFoodType_whenSortingAtExpiry_thenDiscardsStock() {
        for (FoodType type : FoodType.values()) {
            FoodReserve foodReserve = new FoodReserve(type, new FoodFactory());
            foodReserve.store(10, 1);

            foodReserve.discardExpiredAt(1 + type.shelfLife());

            assertEquals(10, foodReserve.totalDiscarded(), type.name());
        }
    }

    @Test
    void givenStoredBatch_whenModifyingReturnedBatches_thenProtectsReserveStock() {
        reserve.store(10, 1);

        assertThrows(UnsupportedOperationException.class, () -> reserve.stockedBatches().clear());
    }

    @Test
    void givenEmptyReserve_whenStoringDelivery_thenStoresEntireQuantity() {
        reserve.store(10, 1);

        assertEquals(10, reserve.stock());
    }

    @Test
    void givenPartiallyFullReserve_whenStoringDelivery_thenDoesNotExceedCapacity() {
        reserve.store(35, 1);

        reserve.store(10, 2);

        assertEquals(40, reserve.stock());
    }

    @Test
    void givenPartiallyFullReserve_whenStoringDelivery_thenRecordsOnlyStoredQuantityAndItsNight() {
        reserve.store(35, 1);

        reserve.store(10, 2);

        assertEquals(new FoodBatch(5, 2, null), reserve.stockedBatches().getLast());
    }

    @Test
    void givenPartiallyFullReserve_whenStoringDelivery_thenCountsOnlyUnstoredQuantity() {
        reserve.store(35, 1);

        reserve.store(10, 2);

        assertEquals(5, reserve.totalOverflowed());
    }

    @Test
    void givenExistingBatch_whenStoringDelivery_thenPreservesExistingBatch() {
        reserve.store(35, 1);
        FoodBatch originalBatch = reserve.stockedBatches().getFirst();

        reserve.store(10, 2);

        assertEquals(originalBatch, reserve.stockedBatches().getFirst());
    }

    @Test
    void givenFullReserve_whenStoringDelivery_thenCreatesNoEmptyBatch() {
        reserve.store(40, 1);
        List<FoodBatch> originalBatches = reserve.stockedBatches();

        reserve.store(10, 2);

        assertEquals(originalBatches, reserve.stockedBatches());
    }

    @Test
    void givenRepeatedOverflow_whenStoringDeliveries_thenAccumulatesOverflow() {
        reserve.store(35, 1);

        reserve.store(10, 2);
        reserve.store(7, 3);

        assertEquals(12, reserve.totalOverflowed());
    }

    @Test
    void givenEnoughCapacity_whenStoringDelivery_thenDoesNotCountOverflow() {
        reserve.store(40, 1);

        assertEquals(0, reserve.totalOverflowed());
    }

    @Test
    void givenZeroQuantity_whenStoringDelivery_thenCreatesNoBatch() {
        reserve.store(0, 1);

        assertEquals(List.of(), reserve.stockedBatches());
    }

    @Test
    void givenNegativeQuantity_whenStoringDelivery_thenRejectsDelivery() {
        assertThrows(IllegalArgumentException.class, () -> reserve.store(-1, 1));
    }

    @Test
    void givenPlantStockedAtNightOne_whenSortingNightOne_thenKeepsStock() {
        reserve.store(10, 1);

        reserve.discardExpiredAt(1);

        assertEquals(10, reserve.stock());
    }

    @Test
    void givenPlantStockedAtNightOne_whenSortingNightTwo_thenKeepsStock() {
        reserve.store(10, 1);

        reserve.discardExpiredAt(2);

        assertEquals(10, reserve.stock());
    }

    @Test
    void givenPlantStockedAtNightOne_whenSortingNightThree_thenKeepsStock() {
        reserve.store(10, 1);

        reserve.discardExpiredAt(3);

        assertEquals(10, reserve.stock());
    }

    @Test
    void givenPlantStockedAtNightOne_whenSortingNightFour_thenRemovesStock() {
        reserve.store(10, 1);

        reserve.discardExpiredAt(4);

        assertEquals(0, reserve.stock());
    }

    @Test
    void givenExpiredBatch_whenSorting_thenRecordsDiscardNightAndOriginalStockingNight() {
        reserve.store(10, 1);

        reserve.discardExpiredAt(4);

        assertEquals(List.of(new FoodBatch(10, 1, 4)), reserve.discardedBatches());
    }

    @Test
    void givenExpiredBatch_whenSorting_thenCountsDiscardedPortions() {
        reserve.store(10, 1);

        reserve.discardExpiredAt(4);

        assertEquals(10, reserve.totalDiscarded());
    }

    @Test
    void givenDifferentStockingNights_whenSorting_thenKeepsOnlyFreshBatch() {
        reserve.store(10, 1);
        reserve.store(5, 2);

        reserve.discardExpiredAt(4);

        assertEquals(List.of(new FoodBatch(5, 2, null)), reserve.stockedBatches());
    }

    @Test
    void givenSuccessiveExpirations_whenSorting_thenAccumulatesDiscardedPortions() {
        reserve.store(10, 1);
        reserve.store(5, 2);

        reserve.discardExpiredAt(4);
        reserve.discardExpiredAt(5);

        assertEquals(15, reserve.totalDiscarded());
    }

    @Test
    void givenAlreadyDiscardedBatch_whenSortingAgain_thenDoesNotCountItTwice() {
        reserve.store(10, 1);
        reserve.discardExpiredAt(4);

        reserve.discardExpiredAt(4);
        reserve.discardExpiredAt(5);

        assertEquals(10, reserve.totalDiscarded());
    }

    @Test
    void givenOverdueBatch_whenSorting_thenRecordsActualDiscardNight() {
        reserve.store(10, 1);

        reserve.discardExpiredAt(6);

        assertEquals(List.of(new FoodBatch(10, 1, 6)), reserve.discardedBatches());
    }

    @Test
    void givenPartialDelivery_whenExpiring_thenDiscardsOnlyStoredPortions() {
        reserve.store(35, 1);
        reserve.store(10, 2);
        reserve.discardExpiredAt(4);

        reserve.discardExpiredAt(5);

        assertEquals(40, reserve.totalDiscarded());
    }

    @Test
    void givenEmptyReserve_whenListingShipments_thenHasNone() {
        assertEquals(List.of(), reserve.shipments());
    }

    @Test
    void givenDiscardedAndStockedBatches_whenListingShipments_thenIncludesBothInStockingOrder() {
        reserve.store(10, 1);
        reserve.store(5, 2);
        reserve.discardExpiredAt(4);
        reserve.store(7, 4);

        List<FoodBatch> shipments = reserve.shipments();

        assertEquals(List.of(new FoodBatch(10, 1, 4), new FoodBatch(5, 2, null), new FoodBatch(7, 4, null)), shipments);
    }

    @Test
    void givenOverflowedDelivery_whenListingShipments_thenIncludesOnlyStoredPortions() {
        reserve.store(40, 1);
        reserve.store(10, 2);

        assertEquals(List.of(new FoodBatch(40, 1, null)), reserve.shipments());
    }

    @Test
    void givenDiscardedStock_whenStoringNewDelivery_thenCapacityIsAvailableAgain() {
        reserve.store(40, 1);
        reserve.discardExpiredAt(4);

        reserve.store(40, 4);

        assertEquals(40, reserve.stock());
    }
}
