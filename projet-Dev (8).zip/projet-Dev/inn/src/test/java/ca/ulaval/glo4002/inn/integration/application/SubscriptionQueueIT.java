package ca.ulaval.glo4002.inn.integration.application;

import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.SubscriptionService;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.subscription.Subscription;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionFactory;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRepository;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionTerms;
import ca.ulaval.glo4002.inn.unit.domain.Inn.InnFactory;
import ca.ulaval.glo4002.inn.unit.domain.Inn.InnTestFactory;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SubscriptionQueueIT {
    private static final String NAME = "Verger";
    private static final SubscriptionTerms TERMS = new SubscriptionTerms(NAME, FoodType.PLANT, 5, 2);

    InnFactory factoryTest = InnTestFactory.createFactory();
    Inn inn = factoryTest.getInn();
    private final SubscriptionRepository subscriptionRepository = factoryTest.getSubscriptionRepository();
    private final SubscriptionService subscriptionService =
            new SubscriptionService(inn, subscriptionRepository, new SubscriptionFactory());

    @Test
    void givenSubscriptionRequested_whenNoNightHasPassed_thenSubscriptionDoesNotExistYet() {
        subscriptionService.subscribe(TERMS);

        assertTrue(subscriptionRepository.findAllInExecutionOrder().isEmpty());
    }

    @Test
    void givenSubscriptionRequested_whenNoNightHasPassed_thenNothingIsDelivered() {
        subscriptionService.subscribe(TERMS);

        assertEquals(0, inn.getPantry().getReserve(FoodType.PLANT).stock());
    }

    @Test
    void givenSubscriptionRequested_whenNightPasses_thenSubscriptionExists() {
        subscriptionService.subscribe(TERMS);

        inn.passNight();

        List<Subscription> subscriptions = subscriptionRepository.findAllInExecutionOrder();
        assertEquals(List.of(NAME), subscriptions.stream().map(Subscription::getName).toList());
    }
}
