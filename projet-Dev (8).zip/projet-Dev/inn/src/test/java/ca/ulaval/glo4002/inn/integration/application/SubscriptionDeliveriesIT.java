package ca.ulaval.glo4002.inn.integration.application;

import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.OrderService;
import ca.ulaval.glo4002.inn.application.SubscriptionService;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.food.FoodBatch;
import ca.ulaval.glo4002.inn.domain.food.FoodReserve;
import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.order.OrderFactory;
import ca.ulaval.glo4002.inn.domain.order.OrderRepository;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionFactory;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRepository;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionTerms;
import ca.ulaval.glo4002.inn.unit.domain.Inn.InnFactory;
import ca.ulaval.glo4002.inn.unit.domain.Inn.InnTestFactory;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SubscriptionDeliveriesIT {
    private static final int QUANTITY = 5;
    private static final int PERIOD = 2;
    private static final int ORDER_QUANTITY = 7;
    private static final int SUBSCRIPTION_NIGHT = 1;
    private static final int FIRST_DELIVERY_NIGHT = SUBSCRIPTION_NIGHT + PERIOD;
    private static final int SECOND_DELIVERY_NIGHT = FIRST_DELIVERY_NIGHT + PERIOD;
    private static final SubscriptionTerms TERMS = new SubscriptionTerms("Carrière", FoodType.MINERAL, QUANTITY, PERIOD);

    InnFactory factoryTest = InnTestFactory.createFactory();
    Inn inn = factoryTest.getInn();
    private final OrderRepository orderRepository = factoryTest.getOrderRepository();
    private final SubscriptionRepository subscriptionRepository = factoryTest.getSubscriptionRepository();

    private final OrderService orderService =
            new OrderService(inn, orderRepository, new OrderFactory());
    private final SubscriptionService subscriptionService =
            new SubscriptionService(inn, subscriptionRepository, new SubscriptionFactory());
    private final FoodReserve mineralReserve = inn.getPantry().getReserve(FoodType.MINERAL);

    @Test
    void givenSubscriptionExecutedTonight_whenNightEnds_thenNothingIsStored() {
        subscriptionService.subscribe(TERMS);

        passNightsUntil(SUBSCRIPTION_NIGHT);

        assertEquals(0, mineralReserve.stock());
    }

    @Test
    void givenSubscription_whenOnePeriodHasPassed_thenQuantityIsStoredOnDeliveryNight() {
        subscriptionService.subscribe(TERMS);

        passNightsUntil(FIRST_DELIVERY_NIGHT);

        assertEquals(List.of(new FoodBatch(QUANTITY, FIRST_DELIVERY_NIGHT, null)), mineralReserve.stockedBatches());
    }

    @Test
    void givenSubscription_whenTwoPeriodsHavePassed_thenQuantityIsStoredAgain() {
        subscriptionService.subscribe(TERMS);

        passNightsUntil(SECOND_DELIVERY_NIGHT);

        List<FoodBatch> expected = List.of(new FoodBatch(QUANTITY, FIRST_DELIVERY_NIGHT, null),
            new FoodBatch(QUANTITY, SECOND_DELIVERY_NIGHT, null));
        assertEquals(expected, mineralReserve.stockedBatches());
    }

    @Test
    void givenOrderAndSubscriptionDeliveredSameNight_whenNightPasses_thenBothAreStored() {
        subscriptionService.subscribe(TERMS);
        orderService.placeOrder(FoodType.MINERAL, ORDER_QUANTITY, PERIOD);

        passNightsUntil(FIRST_DELIVERY_NIGHT);

        assertEquals(ORDER_QUANTITY + QUANTITY, mineralReserve.stock());
    }

    private void passNightsUntil(int night) {
        while (inn.getCurrentNight() < night) {
            inn.passNight();
        }
    }
}
