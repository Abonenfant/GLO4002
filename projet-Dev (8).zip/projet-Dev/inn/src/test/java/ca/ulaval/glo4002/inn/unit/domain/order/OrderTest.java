package ca.ulaval.glo4002.inn.unit.domain.order;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.order.Order;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class OrderTest {

    private static final int QUANTITY = 12;
    private static final int ORDERED_AT_NIGHT = 3;
    private static final int DELIVERY_NIGHT = 5;

    private final Order order = new Order(FoodType.PLANT, QUANTITY, ORDERED_AT_NIGHT, DELIVERY_NIGHT);

    @Test
    void givenNightBeforeDeliveryNight_whenCheckingTransit_thenIsInTransit() {
        assertTrue(order.isInTransitOnNight(DELIVERY_NIGHT - 1));
    }

    @Test
    void givenDeliveryNight_whenCheckingTransit_thenIsNotInTransit() {
        assertFalse(order.isInTransitOnNight(DELIVERY_NIGHT));
    }

    @Test
    void givenNightAfterDeliveryNight_whenCheckingTransit_thenIsNotInTransit() {
        assertFalse(order.isInTransitOnNight(DELIVERY_NIGHT + 1));
    }

    @Test
    void givenDeliveryNight_whenCheckingDelivery_thenIsDelivered() {
        assertTrue(order.isDeliveredOnNight(DELIVERY_NIGHT));
    }

    @Test
    void givenNightBeforeDeliveryNight_whenCheckingDelivery_thenIsNotDelivered() {
        assertFalse(order.isDeliveredOnNight(DELIVERY_NIGHT - 1));
    }

    @Test
    void givenNightAfterDeliveryNight_whenCheckingDelivery_thenIsNotDelivered() {
        assertFalse(order.isDeliveredOnNight(DELIVERY_NIGHT + 1));
    }

    @Test
    void givenSameValues_whenComparingOrders_thenTheyAreEqual() {
        Order sameOrder = new Order(FoodType.PLANT, QUANTITY, ORDERED_AT_NIGHT, DELIVERY_NIGHT);

        assertEquals(order, sameOrder);
    }

    @Test
    void givenDifferentFoodTypes_whenComparingOrders_thenTheyAreNotEqual() {
        Order differentOrder = new Order(FoodType.MEAT, QUANTITY, ORDERED_AT_NIGHT, DELIVERY_NIGHT);

        assertNotEquals(order, differentOrder);
    }

    @Test
    void givenDifferentOrderNights_whenComparingOrders_thenTheyAreNotEqual() {
        Order differentOrder = new Order(FoodType.PLANT, QUANTITY, ORDERED_AT_NIGHT + 1, DELIVERY_NIGHT);

        assertNotEquals(order, differentOrder);
    }

    @Test
    void givenDifferentDeliveryNights_whenComparingOrders_thenTheyAreEqual() {
        Order differentOrder = new Order(FoodType.PLANT, QUANTITY, ORDERED_AT_NIGHT, DELIVERY_NIGHT + 1);

        assertNotEquals(order, differentOrder);
    }

    @Test
    void givenOrderInHashSet_whenLookingUpEqualOrder_thenFindsIt() {
        Set<Order> orders = new HashSet<>();
        orders.add(order);

        boolean containsOrder = orders.contains(new Order(FoodType.PLANT, QUANTITY, ORDERED_AT_NIGHT, DELIVERY_NIGHT));

        assertTrue(containsOrder);
    }
}
