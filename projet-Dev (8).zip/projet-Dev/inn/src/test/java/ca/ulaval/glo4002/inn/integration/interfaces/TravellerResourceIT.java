package ca.ulaval.glo4002.inn.integration.interfaces;

import org.glassfish.hk2.api.ServiceLocator;
import org.glassfish.hk2.utilities.ServiceLocatorUtilities;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.StayService;
import ca.ulaval.glo4002.inn.application.TravellerService;
import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.stay.HomeDimension;
import ca.ulaval.glo4002.inn.domain.stay.Species;
import ca.ulaval.glo4002.inn.domain.stay.StayPackage;
import ca.ulaval.glo4002.inn.domain.stay.StayRefusalReason;
import ca.ulaval.glo4002.inn.domain.stay.TravellerProfile;
import ca.ulaval.glo4002.inn.interfaces.configuration.ApplicationBinder;
import ca.ulaval.glo4002.inn.interfaces.resources.TravellerResource;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.StayResponse;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.TravellerResponse;
import jakarta.ws.rs.core.Response;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TravellerResourceIT {
    private static final String EXISTENCE_NUMBER = "EX-4417-Q";
    private static final TravellerProfile PROFILE =
            new TravellerProfile("Aliqua", Species.QUIDAM, 100, HomeDimension.SALARIA);
    private static final int NIGHTS = 3;
    private static final int EXECUTION_NIGHT = 1;

    private final ServiceLocator serviceLocator = ServiceLocatorUtilities.bind(new ApplicationBinder());
    private final StayService stayService = serviceLocator.getService(StayService.class);
    private final Inn inn = serviceLocator.getService(Inn.class);
    private final TravellerResource travellerResource =
            new TravellerResource(serviceLocator.getService(TravellerService.class));

    @AfterEach
    void tearDown() {
        serviceLocator.shutdown();
    }

    @Test
    void givenUnknownExistenceNumber_whenFindingTraveller_thenReturnsNotFound() {
        try (Response response = travellerResource.findTraveller(EXISTENCE_NUMBER)) {
            assertEquals(Response.Status.NOT_FOUND.getStatusCode(), response.getStatus());
        }
    }

    @Test
    void givenBookingNotYetExecuted_whenFindingTraveller_thenReturnsNotFound() {
        bookStay();

        try (Response response = travellerResource.findTraveller(EXISTENCE_NUMBER)) {
            assertEquals(Response.Status.NOT_FOUND.getStatusCode(), response.getStatus());
        }
    }

    @Test
    void givenExecutedBooking_whenFindingTraveller_thenReturnsOk() {
        bookStay();
        inn.passNight();

        try (Response response = travellerResource.findTraveller(EXISTENCE_NUMBER)) {
            assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
        }
    }

    @Test
    void givenRefusedBooking_whenFindingTraveller_thenStayShowsItsRefusalReason() {
        bookStay();
        inn.passNight();

        assertEquals(StayRefusalReason.NO_COMPATIBLE_ROOM, onlyStay().refusalReason());
    }

    @Test
    void givenRefusedBooking_whenFindingTraveller_thenStayShowsTheNightOfTheRefusal() {
        bookStay();
        inn.passNight();

        assertEquals(EXECUTION_NIGHT, onlyStay().reservedAtNight());
    }

    private void bookStay() {
        stayService.bookStay(new ExistenceNumber(EXISTENCE_NUMBER), PROFILE, StayPackage.COMFORT, NIGHTS);
    }

    private StayResponse onlyStay() {
        try (Response response = travellerResource.findTraveller(EXISTENCE_NUMBER)) {
            return ((TravellerResponse) response.getEntity()).stays().getFirst();
        }
    }
}
