package ca.ulaval.glo4002.inn.integration.application;

import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.OrderService;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.food.FoodBatch;
import ca.ulaval.glo4002.inn.domain.food.FoodReserve;
import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.order.OrderFactory;
import ca.ulaval.glo4002.inn.unit.domain.Inn.InnFactory;
import ca.ulaval.glo4002.inn.unit.domain.Inn.InnTestFactory;

import static org.junit.jupiter.api.Assertions.assertEquals;
class GardConsequencesIT {
    InnFactory factoryTest = InnTestFactory.createFactory();
    Inn inn = factoryTest.getInn();

    OrderService orderService =
            new OrderService(inn, factoryTest.getOrderRepository(), new OrderFactory());
    private final FoodReserve reserve = inn.getPantry().getReserve(FoodType.PLANT);

    @Test
    void givenOrderWithDeliveryDelay_whenPassingNights_thenStocksAtDeliveryNight() {
        final int quantity = 10;
        final int delayOfOneDay = 1;
        final int itemsStockedAtNight = 2;

        orderService.placeOrder(FoodType.PLANT, quantity, delayOfOneDay);
        inn.passNight();

        inn.passNight();

        assertEquals(List.of(new FoodBatch(quantity, itemsStockedAtNight, null)), reserve.stockedBatches());
    }

    @Test
    void givenFutureDelivery_whenPassingNight_thenDoesNotStockEarly() {
        final int quantity = 10;
        final int deliveryDelay = 1;
        final int expectedStock = 0;

        orderService.placeOrder(FoodType.PLANT, quantity, deliveryDelay);

        inn.passNight();

        assertEquals(expectedStock, reserve.stock());
    }

    @Test
    void givenDeliveredOrder_whenPassingAnotherNight_thenDoesNotDeliverAgain() {
        final int quantity = 10;
        final int noDelay = 0;
        final int itemsStockedAtNight = 1;

        orderService.placeOrder(FoodType.PLANT, quantity, noDelay);
        inn.passNight();

        inn.passNight();

        assertEquals(List.of(new FoodBatch(quantity, itemsStockedAtNight, null)), reserve.stockedBatches());
    }

    @Test
    void givenFullReserveExpiringTonight_whenDeliveryArrives_thenOverflowsBeforeDiscarding() {
        final int quantity = 40;
        final int noDelay = 0;
        final int anotherQuantity = 10;
        final int delayOfTwoDays = 2;
        final int expectedOverflow = 10;
        final int expectedDiscarded = 40;
        final int expectedStock = 0;

        orderService.placeOrder(FoodType.PLANT, quantity, noDelay);
        inn.passNight();
        orderService.placeOrder(FoodType.PLANT, anotherQuantity, delayOfTwoDays);
        inn.passNight();
        inn.passNight();

        inn.passNight();

        assertEquals(expectedOverflow, reserve.totalOverflowed());
        assertEquals(expectedDiscarded, reserve.totalDiscarded());
        assertEquals(expectedStock, reserve.stock());
    }
}
