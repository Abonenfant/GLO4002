package ca.ulaval.glo4002.inn.unit.domain.stay;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.stay.HomeDimension;
import ca.ulaval.glo4002.inn.domain.stay.Species;
import ca.ulaval.glo4002.inn.domain.stay.StayPackage;
import ca.ulaval.glo4002.inn.domain.stay.StayTerms;
import ca.ulaval.glo4002.inn.domain.stay.TravellerProfile;

import static org.junit.jupiter.api.Assertions.assertThrows;

class StayTermsTest {
    private static final TravellerProfile TRAVELLER_PROFILE =
            new TravellerProfile("Aliqua", Species.QUIDAM, 100, HomeDimension.SALARIA);
    private static final int ZERO_NIGHTS = 0;
    private static final int NEGATIVE_NIGHTS = -1;

    @Test
    void givenZeroNights_whenCreatingTerms_thenRejectsThem() {
        assertThrows(IllegalArgumentException.class,
                () -> new StayTerms(TRAVELLER_PROFILE, StayPackage.COMFORT, ZERO_NIGHTS));
    }

    @Test
    void givenNegativeNights_whenCreatingTerms_thenRejectsThem() {
        assertThrows(IllegalArgumentException.class,
                () -> new StayTerms(TRAVELLER_PROFILE, StayPackage.COMFORT, NEGATIVE_NIGHTS));
    }
}
