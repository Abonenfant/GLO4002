package ca.ulaval.glo4002.inn.integration.interfaces.rest.dto;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import ca.ulaval.glo4002.inn.domain.room.RoomOperation;
import ca.ulaval.glo4002.inn.domain.room.RoomRejectionReason;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.RoomRejectionResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;

class RoomRejectionResponseSerializationIT {
    private static final String EXPECTED_JSON = """
            {
              "roomNumber":3,
              "operation":"SETUP",
              "rejectedAtNight":5,
              "reason":"ROOM_NUMBER_ALREADY_USED"
            }
            """;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    void givenResponse_whenSerialized_thenJsonMatchesApiContract() throws Exception {
        RoomRejectionResponse response = new RoomRejectionResponse(
                3, RoomOperation.SETUP, 5, RoomRejectionReason.ROOM_NUMBER_ALREADY_USED);

        JsonNode json = objectMapper.valueToTree(response);

        assertEquals(objectMapper.readTree(EXPECTED_JSON), json);
    }
}
