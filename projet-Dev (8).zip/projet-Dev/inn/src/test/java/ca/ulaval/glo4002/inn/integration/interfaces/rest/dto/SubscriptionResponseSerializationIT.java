package ca.ulaval.glo4002.inn.integration.interfaces.rest.dto;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.SubscriptionResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SubscriptionResponseSerializationIT {
    private static final String EXPECTED_JSON =
            """
            {
              "subscriptionName": "Verger",
              "foodType": "PLANT",
              "quantity": 5,
              "period": 2,
              "status": "CANCELLED",
              "refusalReason": null,
              "nextDeliveryNight": null
            }
            """;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    void givenCancelledSubscriptionResponse_whenSerialized_thenJsonMatchesApiContract() throws Exception {
        SubscriptionResponse response = new SubscriptionResponse("Verger", "PLANT",
                5, 2, "CANCELLED", null, null);

        JsonNode json = objectMapper.valueToTree(response);

        assertEquals(objectMapper.readTree(EXPECTED_JSON), json);
    }
}
