package ca.ulaval.glo4002.inn.unit.domain.order;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.order.Order;
import ca.ulaval.glo4002.inn.domain.order.OrderFactory;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class OrderFactoryTest {

    private static final int TWO_NIGHTS_DELAY = 2;
    private static final int QUANTITY = 12;
    private static final int EXECUTION_NIGHT = 3;
    private static final int NO_DELAY = 0;
    private final OrderFactory orderFactory = new OrderFactory();

    @Test
    void givenExecutionNight_whenCreatingPlacedOrder_thenOrderedAtExecutionNight() {
        Order order = orderFactory.createPlacedOrder(EXECUTION_NIGHT, FoodType.PLANT, QUANTITY, TWO_NIGHTS_DELAY);

        assertEquals(EXECUTION_NIGHT, order.getOrderedAtNight());
    }

    @Test
    void givenNoDeliveryDelay_whenCreatingPlacedOrder_thenDeliveredOnExecutionNight() {
        Order order = orderFactory.createPlacedOrder(EXECUTION_NIGHT, FoodType.PLANT, QUANTITY, NO_DELAY);

        assertEquals(EXECUTION_NIGHT, order.getDeliveryNight());
    }

    @Test
    void givenDeliveryDelay_whenCreatingPlacedOrder_thenDeliveredThatManyNightsAfterExecution() {
        Order order = orderFactory.createPlacedOrder(EXECUTION_NIGHT, FoodType.PLANT, QUANTITY, TWO_NIGHTS_DELAY);

        assertEquals(EXECUTION_NIGHT + TWO_NIGHTS_DELAY, order.getDeliveryNight());
    }

    @Test
    void givenFoodType_whenCreatingPlacedOrder_thenPreservesFoodType() {
        Order order = orderFactory.createPlacedOrder(EXECUTION_NIGHT, FoodType.MEAT, QUANTITY, TWO_NIGHTS_DELAY);

        assertEquals(FoodType.MEAT, order.getFoodType());
    }

    @Test
    void givenQuantity_whenCreatingPlacedOrder_thenPreservesQuantity() {
        Order order = orderFactory.createPlacedOrder(EXECUTION_NIGHT, FoodType.PLANT, QUANTITY, TWO_NIGHTS_DELAY);

        assertEquals(QUANTITY, order.getQuantity());
    }
}
