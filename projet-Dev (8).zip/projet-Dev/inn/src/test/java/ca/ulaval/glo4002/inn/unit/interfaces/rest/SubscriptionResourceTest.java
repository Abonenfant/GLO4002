package ca.ulaval.glo4002.inn.unit.interfaces.rest;

import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.SubscriptionService;
import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.subscription.Subscription;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionFactory;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionTerms;
import ca.ulaval.glo4002.inn.interfaces.resources.SubscriptionResource;
import ca.ulaval.glo4002.inn.interfaces.rest.assemblers.SubscriptionAssembler;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.requests.SubscriptionRequest;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.SubscriptionResponse;
import jakarta.ws.rs.core.Response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class SubscriptionResourceTest {
    private static final String NAME = "Verger";
    private static final int QUANTITY = 5;
    private static final int PERIOD = 2;
    private static final SubscriptionRequest SUBSCRIPTION_REQUEST = new SubscriptionRequest(NAME, FoodType.PLANT, QUANTITY, PERIOD);
    private static final int CURRENT_NIGHT = 1;
    private static final Subscription SUBSCRIPTION =
            new SubscriptionFactory().createActiveSubscription(CURRENT_NIGHT, new SubscriptionTerms(NAME, FoodType.PLANT, QUANTITY, PERIOD));

    private final SubscriptionService subscriptionService = mock(SubscriptionService.class);
    private final SubscriptionResource subscriptionResource = new SubscriptionResource(subscriptionService);

    @Test
    void givenSubscriptionRequest_whenSubscribing_thenReturnsAccepted() {
        Response response = subscriptionResource.subscribe(SUBSCRIPTION_REQUEST);

        assertEquals(Response.Status.ACCEPTED.getStatusCode(), response.getStatus());
    }

    @Test
    void givenSubscriptionRequest_whenSubscribing_thenSubscribesWithRequestedTerms() {
        subscriptionResource.subscribe(SUBSCRIPTION_REQUEST);

        verify(subscriptionService).subscribe(new SubscriptionTerms(NAME, FoodType.PLANT, QUANTITY, PERIOD));
    }

    @Test
    void givenSubscriptionName_whenUnsubscribing_thenReturnsAccepted() {
        Response response = subscriptionResource.unsubscribe(NAME);

        assertEquals(Response.Status.ACCEPTED.getStatusCode(), response.getStatus());
    }

    @Test
    void givenSubscriptionName_whenUnsubscribing_thenUnsubscribesThatName() {
        subscriptionResource.unsubscribe(NAME);

        verify(subscriptionService).unsubscribe(NAME);
    }

    @Test
    void givenExecutedSubscriptions_whenGettingSubscriptions_thenReturnsOk() {
        when(subscriptionService.getSubscriptions()).thenReturn(List.of(SUBSCRIPTION));

        Response response = subscriptionResource.getSubscriptions();

        assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
    }

    @Test
    void givenExecutedSubscriptions_whenGettingSubscriptions_thenReturnsAssembledResponses() {
        when(subscriptionService.getCurrentNight()).thenReturn(CURRENT_NIGHT);
        when(subscriptionService.getSubscriptions()).thenReturn(List.of(SUBSCRIPTION));

        Response response = subscriptionResource.getSubscriptions();

        List<SubscriptionResponse> expected = List.of(SubscriptionAssembler.toResponse(SUBSCRIPTION, CURRENT_NIGHT));
        assertEquals(expected, response.getEntity());
    }

    @Test
    void givenNoSubscription_whenGettingSubscriptions_thenReturnsEmptyList() {
        when(subscriptionService.getSubscriptions()).thenReturn(List.of());

        Response response = subscriptionResource.getSubscriptions();

        assertEquals(List.of(), response.getEntity());
    }
}
