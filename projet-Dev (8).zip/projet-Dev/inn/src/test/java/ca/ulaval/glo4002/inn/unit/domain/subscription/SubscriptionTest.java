package ca.ulaval.glo4002.inn.unit.domain.subscription;

import java.util.Optional;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.subscription.Subscription;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionFactory;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRefusalReason;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionStatus;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionTerms;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SubscriptionTest {
    private static final int SUBSCRIBED_AT_NIGHT = 1;
    private static final int PERIOD = 4;
    private static final SubscriptionTerms TERMS = new SubscriptionTerms("Boucherie", FoodType.MEAT, 8, PERIOD);
    private static final int FIRST_DELIVERY_NIGHT = 5;
    private static final int SECOND_DELIVERY_NIGHT = 9;
    private static final int THIRD_DELIVERY_NIGHT = 13;
    private static final int NIGHT_BETWEEN_DELIVERIES = 8;

    private final SubscriptionFactory subscriptionFactory = new SubscriptionFactory();
    private final Subscription activeSubscription =
            subscriptionFactory.createActiveSubscription(SUBSCRIBED_AT_NIGHT, TERMS);
    private final Subscription refusedSubscription = subscriptionFactory.createRefusedSubscription(
            SUBSCRIBED_AT_NIGHT, TERMS, SubscriptionRefusalReason.SUBSCRIPTION_NAME_ALREADY_USED);

    @Test
    void givenSubscription_whenOnItsSubscriptionNight_thenIsNotDelivered() {
        assertFalse(activeSubscription.isDeliveredOnNight(SUBSCRIBED_AT_NIGHT));
    }

    @Test
    void givenActiveSubscription_whenCurrentNightIsExecutionNight_thenFirstDeliveryIsOnePeriodLater() {
        assertEquals(Optional.of(FIRST_DELIVERY_NIGHT), activeSubscription.nextDeliveryNightAfter(SUBSCRIBED_AT_NIGHT));
    }

    @Test
    void givenActiveSubscription_whenCurrentNightIsBetweenDeliveries_thenNextDeliveryIsUpcomingOne() {
        assertEquals(Optional.of(SECOND_DELIVERY_NIGHT), activeSubscription.nextDeliveryNightAfter(NIGHT_BETWEEN_DELIVERIES));
    }

    @Test
    void givenActiveSubscription_whenCurrentNightIsADeliveryNight_thenNextDeliveryIsTheFollowingOne() {
        assertEquals(Optional.of(SECOND_DELIVERY_NIGHT), activeSubscription.nextDeliveryNightAfter(FIRST_DELIVERY_NIGHT));
    }

    @Test
    void givenActiveSubscription_whenCurrentNightIsSecondDeliveryNight_thenNextDeliveryIsThird() {
        assertEquals(Optional.of(THIRD_DELIVERY_NIGHT), activeSubscription.nextDeliveryNightAfter(SECOND_DELIVERY_NIGHT));
    }

    @Test
    void givenActiveSubscription_whenCheckingStatus_thenIsActiveAndNotRefused() {
        assertTrue(activeSubscription.isActive());
        assertFalse(activeSubscription.isRefused());
    }

    @Test
    void givenRefusedSubscription_whenFindingNextDeliveryNight_thenHasNone() {
        assertTrue(refusedSubscription.nextDeliveryNightAfter(SUBSCRIBED_AT_NIGHT).isEmpty());
    }

    @Test
    void givenActiveSubscription_whenCancelled_thenStatusIsCancelled() {
        activeSubscription.cancel();

        assertEquals(SubscriptionStatus.CANCELLED, activeSubscription.getStatus());
    }

    @Test
    void givenCancelledSubscription_whenOnAScheduledDeliveryNight_thenIsNotDelivered() {
        activeSubscription.cancel();

        assertFalse(activeSubscription.isDeliveredOnNight(FIRST_DELIVERY_NIGHT));
    }

    @Test
    void givenCancelledSubscription_whenFindingNextDeliveryNight_thenHasNone() {
        activeSubscription.cancel();

        assertTrue(activeSubscription.nextDeliveryNightAfter(SUBSCRIBED_AT_NIGHT).isEmpty());
    }
}
