package ca.ulaval.glo4002.inn.unit.domain.Inn;

import ca.ulaval.glo4002.inn.domain.Pantry;
import ca.ulaval.glo4002.inn.domain.food.FoodFactory;
import ca.ulaval.glo4002.inn.domain.order.OrderRepository;
import ca.ulaval.glo4002.inn.domain.room.RoomRepository;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryOrderRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryRoomRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemorySubscriptionRepository;

public class InnTestFactory {

    public static InnFactory createFactory() {
        OrderRepository orderRepository = new InMemoryOrderRepository();
        SubscriptionRepository subscriptionRepository = new InMemorySubscriptionRepository();
        RoomRepository roomRepository = new InMemoryRoomRepository();
        Pantry pantry = new Pantry(new FoodFactory());

        return new InnFactory(
                orderRepository,
                subscriptionRepository,
                roomRepository,
                pantry
        );
    }
}
