package ca.ulaval.glo4002.inn.unit.domain.stay;

import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.stay.HomeDimension;
import ca.ulaval.glo4002.inn.domain.stay.Money;
import ca.ulaval.glo4002.inn.domain.stay.Species;
import ca.ulaval.glo4002.inn.domain.stay.Stay;
import ca.ulaval.glo4002.inn.domain.stay.StayFactory;
import ca.ulaval.glo4002.inn.domain.stay.StayPackage;
import ca.ulaval.glo4002.inn.domain.stay.StayRefusalReason;
import ca.ulaval.glo4002.inn.domain.stay.StayStatus;
import ca.ulaval.glo4002.inn.domain.stay.StayTerms;
import ca.ulaval.glo4002.inn.domain.stay.Traveller;
import ca.ulaval.glo4002.inn.domain.stay.TravellerProfile;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TravellerTest {
    private static final ExistenceNumber EXISTENCE_NUMBER = new ExistenceNumber("EX-01");
    private static final TravellerProfile FIRST_PROFILE =
            new TravellerProfile("Aliqua", Species.QUIDAM, 100, HomeDimension.SALARIA);
    private static final TravellerProfile LATEST_PROFILE =
            new TravellerProfile("Lorem", Species.QUIDAM, 90, HomeDimension.NOCTAMBULIE);
    private static final int NIGHTS = 3;
    private static final int ONE_NIGHT = 1;
    private static final int RESERVATION_NIGHT = 1;
    private static final int FIRST_NIGHT = 2;
    private static final int MIDDLE_NIGHT = 3;
    private static final int LAST_NIGHT = 4;
    private static final int NIGHT_AFTER_LAST_NIGHT = 5;
    private static final RoomNumber ROOM_NUMBER = new RoomNumber(1);
    private static final Money AMOUNT_AFTER_FIRST_NIGHT = Money.ofPieces(150);
    private static final Money AMOUNT_AFTER_LAST_NIGHT = Money.ofPieces(450);

    private final StayFactory stayFactory = new StayFactory();

    @Test
    void givenTraveller_whenReadingExistenceNumber_thenIsTheNumberThatIdentifiesTheTraveller() {
        Traveller traveller = travellerWithBookedStay();

        assertEquals(EXISTENCE_NUMBER, traveller.getExistenceNumber());
    }

    @Test
    void givenNewTraveller_whenReadingStays_thenContainsItsFirstStay() {
        Stay firstStay = bookedStay();

        Traveller traveller = new Traveller(EXISTENCE_NUMBER, firstStay);

        assertEquals(List.of(firstStay), traveller.getStays());
    }

    @Test
    void givenEndedStay_whenAddingNewStay_thenStaysAreKeptInExecutionOrder() {
        Stay firstStay = bookedStay();
        Traveller traveller = new Traveller(EXISTENCE_NUMBER, firstStay);
        traveller.arrive(FIRST_NIGHT);
        traveller.depart(LAST_NIGHT);
        Stay secondStay = laterStayOf(FIRST_PROFILE);

        traveller.addStay(secondStay);

        assertEquals(List.of(firstStay, secondStay), traveller.getStays());
    }

    @Test
    void givenSeveralStays_whenReadingProfile_thenIsTheProfileOfTheMostRecentStay() {
        Traveller traveller = travellerWithEndedStay();
        traveller.addStay(laterStayOf(LATEST_PROFILE));

        assertEquals(LATEST_PROFILE, traveller.getProfile());
    }

    @Test
    void givenBookedStay_whenCheckingIfAlreadyStaying_thenIsAlreadyStaying() {
        Traveller traveller = travellerWithBookedStay();

        assertTrue(traveller.isAlreadyStaying());
    }

    @Test
    void givenActiveStay_whenCheckingIfAlreadyStaying_thenIsAlreadyStaying() {
        Traveller traveller = travellerWithActiveStay();

        assertTrue(traveller.isAlreadyStaying());
    }

    @Test
    void givenEndedStay_whenCheckingIfAlreadyStaying_thenIsNotAlreadyStaying() {
        Traveller traveller = travellerWithEndedStay();

        assertFalse(traveller.isAlreadyStaying());
    }

    @Test
    void givenRefusedStay_whenCheckingIfAlreadyStaying_thenIsNotAlreadyStaying() {
        Traveller traveller = travellerWithRefusedStay();

        assertFalse(traveller.isAlreadyStaying());
    }

    @Test
    void givenTravellerAlreadyStaying_whenAddingBookedStay_thenIsRejected() {
        Traveller traveller = travellerWithBookedStay();
        Stay secondBookedStay = bookedStay();

        assertThrows(IllegalStateException.class, () -> traveller.addStay(secondBookedStay));
    }

    @Test
    void givenTravellerAlreadyStaying_whenAddingRefusedStay_thenRefusalIsKeptInHistory() {
        Traveller traveller = travellerWithBookedStay();
        Stay refusedStay = stayFactory.createRefusedStay(
                FIRST_NIGHT, termsFor(FIRST_PROFILE, NIGHTS), StayRefusalReason.ALREADY_STAYING);

        traveller.addStay(refusedStay);

        assertEquals(refusedStay, traveller.getStays().getLast());
    }

    @Test
    void givenBookedStay_whenItsFirstNightBegins_thenTravellerIsArriving() {
        Traveller traveller = travellerWithBookedStay();

        assertTrue(traveller.isArrivingOn(FIRST_NIGHT));
    }

    @Test
    void givenBookedStay_whenOnItsReservationNight_thenTravellerIsNotArriving() {
        Traveller traveller = travellerWithBookedStay();

        assertFalse(traveller.isArrivingOn(RESERVATION_NIGHT));
    }

    @Test
    void givenRefusedStay_whenNightAfterRefusalBegins_thenTravellerIsNotArriving() {
        Traveller traveller = travellerWithRefusedStay();

        assertFalse(traveller.isArrivingOn(FIRST_NIGHT));
    }

    @Test
    void givenArrivingTraveller_whenArriving_thenStayBecomesActive() {
        Traveller traveller = travellerWithBookedStay();

        traveller.arrive(FIRST_NIGHT);

        assertEquals(StayStatus.ACTIVE, onlyStayOf(traveller).getStatus());
    }

    @Test
    void givenArrivedTraveller_whenCheckingTheSameNight_thenIsNoLongerArriving() {
        Traveller traveller = travellerWithActiveStay();

        assertFalse(traveller.isArrivingOn(FIRST_NIGHT));
    }

    @Test
    void givenNoStayStartingThatNight_whenArriving_thenIsRejected() {
        Traveller traveller = travellerWithBookedStay();

        assertThrows(IllegalStateException.class, () -> traveller.arrive(MIDDLE_NIGHT));
    }

    @Test
    void givenActiveStay_whenItsLastNightBegins_thenTravellerIsDeparting() {
        Traveller traveller = travellerWithActiveStay();

        assertTrue(traveller.isDepartingOn(LAST_NIGHT));
    }

    @Test
    void givenActiveStay_whenBeforeItsLastNight_thenTravellerIsNotDeparting() {
        Traveller traveller = travellerWithActiveStay();

        assertFalse(traveller.isDepartingOn(MIDDLE_NIGHT));
    }

    @Test
    void givenOneNightStay_whenTravellerHasArrived_thenDepartsTheSameNight() {
        Traveller traveller = new Traveller(EXISTENCE_NUMBER, bookedStayOf(ONE_NIGHT));
        traveller.arrive(FIRST_NIGHT);

        assertTrue(traveller.isDepartingOn(FIRST_NIGHT));
    }

    @Test
    void givenDepartingTraveller_whenDeparting_thenStayIsEnded() {
        Traveller traveller = travellerWithActiveStay();

        traveller.depart(LAST_NIGHT);

        assertEquals(StayStatus.ENDED, onlyStayOf(traveller).getStatus());
    }

    @Test
    void givenNoStayEndingThatNight_whenDeparting_thenIsRejected() {
        Traveller traveller = travellerWithActiveStay();

        assertThrows(IllegalStateException.class, () -> traveller.depart(MIDDLE_NIGHT));
    }

    @Test
    void givenBookedStay_whenOnItsReservationNight_thenHasNotSpentTheNight() {
        Traveller traveller = travellerWithBookedStay();

        assertFalse(traveller.hasSpentNight(RESERVATION_NIGHT));
    }

    @Test
    void givenActiveStay_whenDuringItsNights_thenHasSpentTheNight() {
        Traveller traveller = travellerWithActiveStay();

        assertTrue(traveller.hasSpentNight(MIDDLE_NIGHT));
    }

    @Test
    void givenStayEndedTonight_whenCheckingTonight_thenHasSpentTheNight() {
        Traveller traveller = travellerWithEndedStay();

        assertTrue(traveller.hasSpentNight(LAST_NIGHT));
    }

    @Test
    void givenEndedStay_whenNightAfterItsLastNight_thenHasNotSpentTheNight() {
        Traveller traveller = travellerWithEndedStay();

        assertFalse(traveller.hasSpentNight(NIGHT_AFTER_LAST_NIGHT));
    }

    @Test
    void givenRefusedStay_whenNightAfterRefusal_thenHasNotSpentTheNight() {
        Traveller traveller = travellerWithRefusedStay();

        assertFalse(traveller.hasSpentNight(FIRST_NIGHT));
    }

    @Test
    void givenTravellerWhoSpentTheNight_whenBilling_thenTotalIncreasesByTheNightlyRateOfItsPackage() {
        Traveller traveller = travellerWithActiveStay();

        traveller.billNight(FIRST_NIGHT);

        assertEquals(AMOUNT_AFTER_FIRST_NIGHT, onlyStayOf(traveller).getTotalBilledAmount());
    }

    @Test
    void givenComfortStayOfThreeNights_whenLivingItsNights_thenIsBilledForEachNightSpent() {
        Traveller traveller = travellerWithBookedStay();

        traveller.arrive(FIRST_NIGHT);
        traveller.billNight(FIRST_NIGHT);
        traveller.billNight(MIDDLE_NIGHT);
        traveller.depart(LAST_NIGHT);
        traveller.billNight(LAST_NIGHT);

        assertEquals(AMOUNT_AFTER_LAST_NIGHT, onlyStayOf(traveller).getTotalBilledAmount());
    }

    @Test
    void givenNightAlreadyBilled_whenBillingItAgain_thenIsRejected() {
        Traveller traveller = travellerWithActiveStay();
        traveller.billNight(FIRST_NIGHT);

        assertThrows(IllegalStateException.class, () -> traveller.billNight(FIRST_NIGHT));
    }

    @Test
    void givenNoStaySpentThatNight_whenBilling_thenIsRejected() {
        Traveller traveller = travellerWithBookedStay();

        assertThrows(IllegalStateException.class, () -> traveller.billNight(RESERVATION_NIGHT));
    }

    @Test
    void givenArrivingTraveller_whenReadingRoomOnFirstNight_thenIsTheReservedRoom() {
        Traveller traveller = travellerWithBookedStay();

        assertEquals(ROOM_NUMBER, traveller.getRoomNumberOn(FIRST_NIGHT));
    }

    @Test
    void givenStayEndedTonight_whenReadingRoomOnLastNight_thenIsStillItsRoom() {
        Traveller traveller = travellerWithEndedStay();

        assertEquals(ROOM_NUMBER, traveller.getRoomNumberOn(LAST_NIGHT));
    }

    @Test
    void givenRefusedStay_whenReadingRoom_thenIsRejected() {
        Traveller traveller = travellerWithRefusedStay();

        assertThrows(IllegalStateException.class, () -> traveller.getRoomNumberOn(FIRST_NIGHT));
    }

    private Traveller travellerWithBookedStay() {
        return new Traveller(EXISTENCE_NUMBER, bookedStay());
    }

    private Traveller travellerWithActiveStay() {
        Traveller traveller = travellerWithBookedStay();
        traveller.arrive(FIRST_NIGHT);
        return traveller;
    }

    private Traveller travellerWithEndedStay() {
        Traveller traveller = travellerWithActiveStay();
        traveller.depart(LAST_NIGHT);
        return traveller;
    }

    private Traveller travellerWithRefusedStay() {
        Stay refusedStay = stayFactory.createRefusedStay(
                RESERVATION_NIGHT, termsFor(FIRST_PROFILE, NIGHTS), StayRefusalReason.NO_COMPATIBLE_ROOM);
        return new Traveller(EXISTENCE_NUMBER, refusedStay);
    }

    private Stay bookedStay() {
        return bookedStayOf(NIGHTS);
    }

    private Stay bookedStayOf(int nights) {
        return stayFactory.createBookedStay(RESERVATION_NIGHT, termsFor(FIRST_PROFILE, nights), ROOM_NUMBER);
    }

    private Stay laterStayOf(TravellerProfile travellerProfile) {
        return stayFactory.createBookedStay(NIGHT_AFTER_LAST_NIGHT, termsFor(travellerProfile, NIGHTS), ROOM_NUMBER);
    }

    private static StayTerms termsFor(TravellerProfile travellerProfile, int nights) {
        return new StayTerms(travellerProfile, StayPackage.COMFORT, nights);
    }

    private static Stay onlyStayOf(Traveller traveller) {
        return traveller.getStays().getFirst();
    }
}
