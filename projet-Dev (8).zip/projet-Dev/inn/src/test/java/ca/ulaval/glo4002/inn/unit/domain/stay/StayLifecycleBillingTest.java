package ca.ulaval.glo4002.inn.unit.domain.stay;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomDirectory;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.stay.HomeDimension;
import ca.ulaval.glo4002.inn.domain.stay.Money;
import ca.ulaval.glo4002.inn.domain.stay.Species;
import ca.ulaval.glo4002.inn.domain.stay.StayFactory;
import ca.ulaval.glo4002.inn.domain.stay.StayLifecycle;
import ca.ulaval.glo4002.inn.domain.stay.StayPackage;
import ca.ulaval.glo4002.inn.domain.stay.StayRefusalReason;
import ca.ulaval.glo4002.inn.domain.stay.StayTerms;
import ca.ulaval.glo4002.inn.domain.stay.Traveller;
import ca.ulaval.glo4002.inn.domain.stay.TravellerProfile;
import ca.ulaval.glo4002.inn.domain.stay.TravellerRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryRoomRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryTravellerRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;

class StayLifecycleBillingTest {
    private static final ExistenceNumber EXISTENCE_NUMBER = new ExistenceNumber("EX-01");
    private static final TravellerProfile PROFILE = new TravellerProfile("Aliqua", Species.QUIDAM, 100, HomeDimension.SALARIA);
    private static final RoomNumber ROOM_NUMBER = new RoomNumber(1);
    private static final int NIGHTS = 3;
    private static final int RESERVATION_NIGHT = 1;
    private static final int FIRST_NIGHT = 2;
    private static final int MIDDLE_NIGHT = 3;
    private static final int LAST_NIGHT = 4;
    private static final int NIGHT_AFTER_LAST_NIGHT = 5;

    private final TravellerRepository travellerRepository = new InMemoryTravellerRepository();
    private final StayFactory stayFactory = new StayFactory();
    private final StayLifecycle stayLifecycle =
            new StayLifecycle(travellerRepository, new RoomDirectory(new InMemoryRoomRepository()));

    @Test
    void givenRoyalTravellerWhoSpentTheNight_whenTravellersAreBilled_thenIsBilledThreeHundredPieces() {
        givenArrivedTravellerWith(StayPackage.ROYAL);

        stayLifecycle.billTravellers(FIRST_NIGHT);

        assertEquals(Money.ofPieces(300), totalBilledAmount());
    }

    @Test
    void givenComfortTravellerWhoSpentTheNight_whenTravellersAreBilled_thenIsBilledOneHundredFiftyPieces() {
        givenArrivedTravellerWith(StayPackage.COMFORT);

        stayLifecycle.billTravellers(FIRST_NIGHT);

        assertEquals(Money.ofPieces(150), totalBilledAmount());
    }

    @Test
    void givenModestTravellerWhoSpentTheNight_whenTravellersAreBilled_thenIsBilledSixtyPieces() {
        givenArrivedTravellerWith(StayPackage.MODEST);

        stayLifecycle.billTravellers(FIRST_NIGHT);

        assertEquals(Money.ofPieces(60), totalBilledAmount());
    }

    @Test
    void givenTravellerBilledOnSeveralNights_whenTravellersAreBilled_thenAmountDueIsCumulated() {
        givenArrivedTravellerWith(StayPackage.COMFORT);

        stayLifecycle.billTravellers(FIRST_NIGHT);
        stayLifecycle.billTravellers(MIDDLE_NIGHT);
        stayLifecycle.billTravellers(LAST_NIGHT);

        assertEquals(Money.ofPieces(450), totalBilledAmount());
    }

    @Test
    void givenTravellerWhoDepartedTonight_whenTravellersAreBilled_thenLastNightIsBilled() {
        Traveller traveller = givenArrivedTravellerWith(StayPackage.COMFORT);
        traveller.depart(LAST_NIGHT);

        stayLifecycle.billTravellers(LAST_NIGHT);

        assertEquals(Money.ofPieces(150), totalBilledAmount());
    }

    @Test
    void givenBookedTravellerNotArrivedYet_whenTravellersAreBilled_thenIsNotBilled() {
        travellerRepository.save(new Traveller(EXISTENCE_NUMBER,
                stayFactory.createBookedStay(RESERVATION_NIGHT, termsWith(StayPackage.ROYAL), ROOM_NUMBER)));

        stayLifecycle.billTravellers(RESERVATION_NIGHT);

        assertEquals(Money.ZERO, totalBilledAmount());
    }

    @Test
    void givenRefusedStay_whenTravellersAreBilled_thenIsNotBilled() {
        travellerRepository.save(new Traveller(EXISTENCE_NUMBER, stayFactory.createRefusedStay(
                RESERVATION_NIGHT, termsWith(StayPackage.ROYAL), StayRefusalReason.NO_COMPATIBLE_ROOM)));

        stayLifecycle.billTravellers(FIRST_NIGHT);

        assertEquals(Money.ZERO, totalBilledAmount());
    }

    @Test
    void givenStayWhoseLastNightHasPassed_whenTravellersAreBilledTheNightAfter_thenIsNotBilled() {
        givenArrivedTravellerWith(StayPackage.COMFORT);

        stayLifecycle.billTravellers(NIGHT_AFTER_LAST_NIGHT);

        assertEquals(Money.ZERO, totalBilledAmount());
    }

    private Traveller givenArrivedTravellerWith(StayPackage stayPackage) {
        Traveller traveller = new Traveller(EXISTENCE_NUMBER,
                stayFactory.createBookedStay(RESERVATION_NIGHT, termsWith(stayPackage), ROOM_NUMBER));
        traveller.arrive(FIRST_NIGHT);
        travellerRepository.save(traveller);
        return traveller;
    }

    private static StayTerms termsWith(StayPackage stayPackage) {
        return new StayTerms(PROFILE, stayPackage, NIGHTS);
    }

    private Money totalBilledAmount() {
        return travellerRepository.findByExistenceNumber(EXISTENCE_NUMBER).orElseThrow().getLatestStay().getTotalBilledAmount();
    }
}
