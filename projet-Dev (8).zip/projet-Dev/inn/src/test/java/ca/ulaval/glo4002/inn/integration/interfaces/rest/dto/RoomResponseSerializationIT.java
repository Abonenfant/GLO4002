package ca.ulaval.glo4002.inn.integration.interfaces.rest.dto;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import ca.ulaval.glo4002.inn.domain.room.Atmosphere;
import ca.ulaval.glo4002.inn.domain.room.Gravity;
import ca.ulaval.glo4002.inn.domain.room.Temperature;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.OccupantResponse;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.RoomResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;

class RoomResponseSerializationIT {
    private static final String EXPECTED_JSON = """
            {
              "roomNumber":1,
              "atmosphere":"STANDARD",
              "gravity":"NORMAL",
              "temperature":"TEMPERATE",
              "capacity":2,
              "freePlaces":0,
              "occupants":[
                 {"existenceNumber":"EX-4417-Q","travellerName":"Aliqua"}
              ]
             }
            """;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    void givenResponse_whenSerialized_thenJsonMatchesApiContract() throws Exception {
        List<OccupantResponse> occupants = List.of(new OccupantResponse("EX-4417-Q", "Aliqua"));
        RoomResponse response = new RoomResponse(
                1, Atmosphere.STANDARD, Gravity.NORMAL, Temperature.TEMPERATE, 2, 0, occupants);

        JsonNode json = objectMapper.valueToTree(response);

        assertEquals(objectMapper.readTree(EXPECTED_JSON), json);
    }
}
