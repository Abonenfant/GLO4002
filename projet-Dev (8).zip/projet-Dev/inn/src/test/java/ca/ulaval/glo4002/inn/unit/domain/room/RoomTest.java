package ca.ulaval.glo4002.inn.unit.domain.room;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.room.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RoomTest {
    private static final RoomNumber ROOM_NUMBER = new RoomNumber(1);
    private static final int CAPACITY = 2;
    private static final ExistenceNumber EXISTENCE_NUMBER = new ExistenceNumber("EX-4417-Q");
    private static final String TRAVELLER_NAME = "Aliqua";
    private static final RoomConfiguration CONFIGURATION =
            new RoomConfiguration(Atmosphere.STANDARD, Gravity.NORMAL, Temperature.TEMPERATE);
    private static final ExistenceNumber SMALLER_EXISTENCE_NUMBER = new ExistenceNumber("EX-100");
    private static final ExistenceNumber GREATER_EXISTENCE_NUMBER = new ExistenceNumber("EX-99");

    private Room room;

    @BeforeEach
    void setUp() {
        room = new Room(ROOM_NUMBER, CONFIGURATION, CAPACITY);
    }

    @Test
    void givenNewRoom_whenCheckingAvailability_thenAllPlacesAreFree() {
        assertEquals(CAPACITY, room.getFreePlaces());
    }

    @Test
    void givenMatchingConfiguration_whenCheckingCompatibility_thenRoomIsCompatible() {
        RoomConfiguration sameConfiguration =
                new RoomConfiguration(Atmosphere.STANDARD, Gravity.NORMAL, Temperature.TEMPERATE);

        assertTrue(room.isCompatibleWith(sameConfiguration));
    }

    @Test
    void givenDifferentConfiguration_whenCheckingCompatibility_thenRoomIsNotCompatible() {
        RoomConfiguration differentConfiguration =
                new RoomConfiguration(Atmosphere.HUMID, Gravity.NORMAL, Temperature.TEMPERATE);

        assertFalse(room.isCompatibleWith(differentConfiguration));
    }

    @Test
    void givenAvailableRoom_whenReservingPlace_thenFreePlacesDecrease() {
        room.reservePlace(EXISTENCE_NUMBER);

        assertEquals(CAPACITY - 1, room.getFreePlaces());
    }

    @Test
    void givenReservedPlace_whenCheckingIfRoomIsEmpty_thenRoomIsNotEmpty() {
        room.reservePlace(EXISTENCE_NUMBER);

        assertFalse(room.isEmpty());
    }

    @Test
    void givenReservedPlace_whenListingOccupants_thenTravellerIsNotAnOccupantYet() {
        room.reservePlace(EXISTENCE_NUMBER);

        assertTrue(room.getOccupants().isEmpty());
    }

    @Test
    void givenReservedPlace_whenTravellerArrives_thenReservationBecomesOccupation() {
        room.reservePlace(EXISTENCE_NUMBER);
        RoomOccupant occupant = new RoomOccupant(EXISTENCE_NUMBER, TRAVELLER_NAME);

        room.occupyReservedPlace(occupant);

        assertEquals(1, room.getOccupants().size());
        assertEquals(occupant, room.getOccupants().getFirst());
        assertTrue(room.getReservedExistenceNumbers().isEmpty());
    }

    @Test
    void givenReservedPlace_whenTravellerArrives_thenFreePlacesRemainUnchanged() {
        room.reservePlace(EXISTENCE_NUMBER);
        int freePlacesBeforeArrival = room.getFreePlaces();

        room.occupyReservedPlace(new RoomOccupant(EXISTENCE_NUMBER, TRAVELLER_NAME));

        assertEquals(freePlacesBeforeArrival, room.getFreePlaces());
    }

    @Test
    void givenOccupiedPlace_whenReleasingPlace_thenPlaceBecomesAvailable() {
        room.reservePlace(EXISTENCE_NUMBER);
        room.occupyReservedPlace(new RoomOccupant(EXISTENCE_NUMBER, TRAVELLER_NAME));

        room.releasePlace(EXISTENCE_NUMBER);

        assertEquals(CAPACITY, room.getFreePlaces());
        assertTrue(room.isEmpty());
    }

    @Test
    void givenFullRoom_whenReservingAnotherPlace_thenReservationIsRejected() {
        room.reservePlace(new ExistenceNumber("EX-01"));
        room.reservePlace(new ExistenceNumber("EX-02"));

        assertThrows(IllegalStateException.class, () -> room.reservePlace(new ExistenceNumber("EX-03")));
    }

    @Test
    void givenNoReservation_whenTravellerArrives_thenArrivalIsRejected() {
        RoomOccupant occupant = new RoomOccupant(EXISTENCE_NUMBER, TRAVELLER_NAME);

        assertThrows(IllegalStateException.class, () -> room.occupyReservedPlace(occupant));
    }

    @Test
    void givenZeroCapacity_whenCreatingRoom_thenRejectsCapacity() {
        assertThrows(IllegalArgumentException.class, () -> new Room(ROOM_NUMBER, CONFIGURATION, 0));
    }

    @Test
    void givenNegativeCapacity_whenCreatingRoom_thenRejectsCapacity() {
        assertThrows(IllegalArgumentException.class, () -> new Room(ROOM_NUMBER, CONFIGURATION, -1));
    }

    @Test
    void givenUnknownTraveller_whenReleasingPlace_thenReleaseIsRejected() {
        assertThrows(IllegalStateException.class, () -> room.releasePlace(EXISTENCE_NUMBER));
    }

    @Test
    void givenEmptyRoom_whenReconfiguring_thenConfigurationAndCapacityAreUpdated() {
        RoomConfiguration newConfiguration =
                new RoomConfiguration(Atmosphere.HUMID, Gravity.LIGHT, Temperature.COLD);
        final int newCapacity = 4;

        room.reconfigure(newConfiguration, newCapacity);

        assertEquals(newConfiguration, room.getConfiguration());
        assertEquals(newCapacity, room.getCapacity());
    }

    @Test
    void givenRoomWithReservedPlace_whenReconfiguring_thenReconfigurationIsRejected() {
        RoomConfiguration newConfiguration =
                new RoomConfiguration(Atmosphere.HUMID, Gravity.LIGHT, Temperature.COLD);
        final int newCapacity = 4;
        room.reservePlace(EXISTENCE_NUMBER);

        assertThrows(
                IllegalStateException.class,
                () -> room.reconfigure(newConfiguration, newCapacity)
        );

        assertEquals(CONFIGURATION, room.getConfiguration());
        assertEquals(CAPACITY, room.getCapacity());
    }

    @Test
    void givenOccupantsArrivedInDisorder_whenListingOccupants_thenOccupantsAreSortedByExistenceNumber() {
        RoomOccupant greaterOccupant = new RoomOccupant(GREATER_EXISTENCE_NUMBER, TRAVELLER_NAME);
        RoomOccupant smallerOccupant = new RoomOccupant(SMALLER_EXISTENCE_NUMBER, TRAVELLER_NAME);
        arrive(greaterOccupant);
        arrive(smallerOccupant);

        List<RoomOccupant> occupants = room.getOccupants();

        assertEquals(List.of(smallerOccupant, greaterOccupant), occupants);
    }

    private void arrive(RoomOccupant occupant) {
        room.reservePlace(occupant.getExistenceNumber());
        room.occupyReservedPlace(occupant);
    }
}
