package ca.ulaval.glo4002.inn.unit.application;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import ca.ulaval.glo4002.inn.application.RoomService;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.action.ReconfigureRoomAction;
import ca.ulaval.glo4002.inn.domain.action.SetupRoomAction;
import ca.ulaval.glo4002.inn.domain.room.Atmosphere;
import ca.ulaval.glo4002.inn.domain.room.Gravity;
import ca.ulaval.glo4002.inn.domain.room.Room;
import ca.ulaval.glo4002.inn.domain.room.RoomConfiguration;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomOperation;
import ca.ulaval.glo4002.inn.domain.room.RoomRejection;
import ca.ulaval.glo4002.inn.domain.room.RoomRejectionReason;
import ca.ulaval.glo4002.inn.domain.room.RoomRejectionRepository;
import ca.ulaval.glo4002.inn.domain.room.RoomRepository;
import ca.ulaval.glo4002.inn.domain.room.Temperature;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class RoomServiceTest {

    private static final int ROOM_NUMBER_VALUE = 1;
    private static final int CAPACITY = 22;
    private static final Atmosphere ATMOSPHERE = Atmosphere.HUMID;
    private static final Gravity GRAVITY = Gravity.HEAVY;
    private static final Temperature TEMPERATURE = Temperature.TEMPERATE;
    private static final int EXECUTION_NIGHT = 7;
    private static final RoomConfiguration CONFIGURATION =
            new RoomConfiguration(ATMOSPHERE, GRAVITY, TEMPERATURE);
    private static final RoomNumber FIRST_ROOM_NUMBER = new RoomNumber(1);
    private static final RoomNumber SECOND_ROOM_NUMBER = new RoomNumber(2);
    private static final RoomNumber THIRD_ROOM_NUMBER = new RoomNumber(3);

    private final Inn inn = mock(Inn.class);
    private final RoomRepository roomRepository = mock(RoomRepository.class);
    private final RoomRejectionRepository roomRejectionRepository = mock(RoomRejectionRepository.class);

    private final RoomService roomService = new RoomService(inn, roomRepository, roomRejectionRepository);

    @Test
    void givenRequest_whenCallingRoomService_thenAddsActionToInnQueue() {
        requestRoomSetup();

        verify(inn).addActionToQueue(any(SetupRoomAction.class));
    }

    @Test
    void givenRequest_whenActionIsExecuted_thenRoomIsSavedWithCorrectProperties() {
        requestRoomSetup();

        SetupRoomAction action = captureAction();
        action.execute(EXECUTION_NIGHT);

        ArgumentCaptor<Room> roomCaptor = ArgumentCaptor.forClass(Room.class);
        verify(roomRepository).save(roomCaptor.capture());

        Room savedRoom = roomCaptor.getValue();
        assertEquals(new RoomNumber(ROOM_NUMBER_VALUE), savedRoom.getRoomNumber());
        assertEquals(CAPACITY, savedRoom.getCapacity());
        assertEquals(ATMOSPHERE, savedRoom.getConfiguration().getAtmosphere());
        assertEquals(GRAVITY, savedRoom.getConfiguration().getGravity());
        assertEquals(TEMPERATURE, savedRoom.getConfiguration().getTemperature());
    }

    @Test
    void givenRequest_whenCallingRoomService_thenRoomIsNotCreatedImmediately() {
        requestRoomSetup();

        verify(roomRepository, never()).save(any(Room.class));
    }

    @Test
    void givenInn_whenGettingCurrentNight_thenReturnsInnNight() {
        when(inn.getCurrentNight()).thenReturn(EXECUTION_NIGHT);

        int night = roomService.getCurrentNight();

        assertEquals(EXECUTION_NIGHT, night);
    }

    @Test
    void givenReconfigurationRequest_whenCallingRoomService_thenAddsActionToInnQueue() {
        roomService.requestRoomReconfiguration(
                ROOM_NUMBER_VALUE,
                ATMOSPHERE,
                GRAVITY,
                TEMPERATURE,
                CAPACITY
        );

        verify(inn).addActionToQueue(any(ReconfigureRoomAction.class));
    }

    @Test
    void givenNoRoom_whenFindingAllRooms_thenReturnsEmptyList() {
        when(roomRepository.findAll()).thenReturn(List.of());

        List<Room> rooms = roomService.findAllRooms();

        assertTrue(rooms.isEmpty());
    }

    @Test
    void givenRoomsInDisorder_whenFindingAllRooms_thenRoomsAreSortedByRoomNumber() {
        Room thirdRoom = new Room(THIRD_ROOM_NUMBER, CONFIGURATION, CAPACITY);
        Room firstRoom = new Room(FIRST_ROOM_NUMBER, CONFIGURATION, CAPACITY);
        Room secondRoom = new Room(SECOND_ROOM_NUMBER, CONFIGURATION, CAPACITY);
        when(roomRepository.findAll()).thenReturn(List.of(thirdRoom, firstRoom, secondRoom));

        List<Room> rooms = roomService.findAllRooms();

        assertEquals(List.of(firstRoom, secondRoom, thirdRoom), rooms);
    }

    @Test
    void givenRooms_whenFindingAllRooms_thenNoRoomIsModified() {
        when(roomRepository.findAll()).thenReturn(List.of(new Room(FIRST_ROOM_NUMBER, CONFIGURATION, CAPACITY)));

        roomService.findAllRooms();

        verify(roomRepository, never()).save(any(Room.class));
    }

    @Test
    void givenNoRejection_whenFindingAllRejections_thenReturnsEmptyList() {
        when(roomRejectionRepository.findAllInExecutionOrder()).thenReturn(List.of());

        List<RoomRejection> rejections = roomService.findAllRejections();

        assertTrue(rejections.isEmpty());
    }

    @Test
    void givenRejectionHistory_whenFindingAllRejections_thenKeepsExecutionOrder() {
        RoomRejection firstRejection = new RoomRejection(THIRD_ROOM_NUMBER, RoomOperation.SETUP,
                EXECUTION_NIGHT, RoomRejectionReason.ROOM_NUMBER_ALREADY_USED);
        RoomRejection secondRejection = new RoomRejection(FIRST_ROOM_NUMBER, RoomOperation.RECONFIGURE,
                EXECUTION_NIGHT, RoomRejectionReason.ROOM_NOT_FOUND);
        when(roomRejectionRepository.findAllInExecutionOrder())
                .thenReturn(List.of(firstRejection, secondRejection));

        List<RoomRejection> rejections = roomService.findAllRejections();

        assertEquals(List.of(firstRejection, secondRejection), rejections);
    }

    @Test
    void givenRejectionHistory_whenFindingAllRejections_thenNeitherRoomsNorHistoryAreModified() {
        when(roomRejectionRepository.findAllInExecutionOrder()).thenReturn(List.of());

        roomService.findAllRejections();

        verify(roomRejectionRepository, never()).save(any(RoomRejection.class));
        verify(roomRepository, never()).save(any(Room.class));
    }

    private void requestRoomSetup() {
        roomService.requestRoomSetup(
                ROOM_NUMBER_VALUE,
                ATMOSPHERE,
                GRAVITY,
                TEMPERATURE,
                CAPACITY
        );
    }

    private SetupRoomAction captureAction() {
        ArgumentCaptor<SetupRoomAction> captor = ArgumentCaptor.forClass(SetupRoomAction.class);
        verify(inn).addActionToQueue(captor.capture());
        return captor.getValue();
    }
}
