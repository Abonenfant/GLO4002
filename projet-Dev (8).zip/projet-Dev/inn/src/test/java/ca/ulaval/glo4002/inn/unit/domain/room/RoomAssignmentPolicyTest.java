package ca.ulaval.glo4002.inn.unit.domain.room;

import java.util.Optional;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.room.Room;
import ca.ulaval.glo4002.inn.domain.room.RoomAssignmentPolicy;
import ca.ulaval.glo4002.inn.domain.room.RoomDirectory;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.stay.Species;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryRoomRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;

class RoomAssignmentPolicyTest {
    private static final ExistenceNumber EXISTENCE_NUMBER = new ExistenceNumber("EX-4417-Q");
    private static final RoomNumber LOWER_ROOM_NUMBER = new RoomNumber(1);
    private static final RoomNumber HIGHER_ROOM_NUMBER = new RoomNumber(2);
    private static final int CAPACITY = 2;

    private final InMemoryRoomRepository roomRepository = new InMemoryRoomRepository();
    private final RoomDirectory roomDirectory = new RoomDirectory(roomRepository);
    private final RoomAssignmentPolicy roomAssignmentPolicy = new RoomAssignmentPolicy();

    @Test
    void givenCompatibleRoomsWithDifferentFreePlaces_whenAssigningRoom_thenSelectsRoomWithFewestFreePlaces() {
        Room emptyRoom = new Room(LOWER_ROOM_NUMBER, Species.QUIDAM.requiredConfiguration(), CAPACITY);
        Room partiallyReservedRoom = new Room(HIGHER_ROOM_NUMBER, Species.QUIDAM.requiredConfiguration(), CAPACITY);
        partiallyReservedRoom.reservePlace(EXISTENCE_NUMBER);
        roomRepository.save(emptyRoom);
        roomRepository.save(partiallyReservedRoom);

        Optional<Room> assignedRoom = roomAssignmentPolicy.findBestAvailableRoom(roomDirectory, Species.QUIDAM);

        assertEquals(Optional.of(partiallyReservedRoom), assignedRoom);
    }

    @Test
    void givenCompatibleRoomsWithEqualFreePlaces_whenAssigningRoom_thenSelectsLowestRoomNumber() {
        Room higherNumberRoom = new Room(HIGHER_ROOM_NUMBER, Species.QUIDAM.requiredConfiguration(), CAPACITY);
        Room lowerNumberRoom = new Room(LOWER_ROOM_NUMBER, Species.QUIDAM.requiredConfiguration(), CAPACITY);
        roomRepository.save(higherNumberRoom);
        roomRepository.save(lowerNumberRoom);

        Optional<Room> assignedRoom = roomAssignmentPolicy.findBestAvailableRoom(roomDirectory, Species.QUIDAM);

        assertEquals(Optional.of(lowerNumberRoom), assignedRoom);
    }

    @Test
    void givenFullCompatibleRoom_whenAssigningRoom_thenSelectsAvailableRoom() {
        Room fullRoom = new Room(LOWER_ROOM_NUMBER, Species.QUIDAM.requiredConfiguration(), 1);
        fullRoom.reservePlace(EXISTENCE_NUMBER);
        Room availableRoom = new Room(HIGHER_ROOM_NUMBER, Species.QUIDAM.requiredConfiguration(), CAPACITY);
        roomRepository.save(fullRoom);
        roomRepository.save(availableRoom);

        Optional<Room> assignedRoom = roomAssignmentPolicy.findBestAvailableRoom(roomDirectory, Species.QUIDAM);

        assertEquals(Optional.of(availableRoom), assignedRoom);
    }

    @Test
    void givenIncompatibleRoomWithFewerFreePlaces_whenAssigningRoom_thenSelectsCompatibleRoom() {
        Room incompatibleRoom = new Room(LOWER_ROOM_NUMBER, Species.PYROPHORE.requiredConfiguration(), 1);
        Room compatibleRoom = new Room(HIGHER_ROOM_NUMBER, Species.QUIDAM.requiredConfiguration(), CAPACITY);
        roomRepository.save(incompatibleRoom);
        roomRepository.save(compatibleRoom);

        Optional<Room> assignedRoom = roomAssignmentPolicy.findBestAvailableRoom(roomDirectory, Species.QUIDAM);

        assertEquals(Optional.of(compatibleRoom), assignedRoom);
    }

    @Test
    void givenNoRooms_whenAssigningRoom_thenReturnsEmpty() {
        Optional<Room> assignedRoom = roomAssignmentPolicy.findBestAvailableRoom(roomDirectory, Species.QUIDAM);

        assertEquals(Optional.empty(), assignedRoom);
    }
}
