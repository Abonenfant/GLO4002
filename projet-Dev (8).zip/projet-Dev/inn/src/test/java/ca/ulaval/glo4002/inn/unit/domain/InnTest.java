package ca.ulaval.glo4002.inn.unit.domain;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;

import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.Pantry;
import ca.ulaval.glo4002.inn.domain.action.Action;
import ca.ulaval.glo4002.inn.domain.food.FoodFactory;
import ca.ulaval.glo4002.inn.domain.order.OrderRepository;
import ca.ulaval.glo4002.inn.domain.stay.StayLifecycle;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

class InnTest {
    private static final int FIRST_NIGHT = 1;
    private static final int SECOND_NIGHT = 2;

    private Inn inn;
    private StayLifecycle stayLifecycle;
    private Action firstAction;
    private Action secondAction;

    @BeforeEach
    void setUp() {
        stayLifecycle = mock(StayLifecycle.class);
        inn = new Inn(
                mock(OrderRepository.class),
                mock(SubscriptionRepository.class),
                new Pantry(new FoodFactory()),
                stayLifecycle);
        firstAction = mock(Action.class);
        secondAction = mock(Action.class);
    }

    @Test
    void givenNewInn_whenCreated_thenStartsAtNightZero() {
        final int nightZero = 0;
        assertEquals(nightZero, inn.getCurrentNight());
    }

    @Test
    void givenNewInn_whenCreated_thenHasPantry() {
        assertNotNull(inn.getPantry());
    }

    @Test
    void givenInnWithEmptyPendingQueue_whenNewAction_thenActionIsAddedToPendingQueue() {
        final int queueWithOneActionSize = 1;
        inn.addActionToQueue(firstAction);

        assertEquals(queueWithOneActionSize, inn.getPendingActionQueueSize());
    }

    @Test
    void givenInnWithOnePendingAction_whenNewAction_thenOrderIsPreserved() {
        inn.addActionToQueue(firstAction);
        inn.addActionToQueue(secondAction);

        assertEquals(firstAction, inn.getFirstInPendingActionQueue());
    }

    @Test
    void givenInnPendingActionQueue_whenActionsExecuted_thenActionsAreExecutedInArrivalOrder() {
        inn.addActionToQueue(firstAction);
        inn.addActionToQueue(secondAction);

        inn.executeNight();

        InOrder executionOrder = inOrder(firstAction, secondAction);
        executionOrder.verify(firstAction).execute(anyInt());
        executionOrder.verify(secondAction).execute(anyInt());
    }

    @Test
    void givenInnPendingActionQueue_whenActionsExecuted_thenQueueIsEmpty() {
        final int emptySizeQueue = 0;

        inn.addActionToQueue(firstAction);
        inn.addActionToQueue(secondAction);

        inn.executeNight();

        assertEquals(emptySizeQueue, inn.getPendingActionQueueSize());
    }

    @Test
    void givenInnPendingActionQueue_whenActionExecutionFails_thenFailureIsPropagated() {
        RuntimeException failure = new RuntimeException();
        doThrow(failure).when(firstAction).execute(anyInt());
        inn.addActionToQueue(firstAction);

        RuntimeException thrown = assertThrows(RuntimeException.class, () -> inn.executeNight());

        assertSame(failure, thrown);
    }

    @Test
    void givenInn_whenNightPasses_thenCurrentNightIsIncremented() {
        inn.passNight();

        assertEquals(FIRST_NIGHT, inn.getCurrentNight());
    }

    @Test
    void givenInn_whenNightPassesTwice_thenCurrentNightIsIncrementedByTwo() {
        inn.passNight();
        inn.passNight();

        assertEquals(SECOND_NIGHT, inn.getCurrentNight());
    }

    @Test
    void givenInnWithPendingActions_whenNightPasses_thenPendingActionQueueIsEmptied() {
        final int emptySizeQueue = 0;
        inn.addActionToQueue(firstAction);

        inn.passNight();

        assertEquals(emptySizeQueue, inn.getPendingActionQueueSize());
    }

    @Test
    void givenInn_whenNightPasses_thenTravellersArriveOnTheNewNight() {
        inn.passNight();

        verify(stayLifecycle).arriveTravellers(FIRST_NIGHT);
    }

    @Test
    void givenPendingAction_whenNightPasses_thenActionIsExecutedBeforeTravellersArrive() {
        inn.addActionToQueue(firstAction);

        inn.passNight();

        InOrder nightOrder = inOrder(firstAction, stayLifecycle);
        nightOrder.verify(firstAction).execute(FIRST_NIGHT);
        nightOrder.verify(stayLifecycle).arriveTravellers(FIRST_NIGHT);
    }

    @Test
    void givenInn_whenNightPasses_thenTravellersDepartOnTheNewNight() {
        inn.passNight();

        verify(stayLifecycle).departTravellers(FIRST_NIGHT);
    }

    @Test
    void givenPendingAction_whenNightPasses_thenActionIsExecutedBeforeTravellersDepart() {
        inn.addActionToQueue(firstAction);

        inn.passNight();

        InOrder nightOrder = inOrder(firstAction, stayLifecycle);
        nightOrder.verify(firstAction).execute(FIRST_NIGHT);
        nightOrder.verify(stayLifecycle).departTravellers(FIRST_NIGHT);
    }

    @Test
    void givenInn_whenNightPasses_thenTravellersAreBilledForTheNewNight() {
        inn.passNight();

        verify(stayLifecycle).billTravellers(FIRST_NIGHT);
    }

    @Test
    void givenPendingAction_whenNightPasses_thenActionIsExecutedBeforeTravellersAreBilled() {
        inn.addActionToQueue(firstAction);

        inn.passNight();

        InOrder nightOrder = inOrder(firstAction, stayLifecycle);
        nightOrder.verify(firstAction).execute(FIRST_NIGHT);
        nightOrder.verify(stayLifecycle).billTravellers(FIRST_NIGHT);
    }

    @Test
    void givenPendingAction_whenNightPasses_thenActionReceivesNewNight() {
        inn.addActionToQueue(firstAction);

        inn.passNight();

        verify(firstAction).execute(FIRST_NIGHT);
    }
}
