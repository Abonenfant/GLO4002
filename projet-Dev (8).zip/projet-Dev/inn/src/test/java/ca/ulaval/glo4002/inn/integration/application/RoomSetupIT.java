package ca.ulaval.glo4002.inn.integration.application;

import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.RoomService;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.Pantry;
import ca.ulaval.glo4002.inn.domain.food.FoodFactory;
import ca.ulaval.glo4002.inn.domain.order.OrderRepository;
import ca.ulaval.glo4002.inn.domain.room.Atmosphere;
import ca.ulaval.glo4002.inn.domain.room.Gravity;
import ca.ulaval.glo4002.inn.domain.room.Room;
import ca.ulaval.glo4002.inn.domain.room.RoomDirectory;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomOperation;
import ca.ulaval.glo4002.inn.domain.room.RoomRejection;
import ca.ulaval.glo4002.inn.domain.room.RoomRejectionReason;
import ca.ulaval.glo4002.inn.domain.room.RoomRejectionRepository;
import ca.ulaval.glo4002.inn.domain.room.RoomRepository;
import ca.ulaval.glo4002.inn.domain.room.Temperature;
import ca.ulaval.glo4002.inn.domain.stay.StayLifecycle;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryOrderRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryRoomRejectionRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryRoomRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemorySubscriptionRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryTravellerRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

class RoomSetupIT {

    private static final int ROOM_NUMBER = 42;
    private static final int CAPACITY = 5;
    private static final Atmosphere ATMOSPHERE = Atmosphere.HUMID;
    private static final Gravity GRAVITY = Gravity.HEAVY;
    private static final Temperature TEMPERATURE = Temperature.COLD;

    private final Pantry pantry = new Pantry(new FoodFactory());
    private final RoomRepository roomRepository = new InMemoryRoomRepository();
    private final SubscriptionRepository subscriptionRepository = new InMemorySubscriptionRepository();
    private final OrderRepository orderRepository = new InMemoryOrderRepository();
    private final RoomDirectory roomDirectory = new RoomDirectory(roomRepository);
    private final Inn inn = new Inn(orderRepository, subscriptionRepository, pantry,
            new StayLifecycle(new InMemoryTravellerRepository(), roomDirectory));
    private final RoomRejectionRepository roomRejectionRepository = new InMemoryRoomRejectionRepository();
    private final RoomService roomService =
            new RoomService(inn, roomRepository, roomRejectionRepository);

    @Test
    void givenRoomSetupRequested_whenNoNightHasPassed_thenRoomDoesNotExistYet() {
        requestRoomSetup();

        assertThrows(NoSuchElementException.class,
                () -> roomDirectory.findExistingRoom(new RoomNumber(ROOM_NUMBER)));
    }

    @Test
    void givenRoomSetupRequested_whenNightPasses_thenRoomIsCreated() {
        requestRoomSetup();

        inn.passNight();

        Room room = roomDirectory.findExistingRoom(new RoomNumber(ROOM_NUMBER));
        assertNotNull(room);
        assertEquals(ROOM_NUMBER, room.getRoomNumber().value());
    }

    @Test
    void givenRoomSetupRequested_whenNightPasses_thenRoomHasCorrectConfiguration() {
        requestRoomSetup();

        inn.passNight();

        Room room = roomDirectory.findExistingRoom(new RoomNumber(ROOM_NUMBER));

        assertEquals(CAPACITY, room.getCapacity());
        assertEquals(ATMOSPHERE, room.getConfiguration().getAtmosphere());
        assertEquals(GRAVITY, room.getConfiguration().getGravity());
        assertEquals(TEMPERATURE, room.getConfiguration().getTemperature());
    }

    @Test
    void givenRoomAlreadyCreated_whenNightPassesAgain_thenRoomIsNotDuplicated() {
        requestRoomSetup();
        inn.passNight();

        int countBefore = roomDirectory.findAll().size();

        inn.passNight();

        int countAfter = roomDirectory.findAll().size();

        assertEquals(countBefore, countAfter);
    }

    @Test
    void givenTwoRoomSetupRequestsSameNumber_whenNightPasses_thenFirstCreatesRoomAndSecondCreatesRejection() {
        roomService.requestRoomSetup(ROOM_NUMBER, ATMOSPHERE, GRAVITY, TEMPERATURE, CAPACITY);
        roomService.requestRoomSetup(ROOM_NUMBER, ATMOSPHERE, GRAVITY, TEMPERATURE, CAPACITY);

        inn.passNight();

        Room room = roomDirectory.findExistingRoom(new RoomNumber(ROOM_NUMBER));
        assertNotNull(room);
        assertEquals(ROOM_NUMBER, room.getRoomNumber().value());
        assertEquals(CAPACITY, room.getCapacity());
        assertEquals(ATMOSPHERE, room.getConfiguration().getAtmosphere());
        assertEquals(GRAVITY, room.getConfiguration().getGravity());
        assertEquals(TEMPERATURE, room.getConfiguration().getTemperature());

        assertEquals(1, roomRejectionRepository.findAllInExecutionOrder().size());
        RoomRejection rejection = roomRejectionRepository.findAllInExecutionOrder().getFirst();

        assertEquals(new RoomNumber(ROOM_NUMBER), rejection.getRoomNumber());
        assertEquals(RoomOperation.SETUP, rejection.getOperation());
        assertEquals(inn.getCurrentNight(), rejection.getRejectedAtNight());
        assertEquals(RoomRejectionReason.ROOM_NUMBER_ALREADY_USED, rejection.getReason());
    }

    private void requestRoomSetup() {
        roomService.requestRoomSetup(
                ROOM_NUMBER,
                ATMOSPHERE,
                GRAVITY,
                TEMPERATURE,
                CAPACITY
        );
    }
}
