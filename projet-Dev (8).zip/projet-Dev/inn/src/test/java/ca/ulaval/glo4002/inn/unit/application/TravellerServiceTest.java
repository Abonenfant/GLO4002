package ca.ulaval.glo4002.inn.unit.application;

import java.util.Optional;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.TravellerService;
import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.stay.HomeDimension;
import ca.ulaval.glo4002.inn.domain.stay.Species;
import ca.ulaval.glo4002.inn.domain.stay.StayFactory;
import ca.ulaval.glo4002.inn.domain.stay.StayPackage;
import ca.ulaval.glo4002.inn.domain.stay.StayTerms;
import ca.ulaval.glo4002.inn.domain.stay.Traveller;
import ca.ulaval.glo4002.inn.domain.stay.TravellerProfile;
import ca.ulaval.glo4002.inn.domain.stay.TravellerRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class TravellerServiceTest {
    private static final ExistenceNumber EXISTENCE_NUMBER = new ExistenceNumber("EX-01");
    private static final StayTerms TERMS = new StayTerms(
            new TravellerProfile("Aliqua", Species.QUIDAM, 100, HomeDimension.SALARIA), StayPackage.COMFORT, 3);
    private static final Traveller TRAVELLER = new Traveller(
            EXISTENCE_NUMBER, new StayFactory().createBookedStay(1, TERMS, new RoomNumber(1)));

    private final TravellerRepository travellerRepository = mock(TravellerRepository.class);
    private final TravellerService travellerService = new TravellerService(travellerRepository);

    @Test
    void givenKnownExistenceNumber_whenFindingTraveller_thenReturnsTheTraveller() {
        when(travellerRepository.findByExistenceNumber(EXISTENCE_NUMBER)).thenReturn(Optional.of(TRAVELLER));

        assertEquals(Optional.of(TRAVELLER), travellerService.findTraveller(EXISTENCE_NUMBER));
    }

    @Test
    void givenUnknownExistenceNumber_whenFindingTraveller_thenReturnsNothing() {
        when(travellerRepository.findByExistenceNumber(EXISTENCE_NUMBER)).thenReturn(Optional.empty());

        assertEquals(Optional.empty(), travellerService.findTraveller(EXISTENCE_NUMBER));
    }
}
