package ca.ulaval.glo4002.inn.integration.interfaces.rest.dto;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.ObjectMapper;

import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.requests.SubscriptionRequest;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SubscriptionRequestDeserializationIT {
    private static final String REQUEST_JSON =
            "{\"subscriptionName\":\"Verger\",\"foodType\":\"PLANT\",\"quantity\":5,\"period\":2}";

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    void givenApiContractJson_whenDeserialized_thenRequestHasItsValues() throws Exception {
        SubscriptionRequest request = objectMapper.readValue(REQUEST_JSON, SubscriptionRequest.class);

        assertEquals(new SubscriptionRequest("Verger", FoodType.PLANT, 5, 2), request);
    }
}
