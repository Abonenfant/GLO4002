package ca.ulaval.glo4002.inn.integration.application;

import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.RoomService;
import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.Pantry;
import ca.ulaval.glo4002.inn.domain.food.FoodFactory;
import ca.ulaval.glo4002.inn.domain.room.Atmosphere;
import ca.ulaval.glo4002.inn.domain.room.Gravity;
import ca.ulaval.glo4002.inn.domain.room.RoomDirectory;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomOperation;
import ca.ulaval.glo4002.inn.domain.room.RoomRejection;
import ca.ulaval.glo4002.inn.domain.room.RoomRejectionReason;
import ca.ulaval.glo4002.inn.domain.room.RoomRepository;
import ca.ulaval.glo4002.inn.domain.room.Temperature;
import ca.ulaval.glo4002.inn.domain.stay.StayLifecycle;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryOrderRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryRoomRejectionRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryRoomRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemorySubscriptionRepository;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryTravellerRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RoomRejectionHistoryIT {
    private static final int ROOM_NUMBER = 1;
    private static final int UNKNOWN_ROOM_NUMBER = 9;
    private static final int CAPACITY = 2;
    private static final int FIRST_NIGHT = 1;
    private static final int SECOND_NIGHT = 2;
    private static final ExistenceNumber EXISTENCE_NUMBER = new ExistenceNumber("EX-4417-Q");

    private final RoomRepository roomRepository = new InMemoryRoomRepository();
    private final Inn inn = new Inn(
            new InMemoryOrderRepository(),
            new InMemorySubscriptionRepository(),
            new Pantry(new FoodFactory()),
            new StayLifecycle(new InMemoryTravellerRepository(), new RoomDirectory(roomRepository)));
    private final RoomService roomService = new RoomService(inn, roomRepository, new InMemoryRoomRejectionRepository());

    @Test
    void givenOnlyAcceptedOperations_whenConsultingRejections_thenHistoryIsEmpty() {
        requestSetup(ROOM_NUMBER);
        inn.passNight();

        List<RoomRejection> rejections = roomService.findAllRejections();

        assertTrue(rejections.isEmpty());
    }

    @Test
    void givenDuplicateSetupRequested_whenNoNightHasPassed_thenNoRejectionExistsYet() {
        requestSetup(ROOM_NUMBER);
        requestSetup(ROOM_NUMBER);

        List<RoomRejection> rejections = roomService.findAllRejections();

        assertTrue(rejections.isEmpty());
    }

    @Test
    void givenRefusedOperationsOverTwoNights_whenConsultingRejections_thenEachRejectionIsListedInExecutionOrder() {
        requestSetup(ROOM_NUMBER);
        requestSetup(ROOM_NUMBER);
        requestReconfiguration(UNKNOWN_ROOM_NUMBER);
        inn.passNight();
        reservePlaceInRoom(ROOM_NUMBER);
        requestReconfiguration(ROOM_NUMBER);
        inn.passNight();

        List<RoomRejection> rejections = roomService.findAllRejections();

        List<RoomRejection> expected = List.of(
                new RoomRejection(new RoomNumber(ROOM_NUMBER), RoomOperation.SETUP,
                        FIRST_NIGHT, RoomRejectionReason.ROOM_NUMBER_ALREADY_USED),
                new RoomRejection(new RoomNumber(UNKNOWN_ROOM_NUMBER), RoomOperation.RECONFIGURE,
                        FIRST_NIGHT, RoomRejectionReason.ROOM_NOT_FOUND),
                new RoomRejection(new RoomNumber(ROOM_NUMBER), RoomOperation.RECONFIGURE,
                        SECOND_NIGHT, RoomRejectionReason.ROOM_NOT_EMPTY));
        assertEquals(expected, rejections);
    }

    @Test
    void givenRejectionAtFirstNight_whenSeveralNightsPass_thenRejectionRemainsConsultable() {
        requestSetup(ROOM_NUMBER);
        requestSetup(ROOM_NUMBER);
        inn.passNight();

        inn.passNight();
        inn.passNight();

        List<RoomRejection> expected = List.of(new RoomRejection(new RoomNumber(ROOM_NUMBER),
                RoomOperation.SETUP, FIRST_NIGHT, RoomRejectionReason.ROOM_NUMBER_ALREADY_USED));
        assertEquals(expected, roomService.findAllRejections());
    }

    private void requestSetup(int roomNumber) {
        roomService.requestRoomSetup(roomNumber, Atmosphere.STANDARD, Gravity.NORMAL, Temperature.TEMPERATE, CAPACITY);
    }

    private void requestReconfiguration(int roomNumber) {
        roomService.requestRoomReconfiguration(roomNumber, Atmosphere.HUMID, Gravity.LIGHT, Temperature.COLD, CAPACITY);
    }

    private void reservePlaceInRoom(int roomNumber) {
        roomRepository.findByNumber(new RoomNumber(roomNumber)).orElseThrow().reservePlace(EXISTENCE_NUMBER);
    }
}
