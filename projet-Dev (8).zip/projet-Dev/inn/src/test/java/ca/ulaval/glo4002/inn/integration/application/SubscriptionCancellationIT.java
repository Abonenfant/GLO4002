package ca.ulaval.glo4002.inn.integration.application;

import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.SubscriptionService;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.subscription.Subscription;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionFactory;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRepository;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionStatus;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionTerms;
import ca.ulaval.glo4002.inn.unit.domain.Inn.InnFactory;
import ca.ulaval.glo4002.inn.unit.domain.Inn.InnTestFactory;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SubscriptionCancellationIT {
    private static final String NAME = "Verger";
    private static final String UNKNOWN_NAME = "Inconnu";
    private static final int QUANTITY = 5;
    private static final int PERIOD = 2;
    private static final int LATER_DELIVERY_NIGHT = 1 + 2 * PERIOD;
    private static final SubscriptionTerms TERMS = new SubscriptionTerms(NAME, FoodType.PLANT, QUANTITY, PERIOD);

    InnFactory factoryTest = InnTestFactory.createFactory();
    Inn inn = factoryTest.getInn();
    private final SubscriptionRepository subscriptionRepository = factoryTest.getSubscriptionRepository();
    private final SubscriptionService subscriptionService =
            new SubscriptionService(inn, subscriptionRepository, new SubscriptionFactory());

    @Test
    void givenUnsubscriptionRequested_whenNoNightHasPassed_thenSubscriptionIsStillActive() {
        givenActiveSubscription();

        subscriptionService.unsubscribe(NAME);

        assertEquals(List.of(SubscriptionStatus.ACTIVE), subscriptionStatuses());
    }

    @Test
    void givenActiveSubscription_whenUnsubscriptionIsExecuted_thenSubscriptionIsCancelled() {
        givenActiveSubscription();
        subscriptionService.unsubscribe(NAME);

        inn.passNight();

        assertEquals(List.of(SubscriptionStatus.CANCELLED), subscriptionStatuses());
    }

    @Test
    void givenCancelledSubscription_whenLaterDeliveryNightsPass_thenNothingIsDelivered() {
        givenActiveSubscription();
        subscriptionService.unsubscribe(NAME);

        passNightsUntil(LATER_DELIVERY_NIGHT);

        assertEquals(0, inn.getPantry().getReserve(FoodType.PLANT).stock());
    }

    @Test
    void givenUnknownSubscriptionName_whenUnsubscriptionIsExecuted_thenExistingSubscriptionsAreUnchanged() {
        givenActiveSubscription();
        subscriptionService.unsubscribe(UNKNOWN_NAME);

        inn.passNight();

        assertEquals(List.of(SubscriptionStatus.ACTIVE), subscriptionStatuses());
    }

    @Test
    void givenAlreadyCancelledSubscription_whenUnsubscribedAgain_thenItStaysCancelled() {
        givenActiveSubscription();
        subscriptionService.unsubscribe(NAME);
        inn.passNight();
        subscriptionService.unsubscribe(NAME);

        inn.passNight();

        assertEquals(List.of(SubscriptionStatus.CANCELLED), subscriptionStatuses());
    }

    @Test
    void givenUnsubscriptionAndSubscriptionWithSameNameTheSameNight_whenNightPasses_thenNewSubscriptionIsActive() {
        givenActiveSubscription();
        subscriptionService.unsubscribe(NAME);
        subscriptionService.subscribe(TERMS);

        inn.passNight();

        assertEquals(List.of(SubscriptionStatus.CANCELLED, SubscriptionStatus.ACTIVE), subscriptionStatuses());
    }

    @Test
    void givenNoSubscription_whenUnsubscriptionIsExecuted_thenNoSubscriptionIsCreated() {
        subscriptionService.unsubscribe(NAME);

        inn.passNight();

        assertTrue(subscriptionRepository.findAllInExecutionOrder().isEmpty());
    }

    private void givenActiveSubscription() {
        subscriptionService.subscribe(TERMS);
        inn.passNight();
    }

    private List<SubscriptionStatus> subscriptionStatuses() {
        return subscriptionRepository.findAllInExecutionOrder().stream().map(Subscription::getStatus).toList();
    }

    private void passNightsUntil(int night) {
        while (inn.getCurrentNight() < night) {
            inn.passNight();
        }
    }
}
