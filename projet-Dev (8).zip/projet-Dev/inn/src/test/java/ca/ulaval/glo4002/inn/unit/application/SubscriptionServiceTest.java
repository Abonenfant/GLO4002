package ca.ulaval.glo4002.inn.unit.application;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import ca.ulaval.glo4002.inn.application.SubscriptionService;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.action.Action;
import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.subscription.Subscription;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionFactory;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRepository;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionStatus;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionTerms;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class SubscriptionServiceTest {
    private static final String NAME = "Verger";
    private static final int EXECUTION_NIGHT = 4;
    private static final SubscriptionTerms TERMS = new SubscriptionTerms(NAME, FoodType.PLANT, 5, 2);

    private final Inn inn = mock(Inn.class);
    private final SubscriptionRepository subscriptionRepository = mock(SubscriptionRepository.class);
    private final SubscriptionService subscriptionService =
            new SubscriptionService(inn, subscriptionRepository, new SubscriptionFactory());

    @Test
    void givenSubscriptionRequested_whenNotYetExecuted_thenNoSubscriptionIsSaved() {
        subscriptionService.subscribe(TERMS);

        verifyNoInteractions(subscriptionRepository);
    }

    @Test
    void givenSubscriptionRequested_whenItsActionIsExecuted_thenSubscriptionIsSaved() {
        subscriptionService.subscribe(TERMS);

        captureQueuedAction().execute(EXECUTION_NIGHT);

        assertEquals(NAME, captureSavedSubscription().getName());
    }

    @Test
    void givenUnsubscriptionRequested_whenNotYetExecuted_thenRepositoryIsNotTouched() {
        subscriptionService.unsubscribe(NAME);

        verifyNoInteractions(subscriptionRepository);
    }

    @Test
    void givenUnsubscriptionRequested_whenItsActionIsExecuted_thenActiveSubscriptionIsCancelled() {
        Subscription subscription = new SubscriptionFactory().createActiveSubscription(EXECUTION_NIGHT, TERMS);
        when(subscriptionRepository.findActiveByName(NAME)).thenReturn(Optional.of(subscription));
        subscriptionService.unsubscribe(NAME);

        captureQueuedAction().execute(EXECUTION_NIGHT);

        assertEquals(SubscriptionStatus.CANCELLED, subscription.getStatus());
    }

    @Test
    void givenSavedSubscriptions_whenGettingSubscriptions_thenReturnsRepositorySubscriptions() {
        Subscription subscription = new SubscriptionFactory().createActiveSubscription(EXECUTION_NIGHT, TERMS);
        when(subscriptionRepository.findAllInExecutionOrder()).thenReturn(List.of(subscription));

        assertEquals(List.of(subscription), subscriptionService.getSubscriptions());
    }

    @Test
    void givenInnAtANight_whenGettingCurrentNight_thenReturnsInnCurrentNight() {
        when(inn.getCurrentNight()).thenReturn(EXECUTION_NIGHT);

        assertEquals(EXECUTION_NIGHT, subscriptionService.getCurrentNight());
    }

    private Action captureQueuedAction() {
        ArgumentCaptor<Action> queuedAction = ArgumentCaptor.forClass(Action.class);
        verify(inn).addActionToQueue(queuedAction.capture());
        return queuedAction.getValue();
    }

    private Subscription captureSavedSubscription() {
        ArgumentCaptor<Subscription> savedSubscription = ArgumentCaptor.forClass(Subscription.class);
        verify(subscriptionRepository).save(savedSubscription.capture());
        return savedSubscription.getValue();
    }
}
