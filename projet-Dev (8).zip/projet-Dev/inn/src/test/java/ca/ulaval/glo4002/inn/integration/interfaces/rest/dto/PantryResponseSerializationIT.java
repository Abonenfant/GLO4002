package ca.ulaval.glo4002.inn.integration.interfaces.rest.dto;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.PantryResponse;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.ReserveResponse;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.ShipmentResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PantryResponseSerializationIT {
    private static final String EXPECTED_JSON = """
            {"reserves":[{
              "foodType":"PLANT",
              "maxCapacity":40,
              "stockedQuantity":12,
              "shipments":[
                {"quantity":40,"stockedAtNight":1,"discardedAtNight":4},
                {"quantity":12,"stockedAtNight":4,"discardedAtNight":null}
              ],
              "totalDiscarded":40,
              "totalOverflowed":10
            }]}
            """;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    void givenResponse_whenSerialized_thenJsonMatchesApiContract() throws Exception {
        List<ShipmentResponse> shipments = List.of(new ShipmentResponse(40, 1, 4), new ShipmentResponse(12, 4, null));
        PantryResponse response = new PantryResponse(List.of(new ReserveResponse(FoodType.PLANT, 40, 12, shipments, 40, 10)));

        JsonNode json = objectMapper.valueToTree(response);

        assertEquals(objectMapper.readTree(EXPECTED_JSON), json);
    }
}
