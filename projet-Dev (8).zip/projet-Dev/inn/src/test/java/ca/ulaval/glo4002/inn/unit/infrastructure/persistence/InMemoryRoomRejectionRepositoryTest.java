package ca.ulaval.glo4002.inn.unit.infrastructure.persistence;

import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomOperation;
import ca.ulaval.glo4002.inn.domain.room.RoomRejection;
import ca.ulaval.glo4002.inn.domain.room.RoomRejectionReason;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryRoomRejectionRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class InMemoryRoomRejectionRepositoryTest {

    private static final RoomRejection FIRST_REJECTION =
            new RoomRejection(
                    new RoomNumber(1),
                    RoomOperation.SETUP,
                    2,
                    RoomRejectionReason.ROOM_NUMBER_ALREADY_USED
            );

    private static final RoomRejection SECOND_REJECTION =
            new RoomRejection(
                    new RoomNumber(2),
                    RoomOperation.SETUP,
                    3,
                    RoomRejectionReason.ROOM_NUMBER_ALREADY_USED
            );

    private final InMemoryRoomRejectionRepository repository =
            new InMemoryRoomRejectionRepository();

    @Test
    void givenNoSavedRejection_whenFindingAll_thenReturnsEmptyList() {
        assertTrue(repository.findAllInExecutionOrder().isEmpty());
    }

    @Test
    void givenSavedRejections_whenFindingAll_thenReturnsThemInExecutionOrder() {
        repository.save(FIRST_REJECTION);
        repository.save(SECOND_REJECTION);

        assertEquals(List.of(FIRST_REJECTION, SECOND_REJECTION), repository.findAllInExecutionOrder());
    }
}
