package ca.ulaval.glo4002.inn.unit.infrastructure.persistence;

import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.order.Order;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryOrderRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class InMemoryOrderRepositoryTest {

    private static final Order FIRST_EXECUTED_ORDER = new Order(FoodType.PLANT, 12, 1, 3);
    private static final Order SECOND_EXECUTED_ORDER = new Order(FoodType.MEAT, 5, 2, 5);

    private final InMemoryOrderRepository orderRepository = new InMemoryOrderRepository();

    @Test
    void givenNoSavedOrder_whenFindingAll_thenReturnsEmptyList() {
        assertTrue(orderRepository.findAllInExecutionOrder().isEmpty());
    }

    @Test
    void givenSavedOrders_whenFindingAll_thenReturnsThemInExecutionOrder() {
        orderRepository.save(FIRST_EXECUTED_ORDER);
        orderRepository.save(SECOND_EXECUTED_ORDER);
        assertEquals(List.of(FIRST_EXECUTED_ORDER, SECOND_EXECUTED_ORDER), orderRepository.findAllInExecutionOrder());
    }

}
