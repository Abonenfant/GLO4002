package ca.ulaval.glo4002.inn.unit.domain.action;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.action.BookStayAction;
import ca.ulaval.glo4002.inn.domain.room.RoomAssignmentPolicy;
import ca.ulaval.glo4002.inn.domain.room.RoomDirectory;
import ca.ulaval.glo4002.inn.domain.stay.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

class BookStayActionTest {
    private static final ExistenceNumber EXISTENCE_NUMBER = new ExistenceNumber("EX-4417-Q");
    private static final TravellerProfile PROFILE =
            new TravellerProfile("Aliqua", Species.QUIDAM, 100, HomeDimension.SALARIA);
    private static final int NIGHTS = 3;
    private static final int EXECUTION_NIGHT = 1;

    private final TravellerRepository travellerRepository = mock(TravellerRepository.class);
    private final RoomDirectory roomDirectory = mock(RoomDirectory.class);

    @Test
    void givenBookStayAction_whenExecutingBooking_thenTravellerIsUpdated() {
        BookStayAction bookStayAction = new BookStayAction(EXISTENCE_NUMBER, PROFILE, StayPackage.COMFORT, NIGHTS,
                travellerRepository, new StayFactory(), new RoomAssignmentPolicy(), roomDirectory);

        bookStayAction.execute(EXECUTION_NIGHT);

        verify(travellerRepository).save(any(Traveller.class));
    }

}
