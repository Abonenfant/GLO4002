package ca.ulaval.glo4002.inn.unit.domain.action;

import java.util.Optional;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.action.SubscribeAction;
import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.subscription.Subscription;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionFactory;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRefusalReason;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRepository;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionTerms;

import static org.mockito.Mockito.*;

class SubscribeActionTest {
    private static final String NAME = "Verger";
    private static final int PREVIOUS_NIGHT = 3;
    private static final int EXECUTION_NIGHT = 4;
    private static final SubscriptionRefusalReason NAME_ALREADY_USED = SubscriptionRefusalReason.SUBSCRIPTION_NAME_ALREADY_USED;
    private static final SubscriptionTerms TERMS = new SubscriptionTerms(NAME, FoodType.PLANT, 5, 2);
    private static final SubscriptionFactory REAL_FACTORY = new SubscriptionFactory();
    private static final Subscription CREATED_SUBSCRIPTION = REAL_FACTORY.createActiveSubscription(EXECUTION_NIGHT, TERMS);
    private static final Subscription ACTIVE_SUBSCRIPTION_WITH_SAME_NAME = REAL_FACTORY.createActiveSubscription(PREVIOUS_NIGHT, TERMS);
    private static final Subscription REFUSED_SUBSCRIPTION =
            REAL_FACTORY.createRefusedSubscription(EXECUTION_NIGHT, TERMS, NAME_ALREADY_USED);

    private final SubscriptionRepository subscriptionRepository = mock(SubscriptionRepository.class);
    private final SubscriptionFactory subscriptionFactory = mock(SubscriptionFactory.class);
    private final SubscribeAction subscribeAction = new SubscribeAction(TERMS, subscriptionRepository, subscriptionFactory);

    @Test
    void givenSubscribeAction_whenExecuted_thenActiveSubscriptionIsCreatedAtExecutionNight() {
        subscribeAction.execute(EXECUTION_NIGHT);

        verify(subscriptionFactory).createActiveSubscription(EXECUTION_NIGHT, TERMS);
    }

    @Test
    void givenSubscribeAction_whenExecuted_thenCreatedSubscriptionIsSaved() {
        when(subscriptionFactory.createActiveSubscription(EXECUTION_NIGHT, TERMS)).thenReturn(CREATED_SUBSCRIPTION);

        subscribeAction.execute(EXECUTION_NIGHT);

        verify(subscriptionRepository).save(CREATED_SUBSCRIPTION);
    }

    @Test
    void givenNameUsedByActiveSubscription_whenExecuted_thenSubscriptionIsRefusedForNameAlreadyUsed() {
        givenActiveSubscriptionWithSameName();

        subscribeAction.execute(EXECUTION_NIGHT);

        verify(subscriptionFactory).createRefusedSubscription(EXECUTION_NIGHT, TERMS, NAME_ALREADY_USED);
    }

    @Test
    void givenNameUsedByActiveSubscription_whenExecuted_thenRefusedSubscriptionIsSaved() {
        givenActiveSubscriptionWithSameName();
        when(subscriptionFactory.createRefusedSubscription(EXECUTION_NIGHT, TERMS, NAME_ALREADY_USED)).thenReturn(REFUSED_SUBSCRIPTION);

        subscribeAction.execute(EXECUTION_NIGHT);

        verify(subscriptionRepository).save(REFUSED_SUBSCRIPTION);
    }

    private void givenActiveSubscriptionWithSameName() {
        when(subscriptionRepository.findActiveByName(NAME)).thenReturn(Optional.of(ACTIVE_SUBSCRIPTION_WITH_SAME_NAME));
    }
}
