package ca.ulaval.glo4002.inn.integration.interfaces.rest.dto;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import ca.ulaval.glo4002.inn.domain.stay.HomeDimension;
import ca.ulaval.glo4002.inn.domain.stay.Species;
import ca.ulaval.glo4002.inn.domain.stay.StayPackage;
import ca.ulaval.glo4002.inn.domain.stay.StayRefusalReason;
import ca.ulaval.glo4002.inn.domain.stay.StayStatus;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.ErrorResponse;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.StayResponse;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.TravellerResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TravellerResponseSerializationIT {
    private static final String EXPECTED_TRAVELLER_JSON = """
            {
              "existenceNumber":"EX-4417-Q",
              "travellerName":"Aliqua",
              "species":"QUIDAM",
              "massKg":100,
              "homeDimension":"SALARIA",
              "stays":[
                {
                  "status":"ACTIVE",
                  "reservedAtNight":3,
                  "package":"COMFORT",
                  "nights":5,
                  "roomNumber":1,
                  "firstNight":4,
                  "lastNight":8,
                  "refusalReason":null,
                  "totalBilledAmount":300.00
                },
                {
                  "status":"REFUSED",
                  "reservedAtNight":9,
                  "package":"ROYAL",
                  "nights":2,
                  "roomNumber":null,
                  "firstNight":null,
                  "lastNight":null,
                  "refusalReason":"NO_COMPATIBLE_ROOM",
                  "totalBilledAmount":0.00
                }
              ]
            }
            """;
    private static final String EXPECTED_ERROR_JSON = """
            {
              "error":"TRAVELLER_NOT_FOUND",
              "description":"traveller with existence number XX not found"
            }
            """;

    private final ObjectMapper objectMapper =
            new ObjectMapper().enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS);

    @Test
    void givenTravellerResponse_whenSerialized_thenJsonMatchesApiContract() throws Exception {
        StayResponse activeStay = new StayResponse(
                StayStatus.ACTIVE, 3, StayPackage.COMFORT, 5, 1, 4, 8, null, new BigDecimal("300.00"));
        StayResponse refusedStay = new StayResponse(StayStatus.REFUSED, 9, StayPackage.ROYAL, 2, null, null, null,
                StayRefusalReason.NO_COMPATIBLE_ROOM, new BigDecimal("0.00"));
        TravellerResponse response = new TravellerResponse(
                "EX-4417-Q", "Aliqua", Species.QUIDAM, 100, HomeDimension.SALARIA, List.of(activeStay, refusedStay));

        JsonNode json = objectMapper.valueToTree(response);

        assertEquals(objectMapper.readTree(EXPECTED_TRAVELLER_JSON), json);
    }

    @Test
    void givenNotFoundError_whenSerialized_thenJsonMatchesApiContract() throws Exception {
        ErrorResponse response = new ErrorResponse("TRAVELLER_NOT_FOUND", "traveller with existence number XX not found");

        JsonNode json = objectMapper.valueToTree(response);

        assertEquals(objectMapper.readTree(EXPECTED_ERROR_JSON), json);
    }
}
