package ca.ulaval.glo4002.inn.unit.infrastructure.persistence;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.room.Room;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.stay.Species;
import ca.ulaval.glo4002.inn.infrastructure.persistence.InMemoryRoomRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;

class InMemoryRoomRepositoryTest {
    private static final RoomNumber ROOM_NUMBER = new RoomNumber(1);
    private final InMemoryRoomRepository roomRepository = new InMemoryRoomRepository();
    private final Room room = new Room(ROOM_NUMBER, Species.QUIDAM.requiredConfiguration(), 2);

    @Test
    void givenSavedRoom_whenFindingByNumber_thenReturnsRoom() {
        roomRepository.save(room);

        Optional<Room> foundRoom = roomRepository.findByNumber(ROOM_NUMBER);

        assertEquals(Optional.of(room), foundRoom);
    }

    @Test
    void givenUnknownRoomNumber_whenFindingByNumber_thenReturnsEmpty() {
        Optional<Room> foundRoom = roomRepository.findByNumber(ROOM_NUMBER);

        assertEquals(Optional.empty(), foundRoom);
    }

    @Test
    void givenSavedRooms_whenFindingAll_thenReturnsRoomsInInsertionOrder() {
        Room otherRoom = new Room(new RoomNumber(2), Species.PYROPHORE.requiredConfiguration(), 1);
        roomRepository.save(room);
        roomRepository.save(otherRoom);

        List<Room> foundRooms = roomRepository.findAll();

        assertEquals(List.of(room, otherRoom), foundRooms);
    }
}
