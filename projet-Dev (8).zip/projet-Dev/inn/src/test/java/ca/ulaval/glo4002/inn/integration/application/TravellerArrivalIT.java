package ca.ulaval.glo4002.inn.integration.application;

import java.util.List;

import org.glassfish.hk2.api.ServiceLocator;
import org.glassfish.hk2.utilities.ServiceLocatorUtilities;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.StayService;
import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.room.Room;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomOccupant;
import ca.ulaval.glo4002.inn.domain.room.RoomRepository;
import ca.ulaval.glo4002.inn.domain.stay.HomeDimension;
import ca.ulaval.glo4002.inn.domain.stay.Species;
import ca.ulaval.glo4002.inn.domain.stay.StayPackage;
import ca.ulaval.glo4002.inn.domain.stay.StayStatus;
import ca.ulaval.glo4002.inn.domain.stay.TravellerProfile;
import ca.ulaval.glo4002.inn.domain.stay.TravellerRepository;
import ca.ulaval.glo4002.inn.interfaces.configuration.ApplicationBinder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TravellerArrivalIT {
    private static final ExistenceNumber EXISTENCE_NUMBER = new ExistenceNumber("EX-01");
    private static final String NAME = "Aliqua";
    private static final TravellerProfile PROFILE = new TravellerProfile(NAME, Species.QUIDAM, 100, HomeDimension.SALARIA);
    private static final RoomNumber ROOM_NUMBER = new RoomNumber(1);
    private static final int NIGHTS = 3;

    private final ServiceLocator serviceLocator = ServiceLocatorUtilities.bind(new ApplicationBinder());
    private final StayService stayService = serviceLocator.getService(StayService.class);
    private final Inn inn = serviceLocator.getService(Inn.class);
    private final TravellerRepository travellerRepository = serviceLocator.getService(TravellerRepository.class);
    private final RoomRepository roomRepository = serviceLocator.getService(RoomRepository.class);
    private final Room room = new Room(ROOM_NUMBER, Species.QUIDAM.requiredConfiguration(), 2);

    @BeforeEach
    void setUp() {
        roomRepository.save(room);
        stayService.bookStay(EXISTENCE_NUMBER, PROFILE, StayPackage.COMFORT, NIGHTS);
    }

    @AfterEach
    void tearDown() {
        serviceLocator.shutdown();
    }

    @Test
    void givenBookingExecutedTonight_whenNightEnds_thenStayIsStillBooked() {
        inn.passNight();

        assertEquals(StayStatus.BOOKED, latestStayStatus());
    }

    @Test
    void givenBookingExecutedTonight_whenNightEnds_thenRoomHasNoOccupantYet() {
        inn.passNight();

        assertTrue(room.getOccupants().isEmpty());
    }

    @Test
    void givenBookedStay_whenItsFirstNightPasses_thenStayIsActive() {
        inn.passNight();

        inn.passNight();

        assertEquals(StayStatus.ACTIVE, latestStayStatus());
    }

    @Test
    void givenBookedStay_whenItsFirstNightPasses_thenTravellerIsAnOccupantOfItsRoom() {
        inn.passNight();

        inn.passNight();

        assertEquals(List.of(new RoomOccupant(EXISTENCE_NUMBER, NAME)), room.getOccupants());
    }

    private StayStatus latestStayStatus() {
        return travellerRepository.findByExistenceNumber(EXISTENCE_NUMBER).orElseThrow().getLatestStay().getStatus();
    }
}
