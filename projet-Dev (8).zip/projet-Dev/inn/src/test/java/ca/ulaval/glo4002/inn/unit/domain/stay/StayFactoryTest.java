package ca.ulaval.glo4002.inn.unit.domain.stay;

import java.util.Optional;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.stay.HomeDimension;
import ca.ulaval.glo4002.inn.domain.stay.Species;
import ca.ulaval.glo4002.inn.domain.stay.Stay;
import ca.ulaval.glo4002.inn.domain.stay.StayFactory;
import ca.ulaval.glo4002.inn.domain.stay.StayPackage;
import ca.ulaval.glo4002.inn.domain.stay.StayRefusalReason;
import ca.ulaval.glo4002.inn.domain.stay.StayStatus;
import ca.ulaval.glo4002.inn.domain.stay.StayTerms;
import ca.ulaval.glo4002.inn.domain.stay.TravellerProfile;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

class StayFactoryTest {
    private static final TravellerProfile TRAVELLER_PROFILE =
            new TravellerProfile("Aliqua", Species.QUIDAM, 100, HomeDimension.SALARIA);
    private static final int NIGHTS = 5;
    private static final StayTerms TERMS = new StayTerms(TRAVELLER_PROFILE, StayPackage.COMFORT, NIGHTS);
    private static final int EXECUTION_NIGHT = 3;
    private static final RoomNumber ROOM_NUMBER = new RoomNumber(1);
    private static final StayRefusalReason REFUSAL_REASON = StayRefusalReason.NO_COMPATIBLE_ROOM;

    private final StayFactory stayFactory = new StayFactory();

    @Test
    void givenTerms_whenCreatingBookedStay_thenStayIsBooked() {
        Stay stay = stayFactory.createBookedStay(EXECUTION_NIGHT, TERMS, ROOM_NUMBER);

        assertEquals(StayStatus.BOOKED, stay.getStatus());
    }

    @Test
    void givenTerms_whenCreatingBookedStay_thenStayKeepsItsTerms() {
        Stay stay = stayFactory.createBookedStay(EXECUTION_NIGHT, TERMS, ROOM_NUMBER);

        assertAll(
                () -> assertEquals(TRAVELLER_PROFILE, stay.getTravellerProfile()),
                () -> assertEquals(StayPackage.COMFORT, stay.getStayPackage()),
                () -> assertEquals(NIGHTS, stay.getNights()));
    }

    @Test
    void givenExecutionNight_whenCreatingBookedStay_thenStayIsReservedAtThatNight() {
        Stay stay = stayFactory.createBookedStay(EXECUTION_NIGHT, TERMS, ROOM_NUMBER);

        assertEquals(EXECUTION_NIGHT, stay.getReservedAtNight());
    }

    @Test
    void givenRoom_whenCreatingBookedStay_thenStayHasThatRoom() {
        Stay stay = stayFactory.createBookedStay(EXECUTION_NIGHT, TERMS, ROOM_NUMBER);

        assertEquals(Optional.of(ROOM_NUMBER), stay.getRoomNumber());
    }

    @Test
    void givenReason_whenCreatingRefusedStay_thenStayIsRefusedWithThatReason() {
        Stay stay = stayFactory.createRefusedStay(EXECUTION_NIGHT, TERMS, REFUSAL_REASON);

        assertAll(
                () -> assertEquals(StayStatus.REFUSED, stay.getStatus()),
                () -> assertEquals(Optional.of(REFUSAL_REASON), stay.getRefusalReason()));
    }

    @Test
    void givenExecutionNight_whenCreatingRefusedStay_thenRefusalNightIsReservedAtNight() {
        Stay stay = stayFactory.createRefusedStay(EXECUTION_NIGHT, TERMS, REFUSAL_REASON);

        assertEquals(EXECUTION_NIGHT, stay.getReservedAtNight());
    }
}
