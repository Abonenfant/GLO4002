package ca.ulaval.glo4002.inn.unit.domain.room;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.room.RoomNumber;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class RoomNumberTest {
    @Test
    void givenPositiveRoomNumber_whenCreating_thenKeepsValue() {
        RoomNumber roomNumber = new RoomNumber(1);

        assertEquals(1, roomNumber.value());
    }

    @Test
    void givenZeroRoomNumber_whenCreating_thenRejectsValue() {
        assertThrows(IllegalArgumentException.class, () -> new RoomNumber(0));
    }

    @Test
    void givenNegativeRoomNumber_whenCreating_thenRejectsValue() {
        assertThrows(IllegalArgumentException.class, () -> new RoomNumber(-1));
    }
}
