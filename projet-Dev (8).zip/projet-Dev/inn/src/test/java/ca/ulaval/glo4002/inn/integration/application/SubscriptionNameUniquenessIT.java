package ca.ulaval.glo4002.inn.integration.application;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.OrderService;
import ca.ulaval.glo4002.inn.application.SubscriptionService;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.order.OrderFactory;
import ca.ulaval.glo4002.inn.domain.order.OrderRepository;
import ca.ulaval.glo4002.inn.domain.subscription.Subscription;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionFactory;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRefusalReason;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRepository;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionStatus;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionTerms;
import ca.ulaval.glo4002.inn.unit.domain.Inn.InnFactory;
import ca.ulaval.glo4002.inn.unit.domain.Inn.InnTestFactory;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SubscriptionNameUniquenessIT {
    private static final String NAME = "Verger";
    private static final int QUANTITY = 5;
    private static final int PERIOD = 2;
    private static final int ORDER_QUANTITY = 7;
    private static final int NO_DELIVERY_DELAY = 0;
    private static final int FIRST_DELIVERY_NIGHT = 1 + PERIOD;
    private static final SubscriptionTerms TERMS = new SubscriptionTerms(NAME, FoodType.MINERAL, QUANTITY, PERIOD);
    private static final SubscriptionTerms SAME_NAME_TERMS = new SubscriptionTerms(NAME, FoodType.MEAT, QUANTITY, PERIOD);

    InnFactory factoryTest = InnTestFactory.createFactory();
    Inn inn = factoryTest.getInn();
    private final OrderRepository orderRepository = factoryTest.getOrderRepository();
    private final SubscriptionRepository subscriptionRepository = factoryTest.getSubscriptionRepository();

    OrderService orderService =
            new OrderService(inn, orderRepository, new OrderFactory());

    private final SubscriptionService subscriptionService =
            new SubscriptionService(inn, subscriptionRepository, new SubscriptionFactory());

    @Test
    void givenActiveSubscription_whenSameNameIsSubscribedTheNextNight_thenNewSubscriptionIsRefused() {
        subscriptionService.subscribe(TERMS);
        inn.passNight();
        subscriptionService.subscribe(SAME_NAME_TERMS);

        inn.passNight();

        assertEquals(List.of(SubscriptionStatus.ACTIVE, SubscriptionStatus.REFUSED), subscriptionStatuses());
    }

    @Test
    void givenTwoSubscriptionsWithSameNameTheSameNight_whenNightPasses_thenOnlyTheFirstArrivedIsActive() {
        subscriptionService.subscribe(TERMS);
        subscriptionService.subscribe(SAME_NAME_TERMS);

        inn.passNight();

        assertEquals(List.of(SubscriptionStatus.ACTIVE, SubscriptionStatus.REFUSED), subscriptionStatuses());
    }

    @Test
    void givenNameConflict_whenNightPasses_thenRefusedSubscriptionIsKeptWithItsReason() {
        subscriptionService.subscribe(TERMS);
        subscriptionService.subscribe(SAME_NAME_TERMS);

        inn.passNight();

        Subscription refusedSubscription = subscriptionRepository.findAllInExecutionOrder().getLast();
        assertEquals(Optional.of(SubscriptionRefusalReason.SUBSCRIPTION_NAME_ALREADY_USED), refusedSubscription.getRefusalReason());
    }

    @Test
    void givenNameConflict_whenNightPasses_thenNextActionOfTheNightIsStillExecuted() {
        subscriptionService.subscribe(TERMS);
        subscriptionService.subscribe(SAME_NAME_TERMS);
        orderService.placeOrder(FoodType.PLANT, ORDER_QUANTITY, NO_DELIVERY_DELAY);

        inn.passNight();

        assertEquals(ORDER_QUANTITY, inn.getPantry().getReserve(FoodType.PLANT).stock());
    }

    @Test
    void givenRefusedSubscription_whenItsDeliveryNightComes_thenNothingIsDeliveredForIt() {
        subscriptionService.subscribe(TERMS);
        subscriptionService.subscribe(SAME_NAME_TERMS);

        passNightsUntil(FIRST_DELIVERY_NIGHT);

        assertEquals(0, inn.getPantry().getReserve(FoodType.MEAT).stock());
    }

    private List<SubscriptionStatus> subscriptionStatuses() {
        return subscriptionRepository.findAllInExecutionOrder().stream().map(Subscription::getStatus).toList();
    }

    private void passNightsUntil(int night) {
        while (inn.getCurrentNight() < night) {
            inn.passNight();
        }
    }
}
