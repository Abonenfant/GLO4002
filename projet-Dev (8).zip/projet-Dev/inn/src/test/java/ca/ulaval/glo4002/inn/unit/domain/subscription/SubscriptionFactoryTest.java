package ca.ulaval.glo4002.inn.unit.domain.subscription;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.subscription.Subscription;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionFactory;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRefusalReason;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionStatus;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionTerms;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SubscriptionFactoryTest {
    private static final String NAME = "Verger";
    private static final int QUANTITY = 5;
    private static final int PERIOD = 2;
    private static final int SUBSCRIBED_AT_NIGHT = 3;
    private static final SubscriptionTerms TERMS = new SubscriptionTerms(NAME, FoodType.PLANT, QUANTITY, PERIOD);
    private static final SubscriptionRefusalReason REFUSAL_REASON = SubscriptionRefusalReason.SUBSCRIPTION_NAME_ALREADY_USED;

    private final SubscriptionFactory subscriptionFactory = new SubscriptionFactory();

    @Test
    void givenTerms_whenCreatingActiveSubscription_thenSubscriptionIsActive() {
        Subscription subscription = subscriptionFactory.createActiveSubscription(SUBSCRIBED_AT_NIGHT, TERMS);

        assertEquals(SubscriptionStatus.ACTIVE, subscription.getStatus());
    }

    @Test
    void givenTerms_whenCreatingActiveSubscription_thenSubscriptionKeepsItsTerms() {
        Subscription subscription = subscriptionFactory.createActiveSubscription(SUBSCRIBED_AT_NIGHT, TERMS);

        assertAll(
                () -> assertEquals(NAME, subscription.getName()),
                () -> assertEquals(FoodType.PLANT, subscription.getFoodType()),
                () -> assertEquals(QUANTITY, subscription.getQuantity()),
                () -> assertEquals(PERIOD, subscription.getPeriod())
        );
    }

    @Test
    void givenTerms_whenCreatingActiveSubscription_thenHasNoRefusalReason() {
        Subscription subscription = subscriptionFactory.createActiveSubscription(SUBSCRIBED_AT_NIGHT, TERMS);

        assertTrue(subscription.getRefusalReason().isEmpty());
    }

    @Test
    void givenRefusalReason_whenCreatingRefusedSubscription_thenSubscriptionIsRefused() {
        Subscription subscription = subscriptionFactory.createRefusedSubscription(SUBSCRIBED_AT_NIGHT, TERMS, REFUSAL_REASON);

        assertEquals(SubscriptionStatus.REFUSED, subscription.getStatus());
    }

    @Test
    void givenRefusalReason_whenCreatingRefusedSubscription_thenKeepsRefusalReason() {
        Subscription subscription = subscriptionFactory.createRefusedSubscription(SUBSCRIBED_AT_NIGHT, TERMS, REFUSAL_REASON);

        assertEquals(REFUSAL_REASON, subscription.getRefusalReason().orElseThrow());
    }
}
