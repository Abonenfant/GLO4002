package ca.ulaval.glo4002.inn.unit.domain;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.ExistenceNumber;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ExistenceNumberTest {
    @Test
    void givenNonBlankExistenceNumber_whenCreating_thenKeepsValue() {
        ExistenceNumber existenceNumber = new ExistenceNumber("EX-4417-Q");

        assertEquals("EX-4417-Q", existenceNumber.value());
    }

    @Test
    void givenBlankExistenceNumber_whenCreating_thenRejectsValue() {
        assertThrows(IllegalArgumentException.class, () -> new ExistenceNumber(" "));
    }

    @Test
    void givenNullExistenceNumber_whenCreating_thenRejectsValue() {
        assertThrows(IllegalArgumentException.class, () -> new ExistenceNumber(null));
    }
}
