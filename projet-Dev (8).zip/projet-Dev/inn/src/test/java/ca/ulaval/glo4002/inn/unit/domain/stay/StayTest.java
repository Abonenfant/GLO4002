package ca.ulaval.glo4002.inn.unit.domain.stay;

import java.util.Optional;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.stay.HomeDimension;
import ca.ulaval.glo4002.inn.domain.stay.Money;
import ca.ulaval.glo4002.inn.domain.stay.Species;
import ca.ulaval.glo4002.inn.domain.stay.Stay;
import ca.ulaval.glo4002.inn.domain.stay.StayFactory;
import ca.ulaval.glo4002.inn.domain.stay.StayPackage;
import ca.ulaval.glo4002.inn.domain.stay.StayRefusalReason;
import ca.ulaval.glo4002.inn.domain.stay.StayTerms;
import ca.ulaval.glo4002.inn.domain.stay.TravellerProfile;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class StayTest {
    private static final TravellerProfile TRAVELLER_PROFILE =
            new TravellerProfile("Aliqua", Species.QUIDAM, 100, HomeDimension.SALARIA);
    private static final int NIGHTS = 5;
    private static final int ONE_NIGHT = 1;
    private static final int RESERVED_AT_NIGHT = 3;
    private static final int FIRST_NIGHT = 4;
    private static final int LAST_NIGHT = 8;
    private static final RoomNumber ROOM_NUMBER = new RoomNumber(1);

    private final StayFactory stayFactory = new StayFactory();
    private final Stay bookedStay = createBookedStay(NIGHTS);
    private final Stay refusedStay = stayFactory.createRefusedStay(
            RESERVED_AT_NIGHT, termsFor(NIGHTS), StayRefusalReason.NO_COMPATIBLE_ROOM);

    @Test
    void givenBookedStay_whenReadingFirstNight_thenIsTheNightAfterItsReservation() {
        assertEquals(Optional.of(FIRST_NIGHT), bookedStay.getFirstNight());
    }

    @Test
    void givenBookedStay_whenReadingLastNight_thenCoversAllItsNights() {
        assertEquals(Optional.of(LAST_NIGHT), bookedStay.getLastNight());
    }

    @Test
    void givenOneNightStay_whenReadingLastNight_thenIsItsFirstNight() {
        Stay oneNightStay = createBookedStay(ONE_NIGHT);

        assertEquals(oneNightStay.getFirstNight(), oneNightStay.getLastNight());
    }

    @Test
    void givenBookedStay_whenReadingRefusalReason_thenHasNone() {
        assertTrue(bookedStay.getRefusalReason().isEmpty());
    }

    @Test
    void givenRefusedStay_whenReadingRoomAndNights_thenHasNone() {
        assertAll(
                () -> assertTrue(refusedStay.getRoomNumber().isEmpty()),
                () -> assertTrue(refusedStay.getFirstNight().isEmpty()),
                () -> assertTrue(refusedStay.getLastNight().isEmpty()));
    }

    @Test
    void givenNewStay_whenReadingTotalBilledAmount_thenIsZero() {
        assertEquals(Money.ZERO, bookedStay.getTotalBilledAmount());
    }

    private Stay createBookedStay(int nights) {
        return stayFactory.createBookedStay(RESERVED_AT_NIGHT, termsFor(nights), ROOM_NUMBER);
    }

    private static StayTerms termsFor(int nights) {
        return new StayTerms(TRAVELLER_PROFILE, StayPackage.COMFORT, nights);
    }
}
