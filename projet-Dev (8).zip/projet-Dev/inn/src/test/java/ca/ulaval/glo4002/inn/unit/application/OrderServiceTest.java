package ca.ulaval.glo4002.inn.unit.application;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import ca.ulaval.glo4002.inn.application.OrderService;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.action.Action;
import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.order.Order;
import ca.ulaval.glo4002.inn.domain.order.OrderFactory;
import ca.ulaval.glo4002.inn.domain.order.OrderRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

public class OrderServiceTest {

    private static final int CURRENT_NIGHT = 6;
    private static final Order DELIVERED_TONIGHT = new Order(FoodType.PLANT, 10, 3, CURRENT_NIGHT);
    private static final Order DELIVERED_NIGHT_7 = new Order(FoodType.MEAT, 10, 5, 7);
    private static final Order DELIVERED_NIGHT_9 = new Order(FoodType.PLANT, 10, 4, 9);
    private static final Order FIRST_EXECUTED_FOR_NIGHT_8 = new Order(FoodType.MEAT, 20, 5, 8);
    private static final Order SECOND_EXECUTED_FOR_NIGHT_8 = new Order(FoodType.PLANT, 10, 5, 8);

    private static final int QUANTITY = 12;
    private static final int DELIVERY_DELAY = 2;
    private static final int EXECUTION_NIGHT = 4;

    private final Inn inn = mock(Inn.class);
    private final OrderRepository orderRepository = mock(OrderRepository.class);
    private final OrderService orderService = new OrderService(inn, orderRepository, new OrderFactory());

    @BeforeEach
    void setup() {
        when(inn.getCurrentNight()).thenReturn(CURRENT_NIGHT);
    }

    @Test
    void givenPlacedOrder_whenNotYetExecuted_thenNoOrderIsSaved() {
        orderService.placeOrder(FoodType.PLANT, QUANTITY, DELIVERY_DELAY);

        verifyNoInteractions(orderRepository);
    }

    @Test
    void givenPlacedOrder_whenItsActionIsExecuted_thenOrderIsSavedAtExecutionNight() {
        orderService.placeOrder(FoodType.PLANT, QUANTITY, DELIVERY_DELAY);

        captureQueuedAction().execute(EXECUTION_NIGHT);

        Order expectedOrder = new Order(FoodType.PLANT, QUANTITY, EXECUTION_NIGHT, EXECUTION_NIGHT + DELIVERY_DELAY);
        verify(orderRepository).save(expectedOrder);
    }

    @Test
    void givenOrderDeliveredTonight_whenFindingOrdersInTransit_thenItIsExcluded() {
        givenExecutedOrders(DELIVERED_TONIGHT, DELIVERED_NIGHT_7);

        assertEquals(List.of(DELIVERED_NIGHT_7), orderService.findOrdersInTransit());
    }

    @Test
    void givenDifferentDeliveryNight_whenFindingOrdersInTransit_thenSortedByDeliveryNight() {
        givenExecutedOrders(DELIVERED_NIGHT_9, DELIVERED_NIGHT_7);

        assertEquals(List.of(DELIVERED_NIGHT_7, DELIVERED_NIGHT_9), orderService.findOrdersInTransit());
    }

    @Test
    void givenSameDeliveryNight_whenFindingOrdersInTransit_thenKeptInExecutionOrder() {
        givenExecutedOrders(FIRST_EXECUTED_FOR_NIGHT_8, SECOND_EXECUTED_FOR_NIGHT_8);

        List<Order> expected = List.of(FIRST_EXECUTED_FOR_NIGHT_8, SECOND_EXECUTED_FOR_NIGHT_8);
        assertEquals(expected, orderService.findOrdersInTransit());
    }

    private void givenExecutedOrders(Order... ordersInExecutionOrder) {
        when(orderRepository.findAllInExecutionOrder()).thenReturn(List.of(ordersInExecutionOrder));
    }

    private Action captureQueuedAction() {
        ArgumentCaptor<Action> queuedAction = ArgumentCaptor.forClass(Action.class);
        verify(inn).addActionToQueue(queuedAction.capture());
        return queuedAction.getValue();
    }
}
