package ca.ulaval.glo4002.inn.integration.application;

import java.util.List;
import java.util.Optional;

import org.glassfish.hk2.api.ServiceLocator;
import org.glassfish.hk2.utilities.ServiceLocatorUtilities;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.application.StayService;
import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.room.Room;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomRepository;
import ca.ulaval.glo4002.inn.domain.stay.*;
import ca.ulaval.glo4002.inn.interfaces.configuration.ApplicationBinder;

import static org.junit.jupiter.api.Assertions.assertEquals;

class StayBookingIT {
    private static final ExistenceNumber EXISTENCE_NUMBER = new ExistenceNumber("EX-4417-Q");
    private static final TravellerProfile PROFILE =
            new TravellerProfile("Aliqua", Species.QUIDAM, 100, HomeDimension.SALARIA);
    private static final RoomNumber ROOM_NUMBER = new RoomNumber(1);
    private static final int NIGHTS = 2;

    private final ServiceLocator serviceLocator = ServiceLocatorUtilities.bind(new ApplicationBinder());
    private final StayService stayService = serviceLocator.getService(StayService.class);
    private final Inn inn = serviceLocator.getService(Inn.class);
    private final TravellerRepository travellerRepository = serviceLocator.getService(TravellerRepository.class);
    private final RoomRepository roomRepository = serviceLocator.getService(RoomRepository.class);

    @AfterEach
    void tearDown() {
        serviceLocator.shutdown();
    }

    @Test
    void givenPendingBooking_whenNightHasNotPassed_thenPlaceRemainsAvailable() {
        Room room = new Room(ROOM_NUMBER, Species.QUIDAM.requiredConfiguration(), 1);
        roomRepository.save(room);

        stayService.bookStay(EXISTENCE_NUMBER, PROFILE, StayPackage.COMFORT, NIGHTS);

        assertEquals(1, room.getFreePlaces());
    }

    @Test
    void givenPendingBookingAndAvailableRoom_whenNightPasses_thenPlaceIsReserved() {
        Room room = new Room(ROOM_NUMBER, Species.QUIDAM.requiredConfiguration(), 1);
        roomRepository.save(room);
        stayService.bookStay(EXISTENCE_NUMBER, PROFILE, StayPackage.COMFORT, NIGHTS);

        inn.passNight();

        assertEquals(List.of(EXISTENCE_NUMBER), room.getReservedExistenceNumbers());
    }

    @Test
    void givenPendingBookingWithoutRooms_whenNightPasses_thenRefusalIsSaved() {
        stayService.bookStay(EXISTENCE_NUMBER, PROFILE, StayPackage.COMFORT, NIGHTS);

        inn.passNight();

        assertEquals(Optional.of(StayRefusalReason.NO_COMPATIBLE_ROOM),
                travellerRepository.findByExistenceNumber(EXISTENCE_NUMBER).orElseThrow()
                        .getLatestStay().getRefusalReason());
    }

    @Test
    void givenPendingBookingButAlreadyStaying_whenNightPasses_thenRefusalIsSaved() {
        Room room = new Room(ROOM_NUMBER, Species.QUIDAM.requiredConfiguration(), 1);
        roomRepository.save(room);
        RoomNumber anotherRoomNumber = new RoomNumber(4);
        Room anotherRoom = new Room(anotherRoomNumber, Species.QUIDAM.requiredConfiguration(), 1);
        roomRepository.save(anotherRoom);

        stayService.bookStay(EXISTENCE_NUMBER, PROFILE, StayPackage.COMFORT, NIGHTS);
        inn.passNight();
        stayService.bookStay(EXISTENCE_NUMBER, PROFILE, StayPackage.COMFORT, NIGHTS);
        inn.passNight();

        assertEquals(Optional.of(StayRefusalReason.ALREADY_STAYING),
                travellerRepository.findByExistenceNumber(EXISTENCE_NUMBER).orElseThrow()
                        .getLatestStay().getRefusalReason());
    }

    @Test
    void givenPreviouslyRefusedStaySinceNoRoomAndNewBooking_whenNightPasses_thenPlaceIsReserved() {
        stayService.bookStay(EXISTENCE_NUMBER, PROFILE, StayPackage.COMFORT, NIGHTS);
        inn.passNight();
        assertEquals(StayStatus.REFUSED,
                travellerRepository.findByExistenceNumber(EXISTENCE_NUMBER).orElseThrow()
                        .getLatestStay().getStatus());

        Room room = new Room(ROOM_NUMBER, Species.QUIDAM.requiredConfiguration(), 1);
        roomRepository.save(room);
        stayService.bookStay(EXISTENCE_NUMBER, PROFILE, StayPackage.COMFORT, NIGHTS);

        inn.passNight();

        assertEquals(List.of(EXISTENCE_NUMBER), room.getReservedExistenceNumbers());
        assertEquals(StayStatus.BOOKED,
                travellerRepository.findByExistenceNumber(EXISTENCE_NUMBER).orElseThrow()
                        .getLatestStay().getStatus());
    }

}
