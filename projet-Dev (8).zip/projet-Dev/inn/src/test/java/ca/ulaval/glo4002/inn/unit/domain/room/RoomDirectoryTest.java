package ca.ulaval.glo4002.inn.unit.domain.room;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.room.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class RoomDirectoryTest {
    private static final RoomNumber ROOM_NUMBER = new RoomNumber(1);
    private static final int CAPACITY = 2;
    private static final ExistenceNumber EXISTENCE_NUMBER = new ExistenceNumber("EX-4417-Q");
    private static final RoomConfiguration CONFIGURATION =
            new RoomConfiguration(Atmosphere.STANDARD, Gravity.NORMAL, Temperature.TEMPERATE);

    private RoomRepository roomRepository;
    private RoomDirectory roomDirectory;
    private Room room;

    @BeforeEach
    void setUp() {
        roomRepository = mock(RoomRepository.class);
        roomDirectory = new RoomDirectory(roomRepository);
        room = new Room(ROOM_NUMBER, CONFIGURATION, CAPACITY);
    }

    @Test
    void givenCompatibleAvailableRoom_whenFindingCandidates_thenReturnsRoom() {
        when(roomRepository.findAll()).thenReturn(List.of(room));

        List<Room> candidates = roomDirectory.findCompatibleRoomsWithAvailablePlace(CONFIGURATION);

        assertEquals(List.of(room), candidates);
    }

    @Test
    void givenIncompatibleRoom_whenFindingCandidates_thenDoesNotReturnRoom() {
        when(roomRepository.findAll()).thenReturn(List.of(room));
        RoomConfiguration expectedConfiguration =
                new RoomConfiguration(Atmosphere.HUMID, Gravity.LIGHT, Temperature.COLD);

        List<Room> candidates = roomDirectory.findCompatibleRoomsWithAvailablePlace(expectedConfiguration);

        assertEquals(List.of(), candidates);
    }

    @Test
    void givenFullCompatibleRoom_whenFindingCandidates_thenDoesNotReturnRoom() {
        room.reservePlace(new ExistenceNumber("EX-01"));
        room.reservePlace(new ExistenceNumber("EX-02"));
        when(roomRepository.findAll()).thenReturn(List.of(room));

        List<Room> candidates = roomDirectory.findCompatibleRoomsWithAvailablePlace(CONFIGURATION);

        assertEquals(List.of(), candidates);
    }

    @Test
    void givenExistingRoom_whenReservingPlace_thenDirectoryDelegatesToRoom() {
        Room roomMock = mock(Room.class);
        when(roomRepository.findByNumber(ROOM_NUMBER)).thenReturn(Optional.of(roomMock));

        roomDirectory.reservePlace(ROOM_NUMBER, EXISTENCE_NUMBER);

        verify(roomMock).reservePlace(EXISTENCE_NUMBER);
    }

    @Test
    void givenExistingRoom_whenOccupyingReservedPlace_thenDirectoryDelegatesToRoom() {
        Room roomMock = mock(Room.class);
        RoomOccupant occupant = new RoomOccupant(EXISTENCE_NUMBER, "Aliqua");
        when(roomRepository.findByNumber(ROOM_NUMBER)).thenReturn(Optional.of(roomMock));

        roomDirectory.occupyReservedPlace(ROOM_NUMBER, occupant);

        verify(roomMock).occupyReservedPlace(occupant);
    }

    @Test
    void givenExistingRoom_whenReleasingPlace_thenDirectoryDelegatesToRoom() {
        Room roomMock = mock(Room.class);
        when(roomRepository.findByNumber(ROOM_NUMBER)).thenReturn(Optional.of(roomMock));

        roomDirectory.releasePlace(ROOM_NUMBER, EXISTENCE_NUMBER);

        verify(roomMock).releasePlace(EXISTENCE_NUMBER);
    }
}
