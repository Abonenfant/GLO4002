package ca.ulaval.glo4002.inn.unit.interfaces.rest.assemblers;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.stay.HomeDimension;
import ca.ulaval.glo4002.inn.domain.stay.Species;
import ca.ulaval.glo4002.inn.domain.stay.Stay;
import ca.ulaval.glo4002.inn.domain.stay.StayFactory;
import ca.ulaval.glo4002.inn.domain.stay.StayPackage;
import ca.ulaval.glo4002.inn.domain.stay.StayRefusalReason;
import ca.ulaval.glo4002.inn.domain.stay.StayStatus;
import ca.ulaval.glo4002.inn.domain.stay.StayTerms;
import ca.ulaval.glo4002.inn.domain.stay.Traveller;
import ca.ulaval.glo4002.inn.domain.stay.TravellerProfile;
import ca.ulaval.glo4002.inn.interfaces.rest.assemblers.TravellerAssembler;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.StayResponse;
import ca.ulaval.glo4002.inn.interfaces.rest.dto.responses.TravellerResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TravellerAssemblerTest {
    private static final ExistenceNumber EXISTENCE_NUMBER = new ExistenceNumber("EX-01");
    private static final TravellerProfile FIRST_PROFILE =
            new TravellerProfile("Aliqua", Species.QUIDAM, 100, HomeDimension.SALARIA);
    private static final TravellerProfile LATEST_PROFILE =
            new TravellerProfile("Lorem", Species.PYROPHORE, 90, HomeDimension.NOCTAMBULIE);
    private static final int NIGHTS = 3;
    private static final int RESERVATION_NIGHT = 1;
    private static final int FIRST_NIGHT = 2;
    private static final int LAST_NIGHT = 4;
    private static final int REFUSAL_NIGHT = 2;
    private static final int ROOM_NUMBER = 1;
    private static final BigDecimal NOTHING_BILLED = new BigDecimal("0.00");

    private final StayFactory stayFactory = new StayFactory();

    @Test
    void givenBookedStay_whenAssembling_thenStayHasItsRoomAndNights() {
        Traveller traveller = travellerWithBookedStay();

        StayResponse expected = new StayResponse(StayStatus.BOOKED, RESERVATION_NIGHT, StayPackage.COMFORT, NIGHTS,
                ROOM_NUMBER, FIRST_NIGHT, LAST_NIGHT, null, NOTHING_BILLED);
        assertEquals(List.of(expected), TravellerAssembler.toResponse(traveller).stays());
    }

    @Test
    void givenRefusedStay_whenAssembling_thenStayHasItsReasonButNoRoomNorNights() {
        Traveller traveller = new Traveller(EXISTENCE_NUMBER, stayFactory.createRefusedStay(
                REFUSAL_NIGHT, termsFor(FIRST_PROFILE), StayRefusalReason.NO_COMPATIBLE_ROOM));

        StayResponse expected = new StayResponse(StayStatus.REFUSED, REFUSAL_NIGHT, StayPackage.COMFORT, NIGHTS,
                null, null, null, StayRefusalReason.NO_COMPATIBLE_ROOM, NOTHING_BILLED);
        assertEquals(List.of(expected), TravellerAssembler.toResponse(traveller).stays());
    }

    @Test
    void givenTraveller_whenAssembling_thenHeaderDescribesTheTraveller() {
        Traveller traveller = travellerWithBookedStay();

        TravellerResponse response = TravellerAssembler.toResponse(traveller);

        TravellerResponse expected = new TravellerResponse("EX-01", "Aliqua", Species.QUIDAM, 100,
                HomeDimension.SALARIA, response.stays());
        assertEquals(expected, response);
    }

    @Test
    void givenSeveralStays_whenAssembling_thenHeaderComesFromTheMostRecentStay() {
        Traveller traveller = travellerWithBookedStay();
        traveller.addStay(refusedLatestStay());

        TravellerResponse response = TravellerAssembler.toResponse(traveller);

        TravellerResponse expected = new TravellerResponse("EX-01", "Lorem", Species.PYROPHORE, 90,
                HomeDimension.NOCTAMBULIE, response.stays());
        assertEquals(expected, response);
    }

    @Test
    void givenSeveralStays_whenAssembling_thenStaysAreInExecutionOrder() {
        Traveller traveller = travellerWithBookedStay();
        traveller.addStay(refusedLatestStay());

        List<StayStatus> statuses = TravellerAssembler.toResponse(traveller).stays().stream()
                .map(StayResponse::status)
                .toList();

        assertEquals(List.of(StayStatus.BOOKED, StayStatus.REFUSED), statuses);
    }

    private Traveller travellerWithBookedStay() {
        return new Traveller(EXISTENCE_NUMBER,
                stayFactory.createBookedStay(RESERVATION_NIGHT, termsFor(FIRST_PROFILE), new RoomNumber(ROOM_NUMBER)));
    }

    private Stay refusedLatestStay() {
        return stayFactory.createRefusedStay(REFUSAL_NIGHT, termsFor(LATEST_PROFILE), StayRefusalReason.ALREADY_STAYING);
    }

    private static StayTerms termsFor(TravellerProfile profile) {
        return new StayTerms(profile, StayPackage.COMFORT, NIGHTS);
    }
}
