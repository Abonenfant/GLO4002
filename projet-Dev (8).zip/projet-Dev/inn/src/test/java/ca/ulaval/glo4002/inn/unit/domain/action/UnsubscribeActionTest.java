package ca.ulaval.glo4002.inn.unit.domain.action;

import java.util.Optional;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.action.UnsubscribeAction;
import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.subscription.Subscription;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionFactory;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionRepository;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionStatus;
import ca.ulaval.glo4002.inn.domain.subscription.SubscriptionTerms;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class UnsubscribeActionTest {
    private static final String NAME = "Verger";
    private static final int SUBSCRIBED_AT_NIGHT = 1;
    private static final int EXECUTION_NIGHT = 4;
    private static final SubscriptionTerms TERMS = new SubscriptionTerms(NAME, FoodType.PLANT, 5, 2);

    private final SubscriptionRepository subscriptionRepository = mock(SubscriptionRepository.class);
    private final Subscription activeSubscription = new SubscriptionFactory().createActiveSubscription(SUBSCRIBED_AT_NIGHT, TERMS);
    private final UnsubscribeAction unsubscribeAction = new UnsubscribeAction(NAME, subscriptionRepository);

    @Test
    void givenActiveSubscriptionWithName_whenExecuted_thenSubscriptionIsCancelled() {
        when(subscriptionRepository.findActiveByName(NAME)).thenReturn(Optional.of(activeSubscription));

        unsubscribeAction.execute(EXECUTION_NIGHT);

        assertEquals(SubscriptionStatus.CANCELLED, activeSubscription.getStatus());
    }

    @Test
    void givenNoActiveSubscriptionWithName_whenExecuted_thenNothingFails() {
        when(subscriptionRepository.findActiveByName(NAME)).thenReturn(Optional.empty());

        assertDoesNotThrow(() -> unsubscribeAction.execute(EXECUTION_NIGHT));
    }
}
