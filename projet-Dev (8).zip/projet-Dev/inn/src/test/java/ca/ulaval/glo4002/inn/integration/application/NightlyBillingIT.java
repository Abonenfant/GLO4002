package ca.ulaval.glo4002.inn.integration.application;

import org.glassfish.hk2.api.ServiceLocator;
import org.glassfish.hk2.utilities.ServiceLocatorUtilities;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.Inn;
import ca.ulaval.glo4002.inn.domain.room.Room;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomOccupant;
import ca.ulaval.glo4002.inn.domain.room.RoomRepository;
import ca.ulaval.glo4002.inn.domain.stay.HomeDimension;
import ca.ulaval.glo4002.inn.domain.stay.Money;
import ca.ulaval.glo4002.inn.domain.stay.Species;
import ca.ulaval.glo4002.inn.domain.stay.StayFactory;
import ca.ulaval.glo4002.inn.domain.stay.StayPackage;
import ca.ulaval.glo4002.inn.domain.stay.StayTerms;
import ca.ulaval.glo4002.inn.domain.stay.Traveller;
import ca.ulaval.glo4002.inn.domain.stay.TravellerProfile;
import ca.ulaval.glo4002.inn.domain.stay.TravellerRepository;
import ca.ulaval.glo4002.inn.interfaces.configuration.ApplicationBinder;

import static org.junit.jupiter.api.Assertions.assertEquals;

class NightlyBillingIT {
    private static final ExistenceNumber EXISTENCE_NUMBER = new ExistenceNumber("EX-01");
    private static final TravellerProfile PROFILE = new TravellerProfile("Aliqua", Species.QUIDAM, 100, HomeDimension.SALARIA);
    private static final StayTerms COMFORT_THREE_NIGHTS = new StayTerms(PROFILE, StayPackage.COMFORT, 3);
    private static final RoomNumber ROOM_NUMBER = new RoomNumber(1);
    private static final int ROOM_CAPACITY = 1;
    private static final int RESERVATION_NIGHT = 1;
    private static final int FIRST_NIGHT = 2;
    private static final int MIDDLE_NIGHT = 3;
    private static final int LAST_NIGHT = 4;
    private static final int NIGHT_AFTER_LAST_NIGHT = 5;

    private final ServiceLocator serviceLocator = ServiceLocatorUtilities.bind(new ApplicationBinder());
    private final Inn inn = serviceLocator.getService(Inn.class);
    private final TravellerRepository travellerRepository = serviceLocator.getService(TravellerRepository.class);
    private final RoomRepository roomRepository = serviceLocator.getService(RoomRepository.class);

    @BeforeEach
    void setUp() {
        Room room = new Room(ROOM_NUMBER, PROFILE.species().requiredConfiguration(), ROOM_CAPACITY); roomRepository.save(room);

        Traveller traveller = new Traveller(EXISTENCE_NUMBER, new StayFactory().createBookedStay(RESERVATION_NIGHT, COMFORT_THREE_NIGHTS, ROOM_NUMBER));

        room.reservePlace(EXISTENCE_NUMBER);
        traveller.arrive(FIRST_NIGHT);
        room.occupyReservedPlace(new RoomOccupant(EXISTENCE_NUMBER, PROFILE.name()));
        travellerRepository.save(traveller);
    }

    @AfterEach
    void tearDown() {
        serviceLocator.shutdown();
    }

    @Test
    void givenComfortStay_whenReservationNightPasses_thenNothingIsBilled() {
        passNightsUntil(RESERVATION_NIGHT);

        assertEquals(Money.ZERO, totalBilledAmount());
    }

    @Test
    void givenComfortStay_whenFirstNightPasses_thenOneNightIsBilled() {
        passNightsUntil(FIRST_NIGHT);

        assertEquals(Money.ofPieces(150), totalBilledAmount());
    }

    @Test
    void givenComfortStay_whenSecondNightPasses_thenTwoNightsAreBilled() {
        passNightsUntil(MIDDLE_NIGHT);

        assertEquals(Money.ofPieces(300), totalBilledAmount());
    }

    @Test
    void givenComfortStay_whenLastNightPasses_thenLastNightIsBilledToo() {
        passNightsUntil(LAST_NIGHT);

        assertEquals(Money.ofPieces(450), totalBilledAmount());
    }

    @Test
    void givenComfortStay_whenNightAfterLastNightPasses_thenAmountDueNoLongerIncreases() {
        passNightsUntil(NIGHT_AFTER_LAST_NIGHT);

        assertEquals(Money.ofPieces(450), totalBilledAmount());
    }

    private Money totalBilledAmount() {
        return travellerRepository.findByExistenceNumber(EXISTENCE_NUMBER).orElseThrow().getLatestStay().getTotalBilledAmount();
    }

    private void passNightsUntil(int night) {
        while (inn.getCurrentNight() < night) {
            inn.passNight();
        }
    }
}
