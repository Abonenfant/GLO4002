package ca.ulaval.glo4002.inn.unit.domain.action;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.action.OrderAction;
import ca.ulaval.glo4002.inn.domain.food.FoodType;
import ca.ulaval.glo4002.inn.domain.order.Order;
import ca.ulaval.glo4002.inn.domain.order.OrderFactory;
import ca.ulaval.glo4002.inn.domain.order.OrderRepository;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

public class OrderActionTest {

    private static final int QUANTITY = 12;
    private static final int DELIVERY_DELAY = 2;
    private static final int EXECUTION_NIGHT = 4;

    private final OrderRepository orderRepository = mock(OrderRepository.class);
    private final OrderAction orderAction =
            new OrderAction(FoodType.PLANT, QUANTITY, DELIVERY_DELAY, orderRepository, new OrderFactory());

    @Test
    void givenOrderAction_whenExecuted_thenOrderIsSavedAtExecutionNight() {
        orderAction.execute(EXECUTION_NIGHT);

        Order expectedOrder = new Order(FoodType.PLANT, QUANTITY, EXECUTION_NIGHT, EXECUTION_NIGHT + DELIVERY_DELAY);
        verify(orderRepository).save(expectedOrder);
    }

    @Test
    void givenOrderAction_whenNotExecuted_thenNoOrderIsSaved() {
        verifyNoInteractions(orderRepository);
    }
}
