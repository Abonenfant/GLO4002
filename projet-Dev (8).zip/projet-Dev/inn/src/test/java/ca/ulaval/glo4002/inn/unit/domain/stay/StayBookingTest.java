package ca.ulaval.glo4002.inn.unit.domain.stay;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.room.Room;
import ca.ulaval.glo4002.inn.domain.room.RoomAssignmentPolicy;
import ca.ulaval.glo4002.inn.domain.room.RoomDirectory;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.stay.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

public class StayBookingTest {
    private static final int NIGHT = 2;
    private static final ExistenceNumber EXISTENCE_NUMBER = new ExistenceNumber("EX-4417-Q");
    private static final int NIGHTS = 5;
    private static final RoomNumber ROOM_NUMBER = new RoomNumber(3);
    private TravellerProfile travellerProfileMock;
    private StayPackage stayPackageMock;
    private TravellerRepository travellerRepositoryMock;
    private StayFactory stayFactoryMock;
    private RoomAssignmentPolicy roomAssignmentPolicyMock;
    private RoomDirectory roomDirectoryMock;
    private StayBooking stayBooking;

    @BeforeEach
    public void setUp() {
        travellerProfileMock = mock(TravellerProfile.class);
        stayPackageMock = mock(StayPackage.class);
        travellerRepositoryMock = mock(TravellerRepository.class);
        stayFactoryMock = mock(StayFactory.class);
        roomAssignmentPolicyMock = mock(RoomAssignmentPolicy.class);
        roomDirectoryMock = mock(RoomDirectory.class);
        stayBooking = new StayBooking(NIGHT, EXISTENCE_NUMBER, travellerProfileMock, stayPackageMock, NIGHTS,
                travellerRepositoryMock, stayFactoryMock, roomAssignmentPolicyMock, roomDirectoryMock);
    }

    @Test
    public void givenCompatibleRoom_whenBookStay_thenStayIsBooked() {
        Room room = mock(Room.class);
        when(room.getRoomNumber()).thenReturn(ROOM_NUMBER);
        when(roomAssignmentPolicyMock.findBestAvailableRoom(eq(roomDirectoryMock), any()))
                .thenReturn(Optional.of(room));

        Stay bookedStay = mock(Stay.class);
        when(bookedStay.getStatus()).thenReturn(StayStatus.BOOKED);
        when(stayFactoryMock.createBookedStay(anyInt(), any(), any(RoomNumber.class))).thenReturn(bookedStay);

        Traveller traveller = mock(Traveller.class);
        when(traveller.isAlreadyStaying()).thenReturn(false);
        when(travellerRepositoryMock.findByExistenceNumber(EXISTENCE_NUMBER)).thenReturn(Optional.of(traveller));

        stayBooking.bookStay();

        ArgumentCaptor<Stay> stayCaptor = ArgumentCaptor.forClass(Stay.class);
        verify(traveller).addStay(stayCaptor.capture());
        assertEquals(StayStatus.BOOKED, stayCaptor.getValue().getStatus());
    }

    @Test
    public void givenNonExistingTraveller_whenBookStay_thenTravellerIsCreated() {
        when(travellerRepositoryMock.findByExistenceNumber(EXISTENCE_NUMBER)).thenReturn(Optional.empty());
        Stay bookedStay = mock(Stay.class);
        when(bookedStay.getStatus()).thenReturn(StayStatus.BOOKED);
        when(stayFactoryMock.createBookedStay(anyInt(), any(), any(RoomNumber.class))).thenReturn(bookedStay);

        stayBooking.bookStay();

        ArgumentCaptor<Traveller> travellerCaptor = ArgumentCaptor.forClass(Traveller.class);
        verify(travellerRepositoryMock).save(travellerCaptor.capture());
        assertEquals(EXISTENCE_NUMBER, travellerCaptor.getValue().getExistenceNumber());
    }

    @Test
    public void givenExistingTravellerAlreadyStaying_whenBookStay_thenStayIsRefusedWithAlreadyStayingReason() {
        Stay refusedStay = mock(Stay.class);
        when(refusedStay.getStatus()).thenReturn(StayStatus.REFUSED);
        when(refusedStay.getRefusalReason()).thenReturn(Optional.of(StayRefusalReason.ALREADY_STAYING));
        when(stayFactoryMock.createRefusedStay(anyInt(), any(), eq(StayRefusalReason.ALREADY_STAYING)))
                .thenReturn(refusedStay);

        Traveller traveller = mock(Traveller.class);
        when(traveller.isAlreadyStaying()).thenReturn(true);
        when(travellerRepositoryMock.findByExistenceNumber(EXISTENCE_NUMBER)).thenReturn(Optional.of(traveller));

        stayBooking.bookStay();

        ArgumentCaptor<Stay> stayCaptor = ArgumentCaptor.forClass(Stay.class);
        verify(traveller).addStay(stayCaptor.capture());
        assertEquals(StayStatus.REFUSED, stayCaptor.getValue().getStatus());
        assertEquals(Optional.of(StayRefusalReason.ALREADY_STAYING), stayCaptor.getValue().getRefusalReason());
    }

    @Test
    public void givenNoRoom_whenBookStay_thenStayIsRefusedWithNoCompatibleRoomReason() {
        Stay refusedStay = mock(Stay.class);
        when(refusedStay.getStatus()).thenReturn(StayStatus.REFUSED);
        when(refusedStay.getRefusalReason()).thenReturn(Optional.of(StayRefusalReason.NO_COMPATIBLE_ROOM));
        when(stayFactoryMock.createRefusedStay(anyInt(), any(), eq(StayRefusalReason.NO_COMPATIBLE_ROOM)))
                .thenReturn(refusedStay);

        Traveller traveller = mock(Traveller.class);
        when(travellerRepositoryMock.findByExistenceNumber(EXISTENCE_NUMBER)).thenReturn(Optional.of(traveller));

        stayBooking.bookStay();

        ArgumentCaptor<Stay> stayCaptor = ArgumentCaptor.forClass(Stay.class);
        verify(traveller).addStay(stayCaptor.capture());
        assertEquals(StayStatus.REFUSED, stayCaptor.getValue().getStatus());
        assertEquals(Optional.of(StayRefusalReason.NO_COMPATIBLE_ROOM), stayCaptor.getValue().getRefusalReason());
    }
}
