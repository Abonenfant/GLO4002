package ca.ulaval.glo4002.inn.unit.domain.action;

import java.util.Optional;

import org.junit.jupiter.api.Test;

import ca.ulaval.glo4002.inn.domain.ExistenceNumber;
import ca.ulaval.glo4002.inn.domain.action.SetupRoomAction;
import ca.ulaval.glo4002.inn.domain.room.Atmosphere;
import ca.ulaval.glo4002.inn.domain.room.Gravity;
import ca.ulaval.glo4002.inn.domain.room.Room;
import ca.ulaval.glo4002.inn.domain.room.RoomConfiguration;
import ca.ulaval.glo4002.inn.domain.room.RoomNumber;
import ca.ulaval.glo4002.inn.domain.room.RoomOccupant;
import ca.ulaval.glo4002.inn.domain.room.RoomOperation;
import ca.ulaval.glo4002.inn.domain.room.RoomRejectionReason;
import ca.ulaval.glo4002.inn.domain.room.RoomRejectionRepository;
import ca.ulaval.glo4002.inn.domain.room.RoomRepository;
import ca.ulaval.glo4002.inn.domain.room.Temperature;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

class SetupRoomActionTest {

    private static final int CAPACITY = 3;
    private static final int EXECUTION_NIGHT = 5;
    private static final RoomNumber ROOM_NUMBER = new RoomNumber(42);
    private static final RoomConfiguration CONFIGURATION = new RoomConfiguration(
            Atmosphere.STANDARD,
            Gravity.NORMAL,
            Temperature.TEMPERATE
    );

    private final RoomRepository roomRepository = mock(RoomRepository.class);
    private final RoomRejectionRepository roomRejectionRepository = mock(RoomRejectionRepository.class);
    private final SetupRoomAction setupRoomAction =
            new SetupRoomAction(roomRepository, roomRejectionRepository, ROOM_NUMBER, CONFIGURATION, CAPACITY);

    @Test
    void givenSetupRoomAction_whenExecuted_thenRoomIsSavedInRepository() {
        when(roomRepository.findByNumber(ROOM_NUMBER)).thenReturn(Optional.empty());

        setupRoomAction.execute(EXECUTION_NIGHT);

        verify(roomRepository).save(argThat(room ->
                room.getRoomNumber().equals(ROOM_NUMBER)
                        && room.getConfiguration().equals(CONFIGURATION)
                        && room.getCapacity() == CAPACITY
        ));
    }

    @Test
    void givenSetupRoomAction_whenNotExecuted_thenNoRoomIsSaved() {
        verifyNoInteractions(roomRepository);
    }

    @Test
    void givenRoomAlreadyExists_whenExecuted_thenRejectionIsSavedWithCorrectValues() {
        Room existingRoom = mock(Room.class);
        when(roomRepository.findByNumber(ROOM_NUMBER)).thenReturn(Optional.of(existingRoom));

        setupRoomAction.execute(EXECUTION_NIGHT);

        verify(roomRejectionRepository).save(argThat(rejection ->
                ROOM_NUMBER.equals(rejection.getRoomNumber())
                        && rejection.getOperation() == RoomOperation.SETUP
                        && rejection.getRejectedAtNight() == EXECUTION_NIGHT
                        && rejection.getReason() == RoomRejectionReason.ROOM_NUMBER_ALREADY_USED
        ));
        verify(roomRepository, never()).save(any(Room.class));
    }

    @Test
    void givenExistingRoom_whenExecuted_thenExistingRoomRemainsUnchanged() {
        Room existingRoom = new Room(ROOM_NUMBER, CONFIGURATION, CAPACITY);
        existingRoom.reservePlace(new ExistenceNumber("2"));
        existingRoom.occupyReservedPlace(new RoomOccupant(new ExistenceNumber("2"), "John"));

        when(roomRepository.findByNumber(ROOM_NUMBER)).thenReturn(Optional.of(existingRoom));

        setupRoomAction.execute(EXECUTION_NIGHT);

        assertEquals(CONFIGURATION, existingRoom.getConfiguration());
        assertEquals(CAPACITY, existingRoom.getCapacity());
        assertEquals(0, existingRoom.getReservedExistenceNumbers().size());
        assertEquals(1, existingRoom.getOccupants().size());
    }

    @Test
    void givenExistingRoom_whenExecuted_thenNoNewRoomIsCreated() {
        when(roomRepository.findByNumber(ROOM_NUMBER)).thenReturn(Optional.of(mock(Room.class)));

        setupRoomAction.execute(EXECUTION_NIGHT);

        verify(roomRepository, never()).save(any(Room.class));
    }
}
