import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Overridable so the container can reach the APIs by their compose service name
const INN_URL = process.env.INN_URL ?? 'http://localhost:9091'
const CONSULATE_URL = process.env.CONSULATE_URL ?? 'http://localhost:9092'

const proxyTo = (prefix, target) => ({
  target,
  changeOrigin: true,
  rewrite: (path) => path.slice(prefix.length),
})

export default defineConfig({
  plugins: [react()],
  server: {
    port: 9090,
    strictPort: true,
    // Also applies to "vite preview"
    proxy: {
      '/api/inn': proxyTo('/api/inn', INN_URL),
      '/api/consulate': proxyTo('/api/consulate', CONSULATE_URL),
    },
  },
  preview: {
    port: 9090,
    strictPort: true,
  },
})
