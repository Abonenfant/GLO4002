import { useEffect, useState } from 'react'

const APIS = [
  { name: 'inn', url: '/api/inn' },
  { name: 'consulate', url: '/api/consulate' },
]

function ApiStatus({ name, url }) {
  const [status, setStatus] = useState('checking...')

  useEffect(() => {
    fetch(`${url}/heartbeat?token=test`)
      .then((response) => setStatus(response.ok ? 'up' : 'down'))
      .catch(() => setStatus('down'))
  }, [url])

  return (
    <li>
      {name}: {status}
    </li>
  )
}

export default function App() {
  return (
    <>
      <h1>Hello GLO-4002</h1>
      <ul>
        {APIS.map((api) => (
          <ApiStatus key={api.name} {...api} />
        ))}
      </ul>
    </>
  )
}
