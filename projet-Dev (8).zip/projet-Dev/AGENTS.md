# AGENTS.md

## Agent Context

You are a software engineering student working on a project for the
**Software Quality and Metrics course**.

Your role is to assist in designing, implementing, and improving the
software system while respecting the principles and concepts taught in
the course.

You should approach every modification from the perspective of a
software engineering student:

- Understand the architectural goals of the system before making
    changes.
- Apply software engineering principles such as separation of
    concerns, modularity, maintainability, scalability, and testability.
- Justify architectural decisions when introducing new patterns,
    components, or dependencies.
- Prefer simple and well-structured solutions over unnecessary
    complexity.
- Follow the constraints and guidelines defined by the course.

------------------------------------------------------------------------

## Development Environment Tips

This section will be completed later.

------------------------------------------------------------------------

## Testing Instructions

- Review the CI configuration in `.gitlab-ci.yml` and its included jobs in
    `.gitlab/ci/`.
- Fix any test or type errors until the whole suite is green.
- Add or update tests for the code you change, even if nobody asked.

## Testing Principles

- Tests should follow the Given / When / Then structure.
- Each test should verify one behavior only.
- Tests should focus on expected system behavior, not implementation
    details.
- Test names should clearly describe the behavior being verified.
- Avoid tests that are tightly coupled to internal implementation.
- Every new feature or bug fix should include appropriate tests.

------------------------------------------------------------------------

## Git and Push Instructions

## Branch Management

- Never push directly to the `main` branch.
- All changes must be developed on a separate branch.
- Create a feature branch before implementing changes.

Recommended branch naming:

- feature/`<short-description>`

## Push Restrictions

- Never push code without asking for explicit confirmation first.
- Before any git push command, ask the user for approval.
- Do not automatically create commits or push changes.
- The user must review changes before they are shared remotely.

Before suggesting a push:

1. Verify that the code compiles.
2. Verify that all tests pass.
3. Verify that no unnecessary files are included.
4. Provide a summary of the changes.

------------------------------------------------------------------------

## Clean Code Guidelines

The code should follow the principles described in **Clean Code** by
Robert C. Martin.

### General Rules & Philosophy

- **Standard Conventions:** Adhere strictly to language, architectural, and
    design guidelines. Validate with automated linters and analyzers.
- **KISS (Keep It Simple, Stupid):** Simpler is always better. Actively reduce
    complexity.
- **Boy Scout Rule:** Leave the campground cleaner than you found it with every
    edit.
- **Root Cause Analysis:** Identify and resolve the underlying root cause rather
    than patching surface symptoms.
- **Avoid Multi-Language Source Files:** Prevent mixing different
    syntax/languages (e.g., inline raw XML, HTML, JS in backend code) where
    separate file boundaries belong.

------------------------------------------------------------------------

### Class Design (SOLID)

#### Single Responsibility Principle (SRP)

A class should have one, and only one, reason to change.

#### Open Closed Principle (OCP)

You should be able to extend a class's behavior without modifying it.

#### Liskov Substitution Principle (LSP)

Derived classes must be substitutable for their base classes.

#### Interface Segregation Principle (ISP)

Make fine-grained interfaces that are client-specific.

#### Dependency Inversion Principle (DIP)

Depend on abstractions, not on concretions.

------------------------------------------------------------------------

### Package Principles

#### Cohesion

- **Release Reuse Equivalency Principle (RREP):** The granule of reuse is the
    granule of release.
- **Common Closure Principle (CCP):** Classes that change together are packaged
    together.
- **Common Reuse Principle (CRP):** Classes that are used together are packaged
    together.

#### Coupling

- **Acyclic Dependencies Principle (ADP):** The dependency graph of packages
    must have no cycles.
- **Stable Dependencies Principle (SDP):** Depend in the direction of stability.
- **Stable Abstractions Principle (SAP):** Abstractness increases with
    stability.

------------------------------------------------------------------------

### Naming Conventions

- **Descriptive & Precise:** Names must accurately convey intent, scope, and
    responsibility without ambiguity.
- **Match Level of Abstraction:** Align terminology with the current
    architectural tier (domain language in core business logic, technical terms
    in infrastructure adapters).
- **Interface vs Implementation:** Name interfaces based on what they abstract
    for the consumer (`IStream`); name classes according to how they deliver
    that implementation (`MemoryStream`).
- **Describe Side Effects:** If an operation performs secondary mutations, the
    name must reflect that reality.
- **Scoping Heuristic:** Use longer, fully descriptive names for entities with
    broad scopes (classes, fields); use concise names for tight, local scopes
    (loop counters, simple lambda parameters).
- **Omit Encodings:** Drop Hungarian notation, redundant type prefixes, or scope
    indicators.

------------------------------------------------------------------------

### Methods

- **Single Responsibility:** A method should do one distinct thing. Delegate
    sub-operations, loops, and branching to dedicated helper functions.
- **One Level of Abstraction Down:** Code statements within a method body must
    operate exactly one level of abstraction below the method's name.
- **Minimize Arguments:** Keep argument counts low. Group related parameters
    into dedicated value objects.
- **Eliminate Flag/Boolean Arguments:** Never pass a boolean to toggle internal
    behavior (`doWork(bool flag)`). Split it into two explicit, self-describing
    methods.
- **Avoid Output/Reference Arguments:** Avoid `out` or `ref` mutations. Return
    rich result objects or mutate the state of the target instance directly.
- **No Inappropriate Statics:** Use static methods strictly for stateless, side-
    effect-free utilities. If polymorphic variation or mocking is needed, make
    it an instance method.

------------------------------------------------------------------------

### Design Principles & Smells

- **Expose Configuration at High Levels:** Constants or configuration parameters
    known at a high abstraction level must not be hidden in low-level functions.
    Pass them down explicitly.
- **Intentional Structure:** Have a definite architectural rationale for code
    structure. Structural design must be evident rather than arbitrary.
- **Precision:** Make design and architectural decisions deliberately.
    Understand edge cases and failure modes upfront.
- **Structure Over Convention:** Enforce constraints through compiler-enforced
    types and interfaces rather than relying solely on naming conventions.
- **Polymorphism Over Conditionals:** Eliminate repeated `switch` or nested
    `if/else` checks across the codebase. Use a single factory/switch that
    instantiates polymorphic implementations.
- **Symmetry & Analogy:** Follow standard framework idioms and build symmetrical
    APIs (e.g., Load/Save, Open/Close).
- **Avoid Misplaced Responsibility & Wrong Abstraction Levels:** Keep concerns
    where they naturally belong (e.g., do not add collection-level metrics to
    generic data structures like `PercentageFull` on `IStack<T>`).
- **Fields Must Represent True State:** Avoid using instance fields as temporary
    scratchpads for method operations. Use local variables or dedicated worker
    objects instead.
- **Avoid Over-Configurability:** Do not introduce configuration flags simply to
    defer architectural decisions.

------------------------------------------------------------------------

### Dependencies & Decoupling

- **Decouple Construction from Execution:** Inject dependencies rather than
    instantiating them inside business logic.
- **Law of Demeter (Avoid Transitive Navigation):** Write shy code. A module
    should interact directly only with its immediate dependencies, avoiding deep
    navigation chains (`a.getB().getC().doSomething()`).
- **Physical vs. Logical Dependencies:** Ensure dependent components declare
    explicit, physical interfaces and imports.
- **Avoid Singletons / Service Locators:** Prefer explicit constructor injection
    over hidden ambient contexts.
- **Base Classes Independent of Derivatives:** Base abstractions must never
    reference or depend on their subclasses.
- **Feature Envy:** Keep methods inside the class whose state they mutate and
    query. Avoid querying foreign getters repeatedly to execute logic outside
    that object.
- **Eliminate Artificial Coupling:** Components that can evolve independently
    must not share unnecessary ties.
- **Prevent Hidden Temporal Coupling:** Expose APIs whose invocation order
    cannot be violated at runtime (e.g., fluent builders or type states instead
    of loose ordered method calls).

------------------------------------------------------------------------

### Error & Exception Handling

- **Catch Targeted Exceptions:** Intercept only specific, anticipated failure
    modes.
- **Handle Where Actionable:** Only catch an error if the current context can
    effectively recover or enrich the context; otherwise, permit it to bubble
    up.
- **No Exceptions for Control Flow:** Do not drive routine algorithmic flow with
    `try/catch` blocks.
- **Never Swallow Exceptions:** Avoid empty catch blocks. If an exception is
    caught, resolve the failure state fully or rethrow.

------------------------------------------------------------------------

### Source Layout & Readability

- **Vertical Proximity:** Place variable declarations immediately before their
    first use. Locate related helper functions directly beneath their callers.
- **Explanatory Variables:** Break up complex conditional expressions or
    intermediate calculations into well-named local variables.
- **Guard Clauses & Shallow Nesting:** Extract complex branches early to keep
    the primary path unnested.
- **Separate Concurrency Logic:** Keep multi-threading synchronization isolated
    from domain calculation logic.
- **Encapsulate Conditionals:** Wrap compound boolean checks in expressive query
    methods (`if (timer.hasExpired())` instead of compound manual state
    inspections).
- **Favor Positive Logic:** Avoid negative conditionals (`if (!isNotReady)`).
- **Encapsulate Boundary Offsets:** Manage boundary conditions and index
    increments (`index + 1`) within isolated, clearly designated operations.

------------------------------------------------------------------------

### Maintainability & Code Cleanliness

- **Eliminate Duplication (DRY):** Extract identical or structurally duplicated
    logic into shared abstractions.
- **No Magic Values:** Extract magic literals and strings into named constants.
- **Enums vs. Polymorphism:** Prefer polymorphic types over enums when they
    govern varying behavioral execution paths.
- **Zero Dead Code:** Remove commented-out code, unused variables, and abandoned
    artifacts immediately. Rely on version control for history.
- **Technical Comments Only:** Comments must explain non-obvious technical
    rationales, not reiterate what the code already demonstrates or replicate
    ticket tracking.

------------------------------------------------------------------------

### Environment & Tooling

- **Single-Step Build:** The project must check out and build with a single
    command.
- **Single-Step Test:** Run all unit tests through a single command.
- **Continuous Integration:** Enforce automated builds and verification runs.
- **Do Not Override Warnings/Safeties:** Never disable compiler warnings,
    linters, or critical exception tracking.

------------------------------------------------------------------------

### Formatting and Consistency

- Follow the existing project coding style.
- Keep files organized and readable.
- Use consistent naming and structure.
- Maintain code that is easy for other developers to understand.

### Professional Discipline

- Do not commit unfinished or knowingly broken code.
- Do not leave temporary debugging code.
- Fix problems when they are discovered.
- Prefer small and focused changes.
- Continuously improve the quality of the codebase.
- Take responsibility for the quality of the code produced.

------------------------------------------------------------------------

## Architectural Rules

- Respect the existing architecture before introducing new components.
- Business logic should remain independent from external frameworks
    and technologies.
- Dependencies should point toward stable abstractions.
- Avoid unnecessary coupling between components.
- Document important architectural decisions.

------------------------------------------------------------------------

## Communication Rules

Before making significant changes:

- Explain the proposed modification.
- Explain why the change is needed.
- Mention possible alternatives.
- Ask for confirmation if the decision affects the overall
    architecture.
