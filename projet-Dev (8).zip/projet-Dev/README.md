# ReadMe à supprimer avant la remise

Ce readme sert à vous expliquer la structure de base de votre projet. Remplacez le avant la première remise.

## Structure

Il existe deux [module maven](https://maven.apache.org/guides/mini/guide-multiple-modules.html) dans le projet :

* `inn` et `consulate`: le projet que vous développerez. 
* Ici, vous pouvez modifier tout ce qui vous plait, tant que vous ne renommez pas les classes existantes. 
* Le code présent n'est pas nécessairement bon/bien placé/selon les normes de votre équipe. 
* À vous de voir!

## Notes sur les technologies utilisées

* [Jetty](https://www.eclipse.org/jetty/) est un Servlet Container. Il accepte les requêtes du web et sait comment répondre.
* [Jersey](https://jersey.github.io/) est un Servlet fait pour le développement d'API REST. Il sait comment faire la correspondance entre un API REST et vos méthodes selon la norme JAX-RS.
* [Jackson](https://www.baeldung.com/jackson) sert à sérialiser/désérialiser les objets JSON en POJO.

Si vous n'êtes pas familiers avec ces concepts, il est fortement suggéré d'utiliser google/stackoverflow pour les apprendre rapidement. 
Ceux-ci peuvent être matière à examen.

:warning: Jetty, Jersey et Jackson sont utilisés dans le projet de base.
Vous pouvez choisir d'autres technologies, mais vous devrez analyser les avantages et inconvéniants d'abord. 
Si vous voulez le faire, venez nous en parler. 
Entre autre, Spring et Spring Boot sont reconnus pour causer des maux de têtes vers la fin de la session. 
Dans le passé, certains étudiants ont râtés certaines remises à cause de ce choix.

## Intégration Docker

Un Dockerfile est également fournis si vous désirez essayer de rouler votre code dans la même configuration que ce que nous utiliserons.

Pour ce faire:

```bash
docker build -t glo4002-inn --build-arg APP=inn .
docker build -t glo4002-consulate --build-arg APP=consulate .
docker build -t glo4002-frontend web
docker run -t -p 9090:9090 glo4002-frontend
docker run -t -p 9091:9091 glo4002-inn
docker run -t -p 9092:9092 glo4002-consulate
```

Ou vous pouvez utiliser docker compose : 

```bash
docker compose up # avec --build pour forcer la recompilation
```

## Démarrer le projet

Vous pouvez démarrer chaque serveur (`ApplicationServer`) dans votre IDE.

Le `main()` ne demande pas d'arguments.

Vous pouvez également rouler le serveur via maven (**c'est ce qui sera utilisé pour corriger votre projet**) :

```bash
mvn clean install
mvn exec:java -pl inn # ou mvn exec:java -pl consulate
```

:warning: Ces commandes seront utilisées pour la correction automatique du projet. Elles doivent donc fonctionner!

Une resource "heartbeat" vous est fournis pour tester que le service démarre bien. 
Allez à l'URL `http://localhost:9091/heartbeat?token=unique_token` pour le valider. 
Vous n'êtes pas obligés de garder le heartbeat (mais si vous le supprimez, ne laissez pas de code mort!)

## Organisation et exécution des tests

Les tests Java sont regroupés par type dans `inn/src/test/java/ca/ulaval/glo4002/inn/` :

* `unit/` : tests d'une unité métier ou technique, nommés `*Test.java`.
  Ils conservent les sous-packages `domain`, `application`, `interfaces` et `infrastructure`.
  Les objets valeur et collaborateurs internes au domaine peuvent être réels ; les dépendances
  externes à l'unité testée sont simulées lorsque nécessaire.
* `integration/` : tests de collaboration entre couches ou avec une bibliothèque, nommés `*IT.java`.
  Ils couvrent le parcours commande/livraison/stock (`GardConsequencesIT`), la ressource avec
  le domaine et son mapper (`InnResourceIT`), et la sérialisation Jackson (`OrderResponseSerializationIT`).

Le dépôt en mémoire est testé comme une unité, sans base de données externe.
Les tests REST actuels appellent directement les ressources : aucun test de bout en bout HTTP
n'est présent. Le module `consulate` et le frontend ne contiennent pas encore de tests automatisés.
Les futurs tests Java de `consulate` suivront les mêmes conventions.

Avec Java 25, depuis la racine :

```bash
mvn test                         # Tests unitaires (Surefire)
mvn verify                       # Tests unitaires + intégration (Failsafe), et compilation des JAR
mvn test-compile failsafe:integration-test failsafe:verify # Intégration seulement
```

Après un déplacement ou renommage de tests, utiliser `mvn clean verify` pour supprimer
les anciennes classes compilées. La CI exécute `mvn verify` et publie les rapports JUnit
des deux suites. `mvn package` seul n'exécute pas les tests d'intégration.

## Utilisation de checkstyle

Un checkstyle de base est fournie, mais il n'est pas utilisé par défaut. Vous pouvez le rouler avec 
`mvn checkstyle:check`, mais si vous voulez l'utiliser pour de vrai, il est conseiller de le "binder" à un goal.
[Documentation](https://maven.apache.org/plugins/maven-checkstyle-plugin/usage.html).

Vous pouvez également ajouter cette configuration à intelliJ. Il y a 2 étapes : l'ajouter dans `Settings > Tools > Checkstyle`, 
afin d'avoir les erreurs directement dans l'IDE. Ensuite, on peut aussi créer un formatter à partir de la configuration
de checkstyle dans `Settings > Editor > Code Style > Java` et ensuite faire `Import Scheme > From checkstyle`.

Évidement, la configuration fournie n'est qu'un exemple, vous pouvez la modifier pour votre équipe. Vous pouvez également
changer pour un outi plus récent, tel que spotless.

## Code existant

Il n'existe présentement qu'une seule ressource: le heartbeat. Vous pouvez l'essayer avec 
`http://localhost:9091/heartbeat?token=something`. Ce code sert surtout d'un exemple de base de ce qui est possible, 
vous pouvez supprimer tout ça (en fait, le heartbeat ne fait pas partie de la _spec_ du client, alors vous _devriez_ le
supprimer).

Vous avez, de base, les deux modules Maven requis et un ébauche de frontend en React. Libre à vous de changer ce que vous voulez.

Inclut (les 2 backend) : 

* Un serveur HTTP (Jetty) qui écoute sur le port 9091 pour l'auberge et 9092 pour le consulat
* Un serveur REST (Jersey) qui expose les endpoints de l'API
* Un endpoint de test (heartbeat) pour valider que le serveur fonctionne
* La sérialisation/désérialisation JSON (Jackson)
* La sérialisation/sérialisation des dates

## Prochaines étapes

Nous regarderons le projet ensemble pendant les premières séances du cours. 
Le client sera également présent pour vous le présenter davantage. 
D'ici là, assurez-vous de pouvoir exécuter le code sur votre machine.

## Besoin d'aide?

Contactez-nous sur Discord à partir de votre channel d'équipe si quelque chose ne fonctionne pas!
