package ca.ulaval.glo4002.consulate.api.rest.dto;

import java.util.List;

public record ConstraintValidationResponse(String message, List<String> validations) {

}
